NIRVANA_TILE_DIR$ = NIRVANA_PROJECT_BASE_DIR$ + NIRVANA_PATH_SEPARATOR$ + "tiles" + NIRVANA_PATH_SEPARATOR$


Type Nirvana_TileMap
Dim TilesetName$
Dim Tileset_ID
Dim TileMap_ID
Dim Mask_Index
Dim Mask_Count
Dim Cut_Index
Dim Cut_Count
End Type

Type Nirvana_TilesetCut
Dim StartTile
Dim NumRows
Dim NumCols
Dim Image_ID
End Type

Dim Nirvana_Tileset_Image_Stack : Nirvana_Tileset_Image_Stack = CreateStack_N()

Dim Nirvana_Tileset_ID_0 : Nirvana_Tileset_ID_0 = -1

Dim Nirvana_Tileset_Image_0 : Nirvana_Tileset_Image_0 = -1

Dim Nirvana_TileMask_Matrix[0]
Dim Nirvana_TileMask_Matrix_Name$[0]



Dim Nirvana_Tileset_Cuts[11] As Nirvana_TilesetCut

Function Nirvana_MakeTileCut(tmp_canvas, tset_image, color_key, cut_index, tile_w, tile_h)
	If Not ImageExists(tset_image) Then
		Return -1
	End If

	If cut_index < 0 Or cut_index >= ArraySize(Nirvana_Tileset_Cuts, 1) Then
		Return -1
	End If

	current_canvas = ActiveCanvas()
	Canvas(tmp_canvas)
	ClearCanvas()

	Dim img_w, img_h
	GetImageSize(tset_image, img_w, img_h)
	widthInTiles = img_w / tile_w

	src_x = (Nirvana_Tileset_Cuts[cut_index].StartTile MOD widthInTiles) * tile_w
	src_y = Int(Nirvana_Tileset_Cuts[cut_index].StartTile  /  widthInTiles) * tile_h
	src_w = tile_w * Nirvana_Tileset_Cuts[cut_index].NumCols
	src_h = tile_h * Nirvana_Tileset_Cuts[cut_index].NumRows

	DrawImage_Blit(tset_image, 0, 0, src_x, src_y, src_w, src_h)

	Img_ID = CanvasClip(0, 0, src_w, src_h)
	ColorKey(Img_ID, color_key)

	Canvas(current_canvas)

	Return Img_ID
End Function

Function Nirvana_GetImageDefaultColorKey(tmp_canvas, img, w, h)
	current_canvas = ActiveCanvas()
	Canvas(tmp_canvas)
	ClearCanvas()
	DrawImage_Blit(Nirvana_Tileset_Image_0, 0, 0, 0, 0, w, h)
	ts_color_key = GetPixel(0,0)
	Canvas(current_canvas)
	Return ts_color_key
End Function

Function Nirvana_Tileset_0()
	If Nirvana_Tileset_ID_0 >= 0 Then
		Return Nirvana_Tileset_ID_0
	End If

	TMP_CANVAS = OpenCanvas( 1024, 1024, 0, 0, 1024, 1024, 1)

	If Nirvana_Tileset_Image_0 < 0 Then
		If OS$ = "WINDOWS" Then
			Nirvana_Tileset_Image_0 = LoadImage(NIRVANA_TILE_DIR$ + "grassland_tiles.png")
		Else
			Nirvana_Tileset_Image_0 = LoadImage(NIRVANA_TILE_DIR$ + "grassland_tiles.png")
		End If

		If Nirvana_Tileset_Image_0 >= 0 Then
			Push_N(Nirvana_Tileset_Image_Stack, Nirvana_Tileset_Image_0)
		End If
	End If

	ts_color = Nirvana_GetImageDefaultColorKey(TMP_CANVAS, Nirvana_Tileset_Image_0, 64, 32)

	Nirvana_Tileset_ID_0 = CreateTileSet(Nirvana_Tileset_Image_0, 64, 32)

	'-------ANIMATIONS-------

	SetTileAnimationLength(Nirvana_Tileset_ID_0, 304, 16)
	SetTileAnimationSpeed(Nirvana_Tileset_ID_0, 304, 8)

	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 0, 304)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 1, 305)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 2, 306)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 3, 307)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 4, 308)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 5, 309)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 6, 310)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 7, 311)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 8, 312)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 9, 313)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 10, 314)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 11, 315)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 12, 316)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 13, 317)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 14, 318)
	SetTileAnimationFrame(Nirvana_Tileset_ID_0, 304, 15, 319)

	'-------MASK-------

	'-------CUTS-------

	Nirvana_Tileset_Cuts[0].StartTile = 376
	Nirvana_Tileset_Cuts[0].NumRows = 6
	Nirvana_Tileset_Cuts[0].NumCols = 4
	Nirvana_Tileset_Cuts[0].Image_ID = Nirvana_MakeTileCut(TMP_CANVAS, Nirvana_Tileset_Image_0, ts_color,0, 64, 32)

	Nirvana_Tileset_Cuts[1].StartTile = 384
	Nirvana_Tileset_Cuts[1].NumRows = 3
	Nirvana_Tileset_Cuts[1].NumCols = 1
	Nirvana_Tileset_Cuts[1].Image_ID = Nirvana_MakeTileCut(TMP_CANVAS, Nirvana_Tileset_Image_0, ts_color,1, 64, 32)

	Nirvana_Tileset_Cuts[2].StartTile = 353
	Nirvana_Tileset_Cuts[2].NumRows = 5
	Nirvana_Tileset_Cuts[2].NumCols = 1
	Nirvana_Tileset_Cuts[2].Image_ID = Nirvana_MakeTileCut(TMP_CANVAS, Nirvana_Tileset_Image_0, ts_color,2, 64, 32)

	Nirvana_Tileset_Cuts[3].StartTile = 369
	Nirvana_Tileset_Cuts[3].NumRows = 1
	Nirvana_Tileset_Cuts[3].NumCols = 1
	Nirvana_Tileset_Cuts[3].Image_ID = Nirvana_MakeTileCut(TMP_CANVAS, Nirvana_Tileset_Image_0, ts_color,3, 64, 32)

	Nirvana_Tileset_Cuts[4].StartTile = 592
	Nirvana_Tileset_Cuts[4].NumRows = 5
	Nirvana_Tileset_Cuts[4].NumCols = 2
	Nirvana_Tileset_Cuts[4].Image_ID = Nirvana_MakeTileCut(TMP_CANVAS, Nirvana_Tileset_Image_0, ts_color,4, 64, 32)

	Nirvana_Tileset_Cuts[5].StartTile = 580
	Nirvana_Tileset_Cuts[5].NumRows = 6
	Nirvana_Tileset_Cuts[5].NumCols = 2
	Nirvana_Tileset_Cuts[5].Image_ID = Nirvana_MakeTileCut(TMP_CANVAS, Nirvana_Tileset_Image_0, ts_color,5, 64, 32)

	Nirvana_Tileset_Cuts[6].StartTile = 352
	Nirvana_Tileset_Cuts[6].NumRows = 5
	Nirvana_Tileset_Cuts[6].NumCols = 3
	Nirvana_Tileset_Cuts[6].Image_ID = Nirvana_MakeTileCut(TMP_CANVAS, Nirvana_Tileset_Image_0, ts_color,6, 64, 32)

	Nirvana_Tileset_Cuts[7].StartTile = 357
	Nirvana_Tileset_Cuts[7].NumRows = 5
	Nirvana_Tileset_Cuts[7].NumCols = 3
	Nirvana_Tileset_Cuts[7].Image_ID = Nirvana_MakeTileCut(TMP_CANVAS, Nirvana_Tileset_Image_0, ts_color,7, 64, 32)

	Nirvana_Tileset_Cuts[8].StartTile = 135
	Nirvana_Tileset_Cuts[8].NumRows = 2
	Nirvana_Tileset_Cuts[8].NumCols = 1
	Nirvana_Tileset_Cuts[8].Image_ID = Nirvana_MakeTileCut(TMP_CANVAS, Nirvana_Tileset_Image_0, ts_color,8, 64, 32)

	Nirvana_Tileset_Cuts[9].StartTile = 201
	Nirvana_Tileset_Cuts[9].NumRows = 3
	Nirvana_Tileset_Cuts[9].NumCols = 1
	Nirvana_Tileset_Cuts[9].Image_ID = Nirvana_MakeTileCut(TMP_CANVAS, Nirvana_Tileset_Image_0, ts_color,9, 64, 32)

	CloseCanvas(TMP_CANVAS)
	Return Nirvana_Tileset_ID_0
End Function




Function Nirvana_CreateTileMap(tset_name$, tmap_width, tmap_height) As Nirvana_TileMap
	Dim nv_tmap As Nirvana_TileMap
	nv_tmap.TilesetName$ = tset_name$

	Select Case tset_name$

	Case "grassland"
		nv_tmap.Tileset_ID = Nirvana_Tileset_0()
		nv_tmap.TileMap_ID = CreateTileMap(nv_tmap.Tileset_ID, tmap_width, tmap_height)
		nv_tmap.Mask_Index = 0
		nv_tmap.Mask_Count = 0

	End Select

	Return nv_tmap
End Function
