Type Nirvana_Vector2D
Dim X
Dim Y
End Type

Type Nirvana_Size2D
Dim Width
Dim Height
End Type

Type Nirvana_Background
Dim Image_ID
Dim RenderSetting
End Type

Type Nirvana_Shape
Dim Name$
Dim Sprite_ID
Dim ShapeType
Dim ShapeData_Matrix
End Type

Type Nirvana_Layer
Dim Name$
Dim LayerType
Dim Visible
Dim Alpha
Dim Scroll_Speed As Nirvana_Vector2D
Dim Ref_Canvas
Dim Layer_TileMap As Nirvana_TileMap
Dim Layer_TileMap2 As Nirvana_TileMap
Dim Layer_Sprite_Count
Dim Layer_Shape_Count
Dim Bkg As Nirvana_Background
Dim Layer_TS_Stack
End Type

Type Nirvana_Stage
Dim Active
Dim Name$
Dim Tile_Size As Nirvana_Size2D
Dim Stage_Size As Nirvana_Size2D
Dim Layer_Count
Dim Viewport_Size As Nirvana_Size2D
Dim Stage_Offset As Nirvana_Vector2D
End Type


NIRVANA_DATA_DIR$ = NIRVANA_PROJECT_BASE_DIR$ + NIRVANA_PATH_SEPARATOR$ + "data" + NIRVANA_PATH_SEPARATOR$
NIRVANA_BKG_DIR$ = NIRVANA_PROJECT_BASE_DIR$ + NIRVANA_PATH_SEPARATOR$ + "bkg" + NIRVANA_PATH_SEPARATOR$

NIRVANA_LAYER_TYPE_TILEMAP = 0
NIRVANA_LAYER_TYPE_ISO_TILEMAP = 1
NIRVANA_LAYER_TYPE_SPRITE = 2
NIRVANA_LAYER_TYPE_CANVAS_2D = 3
NIRVANA_LAYER_TYPE_CANVAS_3D = 4

NIRVANA_IMG_RENDER_SETTING_NORMAL = 0
NIRVANA_IMG_RENDER_SETTING_STRETCHED = 1
NIRVANA_IMG_RENDER_SETTING_TILED = 2


NIRVANA_WINDOW_WIDTH = 320
NIRVANA_WINDOW_HEIGHT = 200


Dim Nirvana_Stage_Sprites[1] As Nirvana_Sprite
Dim Nirvana_Stage_Shape_Points[1] As Nirvana_Vector2D
Dim Nirvana_Stage_Shapes[7] As Nirvana_Shape
Dim Nirvana_Stage_Layers[5] As Nirvana_Layer

Dim Nirvana_NULL_Shape As Nirvana_Shape
Nirvana_NULL_Shape.Name$ = ""
Nirvana_NULL_Shape.Sprite_ID = -1
Nirvana_NULL_Shape.ShapeType = -1
Nirvana_NULL_Shape.ShapeData_Matrix = -1
ArrayFill(Nirvana_Stage_Shapes, Nirvana_NULL_Shape)

For i = 0 To 4
	Nirvana_Stage_Layers[i].Ref_Canvas = -1
	Nirvana_Stage_Layers[i].Layer_TileMap.Tileset_ID = -1
	Nirvana_Stage_Layers[i].Layer_TileMap.TileMap_ID = -1
	Nirvana_Stage_Layers[i].Layer_TileMap2.Tileset_ID = -1
	Nirvana_Stage_Layers[i].Layer_TileMap2.TileMap_ID = -1
	Nirvana_Stage_Layers[i].Bkg.Image_ID = -1
Next

For i = 0 To 0
	Nirvana_Stage_Sprites[i].Sprite_ID = -1
Next

For i = 0 To 6
	Nirvana_Stage_Shapes[i].Sprite_ID = -1
Next

Dim Nirvana_ActiveStage As Nirvana_Stage : Nirvana_ActiveStage.Active = FALSE

'This is a utility function for reading binary data from tile maps
Function Nirvana_Read32(stream)
		Dim byte_array[4]
		byte_array[3] = ReadByte(stream)
		byte_array[2] = ReadByte(stream)
		byte_array[1] = ReadByte(stream)
		byte_array[0] = ReadByte(stream)
		Return (byte_array[0] shl 24) + (byte_array[1] shl 16) + (byte_array[2] shl 8) + byte_array[3]
End Function

Sub Nirvana_ClearStage()
	If Not Nirvana_ActiveStage.Active Then
		Return
	End If

	Nirvana_ActiveStage.Stage_Offset.X = 0
	Nirvana_ActiveStage.Stage_Offset.Y = 0

	Num_Shapes = ArraySize(Nirvana_Stage_Shapes, 1)
	For n = 0 To Num_Shapes-1
		If MatrixExists(Nirvana_Stage_Shapes[n].ShapeData_Matrix) Then
			DeleteMatrix(Nirvana_Stage_Shapes[n].ShapeData_Matrix)
		End If
		Nirvana_Stage_Shapes[n].ShapeData_Matrix = -1
	Next

	For i = 0 To Nirvana_ActiveStage.Layer_Count-1

		CloseCanvas(Nirvana_Stage_Layers[i].Ref_Canvas)
		Nirvana_Stage_Layers[i].Ref_Canvas = -1

		If Stack_N_Exists(Nirvana_Stage_Layers[i].Layer_TS_Stack) Then
			DeleteStack_N(Nirvana_Stage_Layers[i].Layer_TS_Stack)
		End If
		Nirvana_Stage_Layers[i].Layer_TS_Stack = -1

		If ImageExists(Nirvana_Stage_Layers[i].Bkg.Image_ID) Then
			DeleteImage(Nirvana_Stage_Layers[i].Bkg.Image_ID)
			Nirvana_Stage_Layers[i].Bkg.Image_ID = -1
		End If

		If Nirvana_Stage_Layers[i].LayerType = NIRVANA_LAYER_TYPE_TILEMAP Then
			DeleteTileMap(Nirvana_Stage_Layers[i].Layer_TileMap.TileMap_ID)
			DeleteTileSet(Nirvana_Stage_Layers[i].Layer_TileMap.Tileset_ID)
		ElseIf Nirvana_Stage_Layers[i].LayerType = NIRVANA_LAYER_TYPE_ISO_TILEMAP Then
			DeleteTileMap(Nirvana_Stage_Layers[i].Layer_TileMap.TileMap_ID)
			DeleteTileMap(Nirvana_Stage_Layers[i].Layer_TileMap2.TileMap_ID)
			DeleteTileSet(Nirvana_Stage_Layers[i].Layer_TileMap.Tileset_ID)
		End If

		Nirvana_Stage_Layers[i].Layer_TileMap.TileMap_ID = -1
		Nirvana_Stage_Layers[i].Layer_TileMap2.TileMap_ID = -1
		Nirvana_Stage_Layers[i].Layer_TileMap.Tileset_ID = -1

		Nirvana_Stage_Layers[i].Layer_TileMap2.Tileset_ID = -1

	Next

	While Stack_Size_N(Nirvana_Tileset_Image_Stack) > 0
		img_id = Pop_N(Nirvana_Tileset_Image_Stack)
		DeleteImage(img_id)
	Wend

	While Stack_Size_N(Nirvana_Sprite_Image_Stack) > 0
		img_id = Pop_N(Nirvana_Sprite_Image_Stack)
		DeleteImage(img_id)
	Wend

	Nirvana_Tileset_ID_0 = -1
	Nirvana_Tileset_Image_0 = -1

	ArrayFill(Nirvana_Sprite_Image_0, -1)
	Nirvana_ActiveStage.Active = FALSE

End Sub

Function Nirvana_Stage_0(vp_x, vp_y, vp_w, vp_h) As Nirvana_Stage
	Nirvana_ClearStage()

	Dim nv_stage As Nirvana_Stage
	nv_stage.Name$ = "isometric_stage"
	nv_stage.Tile_Size.Width = 64
	nv_stage.Tile_Size.Height = 32
	nv_stage.Stage_Size.Width = 100
	nv_stage.Stage_Size.Height = 100
	nv_stage.Layer_Count = 5

	'-------LAYER (ground)-------

	Nirvana_Stage_Layers[0].Name$ = "ground"
	Nirvana_Stage_Layers[0].LayerType = NIRVANA_LAYER_TYPE_ISO_TILEMAP
	Nirvana_Stage_Layers[0].Visible = TRUE
	Nirvana_Stage_Layers[0].Alpha = 255
	Nirvana_Stage_Layers[0].Scroll_Speed.X = 1
	Nirvana_Stage_Layers[0].Scroll_Speed.Y = 1
	Nirvana_Stage_Layers[0].Layer_TS_Stack = -1  ' This will be set to a stack if needed in sprite layer 

	Nirvana_Stage_Layers[0].Ref_Canvas = OpenCanvas(NIRVANA_WINDOW_WIDTH, NIRVANA_WINDOW_HEIGHT, vp_x, vp_y, vp_w, vp_h, 1)

	'------- ISO TILEMAP 1 -------
	Nirvana_Stage_Layers[0].Layer_TileMap = Nirvana_CreateTileMap("grassland", 101, 101)

	f = OpenFile(NIRVANA_DATA_DIR$ + "tm0.data", BINARY_INPUT)
	For y = 0 To 100
		For x = 0 To 100
			SetTile(Nirvana_Stage_Layers[0].Layer_TileMap.TileMap_ID, Nirvana_Read32(f), x, y)
		Next
	Next
	CloseFile(f)
	'------- ISO TILEMAP 2 -------
	Nirvana_Stage_Layers[0].Layer_TileMap2 = Nirvana_CreateTileMap("grassland", 101, 101)

	f = OpenFile(NIRVANA_DATA_DIR$ + "tm1.data", BINARY_INPUT)
	For y = 0 To 100
		For x = 0 To 100
			SetTile(Nirvana_Stage_Layers[0].Layer_TileMap2.TileMap_ID, Nirvana_Read32(f), x, y)
		Next
	Next
	CloseFile(f)

	'-------LAYER (ground2)-------

	Nirvana_Stage_Layers[1].Name$ = "ground2"
	Nirvana_Stage_Layers[1].LayerType = NIRVANA_LAYER_TYPE_ISO_TILEMAP
	Nirvana_Stage_Layers[1].Visible = TRUE
	Nirvana_Stage_Layers[1].Alpha = 255
	Nirvana_Stage_Layers[1].Scroll_Speed.X = 1
	Nirvana_Stage_Layers[1].Scroll_Speed.Y = 1
	Nirvana_Stage_Layers[1].Layer_TS_Stack = -1  ' This will be set to a stack if needed in sprite layer 

	Nirvana_Stage_Layers[1].Ref_Canvas = OpenCanvas(NIRVANA_WINDOW_WIDTH, NIRVANA_WINDOW_HEIGHT, vp_x, vp_y, vp_w, vp_h, 1)

	'------- ISO TILEMAP 1 -------
	Nirvana_Stage_Layers[1].Layer_TileMap = Nirvana_CreateTileMap("grassland", 101, 101)

	f = OpenFile(NIRVANA_DATA_DIR$ + "tm2.data", BINARY_INPUT)
	For y = 0 To 100
		For x = 0 To 100
			SetTile(Nirvana_Stage_Layers[1].Layer_TileMap.TileMap_ID, Nirvana_Read32(f), x, y)
		Next
	Next
	CloseFile(f)
	'------- ISO TILEMAP 2 -------
	Nirvana_Stage_Layers[1].Layer_TileMap2 = Nirvana_CreateTileMap("grassland", 101, 101)

	f = OpenFile(NIRVANA_DATA_DIR$ + "tm3.data", BINARY_INPUT)
	For y = 0 To 100
		For x = 0 To 100
			SetTile(Nirvana_Stage_Layers[1].Layer_TileMap2.TileMap_ID, Nirvana_Read32(f), x, y)
		Next
	Next
	CloseFile(f)

	'-------LAYER (ground3)-------

	Nirvana_Stage_Layers[2].Name$ = "ground3"
	Nirvana_Stage_Layers[2].LayerType = NIRVANA_LAYER_TYPE_ISO_TILEMAP
	Nirvana_Stage_Layers[2].Visible = TRUE
	Nirvana_Stage_Layers[2].Alpha = 255
	Nirvana_Stage_Layers[2].Scroll_Speed.X = 1
	Nirvana_Stage_Layers[2].Scroll_Speed.Y = 1
	Nirvana_Stage_Layers[2].Layer_TS_Stack = -1  ' This will be set to a stack if needed in sprite layer 

	Nirvana_Stage_Layers[2].Ref_Canvas = OpenCanvas(NIRVANA_WINDOW_WIDTH, NIRVANA_WINDOW_HEIGHT, vp_x, vp_y, vp_w, vp_h, 1)

	'------- ISO TILEMAP 1 -------
	Nirvana_Stage_Layers[2].Layer_TileMap = Nirvana_CreateTileMap("grassland", 101, 101)

	f = OpenFile(NIRVANA_DATA_DIR$ + "tm4.data", BINARY_INPUT)
	For y = 0 To 100
		For x = 0 To 100
			SetTile(Nirvana_Stage_Layers[2].Layer_TileMap.TileMap_ID, Nirvana_Read32(f), x, y)
		Next
	Next
	CloseFile(f)
	'------- ISO TILEMAP 2 -------
	Nirvana_Stage_Layers[2].Layer_TileMap2 = Nirvana_CreateTileMap("grassland", 101, 101)

	f = OpenFile(NIRVANA_DATA_DIR$ + "tm5.data", BINARY_INPUT)
	For y = 0 To 100
		For x = 0 To 100
			SetTile(Nirvana_Stage_Layers[2].Layer_TileMap2.TileMap_ID, Nirvana_Read32(f), x, y)
		Next
	Next
	CloseFile(f)

	'-------LAYER (platforms)-------

	Nirvana_Stage_Layers[3].Name$ = "platforms"
	Nirvana_Stage_Layers[3].LayerType = NIRVANA_LAYER_TYPE_ISO_TILEMAP
	Nirvana_Stage_Layers[3].Visible = TRUE
	Nirvana_Stage_Layers[3].Alpha = 255
	Nirvana_Stage_Layers[3].Scroll_Speed.X = 1
	Nirvana_Stage_Layers[3].Scroll_Speed.Y = 1
	Nirvana_Stage_Layers[3].Layer_TS_Stack = -1  ' This will be set to a stack if needed in sprite layer 

	Nirvana_Stage_Layers[3].Ref_Canvas = OpenCanvas(NIRVANA_WINDOW_WIDTH, NIRVANA_WINDOW_HEIGHT, vp_x, vp_y, vp_w, vp_h, 1)

	'------- ISO TILEMAP 1 -------
	Nirvana_Stage_Layers[3].Layer_TileMap = Nirvana_CreateTileMap("grassland", 101, 101)

	f = OpenFile(NIRVANA_DATA_DIR$ + "tm6.data", BINARY_INPUT)
	For y = 0 To 100
		For x = 0 To 100
			SetTile(Nirvana_Stage_Layers[3].Layer_TileMap.TileMap_ID, Nirvana_Read32(f), x, y)
		Next
	Next
	CloseFile(f)
	'------- ISO TILEMAP 2 -------
	Nirvana_Stage_Layers[3].Layer_TileMap2 = Nirvana_CreateTileMap("grassland", 101, 101)

	f = OpenFile(NIRVANA_DATA_DIR$ + "tm7.data", BINARY_INPUT)
	For y = 0 To 100
		For x = 0 To 100
			SetTile(Nirvana_Stage_Layers[3].Layer_TileMap2.TileMap_ID, Nirvana_Read32(f), x, y)
		Next
	Next
	CloseFile(f)

	'-------LAYER (playfield)-------

	Nirvana_Stage_Layers[4].Name$ = "playfield"
	Nirvana_Stage_Layers[4].LayerType = NIRVANA_LAYER_TYPE_SPRITE
	Nirvana_Stage_Layers[4].Visible = TRUE
	Nirvana_Stage_Layers[4].Alpha = 255
	Nirvana_Stage_Layers[4].Scroll_Speed.X = 1
	Nirvana_Stage_Layers[4].Scroll_Speed.Y = 1
	Nirvana_Stage_Layers[4].Layer_TS_Stack = -1  ' This will be set to a stack if needed in sprite layer 

	Nirvana_Stage_Layers[4].Ref_Canvas = OpenCanvasSpriteLayer(vp_x, vp_y, vp_w, vp_h)
	SetSpriteCanvasRenderPriority(Nirvana_Stage_Layers[4].Ref_Canvas, SPRITE_PRIORITY_LEAST_Y, SPRITE_ORDER_ASCENDING)
	Canvas(Nirvana_Stage_Layers[4].Ref_Canvas)
	Nirvana_Stage_Layers[4].Layer_Sprite_Count = 1
	Nirvana_Stage_Layers[4].Layer_Shape_Count = 7

	'------- SPRITE ("hero") -------
	Nirvana_Stage_Sprites[0] = Nirvana_CreateSprite("warrior", "hero")

	'Base Settings
	SetSpriteType(Nirvana_Stage_Sprites[0].Detached_Sprite_ID, SPRITE_TYPE_DYNAMIC)
	SetSpriteAnimation(Nirvana_Stage_Sprites[0].Sprite_ID, 0, -1)

	'Shape
	SetSpriteShape(Nirvana_Stage_Sprites[0].Detached_Sprite_ID, SPRITE_SHAPE_CIRCLE)
	SetSpriteShapeOffset(Nirvana_Stage_Sprites[0].Detached_Sprite_ID, -4, 21)
	SetSpriteRadius(Nirvana_Stage_Sprites[0].Detached_Sprite_ID, 19)

	'Transform
	SetSpritePosition(Nirvana_Stage_Sprites[0].Detached_Sprite_ID, 735, 414)
	SetSpriteScale(Nirvana_Stage_Sprites[0].Detached_Sprite_ID, 1, 1)
	SetSpriteRotation(Nirvana_Stage_Sprites[0].Detached_Sprite_ID, 360)

	'Render Settings
	SetSpriteAlpha(Nirvana_Stage_Sprites[0].Sprite_ID, 255)
	SetSpriteVisible(Nirvana_Stage_Sprites[0].Sprite_ID, TRUE)

	'------- SHAPE ("BOX_1") -------
	Nirvana_Stage_Shapes[0].Name$ = "BOX_1"
	Nirvana_Stage_Shapes[0].Sprite_ID = CreateSprite(-1, 1, 1)

	'Base Settings
	SetSpriteType(Nirvana_Stage_Shapes[0].Sprite_ID, SPRITE_TYPE_STATIC)
	SetSpriteSolid(Nirvana_Stage_Shapes[0].Sprite_ID, TRUE)
	'Shape
	Nirvana_Stage_Shapes[0].ShapeType = SPRITE_SHAPE_BOX
	SetSpriteShape(Nirvana_Stage_Shapes[0].Sprite_ID, Nirvana_Stage_Shapes[0].ShapeType)
	Nirvana_Stage_Shapes[0].ShapeData_Matrix = DimMatrix(4, 1)
	SetMatrixValue(Nirvana_Stage_Shapes[0].ShapeData_Matrix, 0, 0, 86)
	SetMatrixValue(Nirvana_Stage_Shapes[0].ShapeData_Matrix, 1, 0, 674)
	SetMatrixValue(Nirvana_Stage_Shapes[0].ShapeData_Matrix, 2, 0, 197)
	SetMatrixValue(Nirvana_Stage_Shapes[0].ShapeData_Matrix, 3, 0, 79)
	SetSpriteShapeOffset(Nirvana_Stage_Shapes[0].Sprite_ID, 86, 674)
	SetSpriteBox(Nirvana_Stage_Shapes[0].Sprite_ID, 197, 79)

	'Transform
	SetSpritePosition(Nirvana_Stage_Shapes[0].Sprite_ID,  0, 0) 'Set to (0,0) so that offset will be world position
	SetSpriteVisible(Nirvana_Stage_Shapes[0].Sprite_ID, FALSE) 'Image is -1 so it wouldn't render anyway

	'------- SHAPE ("POLYGON_1") -------
	Nirvana_Stage_Shapes[1].Name$ = "POLYGON_1"
	Nirvana_Stage_Shapes[1].Sprite_ID = CreateSprite(-1, 1, 1)

	'Base Settings
	SetSpriteType(Nirvana_Stage_Shapes[1].Sprite_ID, SPRITE_TYPE_STATIC)
	SetSpriteSolid(Nirvana_Stage_Shapes[1].Sprite_ID, TRUE)
	'Shape
	Nirvana_Stage_Shapes[1].ShapeType = SPRITE_SHAPE_POLYGON
	SetSpriteShape(Nirvana_Stage_Shapes[1].Sprite_ID, Nirvana_Stage_Shapes[1].ShapeType)
	Dim stage_shape_x_1[6]
	Dim stage_shape_y_1[6]
	Nirvana_Stage_Shapes[1].ShapeData_Matrix = DimMatrix(2, 6)

	stage_shape_x_1[0] = 428
	stage_shape_y_1[0] = 235
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 0, 0, stage_shape_x_1[0])
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 1, 0, stage_shape_y_1[0])

	stage_shape_x_1[1] = 177
	stage_shape_y_1[1] = 358
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 0, 1, stage_shape_x_1[1])
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 1, 1, stage_shape_y_1[1])

	stage_shape_x_1[2] = 105
	stage_shape_y_1[2] = 313
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 0, 2, stage_shape_x_1[2])
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 1, 2, stage_shape_y_1[2])

	stage_shape_x_1[3] = 108
	stage_shape_y_1[3] = 283
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 0, 3, stage_shape_x_1[3])
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 1, 3, stage_shape_y_1[3])

	stage_shape_x_1[4] = 325
	stage_shape_y_1[4] = 180
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 0, 4, stage_shape_x_1[4])
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 1, 4, stage_shape_y_1[4])

	stage_shape_x_1[5] = 404
	stage_shape_y_1[5] = 188
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 0, 5, stage_shape_x_1[5])
	SetMatrixValue(Nirvana_Stage_Shapes[1].ShapeData_Matrix, 1, 5, stage_shape_y_1[5])

	SetSpritePolygon(Nirvana_Stage_Shapes[1].Sprite_ID, stage_shape_x_1, stage_shape_y_1, 6)

	'Transform
	SetSpritePosition(Nirvana_Stage_Shapes[1].Sprite_ID,  0, 0) 'Set to (0,0) so that offset will be world position
	SetSpriteVisible(Nirvana_Stage_Shapes[1].Sprite_ID, FALSE) 'Image is -1 so it wouldn't render anyway

	'------- SHAPE ("POLYGON_2") -------
	Nirvana_Stage_Shapes[2].Name$ = "POLYGON_2"
	Nirvana_Stage_Shapes[2].Sprite_ID = CreateSprite(-1, 1, 1)

	'Base Settings
	SetSpriteType(Nirvana_Stage_Shapes[2].Sprite_ID, SPRITE_TYPE_STATIC)
	SetSpriteSolid(Nirvana_Stage_Shapes[2].Sprite_ID, TRUE)
	'Shape
	Nirvana_Stage_Shapes[2].ShapeType = SPRITE_SHAPE_POLYGON
	SetSpriteShape(Nirvana_Stage_Shapes[2].Sprite_ID, Nirvana_Stage_Shapes[2].ShapeType)
	Dim stage_shape_x_2[6]
	Dim stage_shape_y_2[6]
	Nirvana_Stage_Shapes[2].ShapeData_Matrix = DimMatrix(2, 6)

	stage_shape_x_2[0] = 318
	stage_shape_y_2[0] = 280
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 0, 0, stage_shape_x_2[0])
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 1, 0, stage_shape_y_2[0])

	stage_shape_x_2[1] = 168
	stage_shape_y_2[1] = 351
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 0, 1, stage_shape_x_2[1])
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 1, 1, stage_shape_y_2[1])

	stage_shape_x_2[2] = 169
	stage_shape_y_2[2] = 381
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 0, 2, stage_shape_x_2[2])
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 1, 2, stage_shape_y_2[2])

	stage_shape_x_2[3] = 355
	stage_shape_y_2[3] = 479
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 0, 3, stage_shape_x_2[3])
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 1, 3, stage_shape_y_2[3])

	stage_shape_x_2[4] = 451
	stage_shape_y_2[4] = 486
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 0, 4, stage_shape_x_2[4])
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 1, 4, stage_shape_y_2[4])

	stage_shape_x_2[5] = 571
	stage_shape_y_2[5] = 429
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 0, 5, stage_shape_x_2[5])
	SetMatrixValue(Nirvana_Stage_Shapes[2].ShapeData_Matrix, 1, 5, stage_shape_y_2[5])

	SetSpritePolygon(Nirvana_Stage_Shapes[2].Sprite_ID, stage_shape_x_2, stage_shape_y_2, 6)

	'Transform
	SetSpritePosition(Nirvana_Stage_Shapes[2].Sprite_ID,  0, 0) 'Set to (0,0) so that offset will be world position
	SetSpriteVisible(Nirvana_Stage_Shapes[2].Sprite_ID, FALSE) 'Image is -1 so it wouldn't render anyway

	'------- SHAPE ("POLYGON_3") -------
	Nirvana_Stage_Shapes[3].Name$ = "POLYGON_3"
	Nirvana_Stage_Shapes[3].Sprite_ID = CreateSprite(-1, 1, 1)

	'Base Settings
	SetSpriteType(Nirvana_Stage_Shapes[3].Sprite_ID, SPRITE_TYPE_STATIC)
	SetSpriteSolid(Nirvana_Stage_Shapes[3].Sprite_ID, TRUE)
	'Shape
	Nirvana_Stage_Shapes[3].ShapeType = SPRITE_SHAPE_POLYGON
	SetSpriteShape(Nirvana_Stage_Shapes[3].Sprite_ID, Nirvana_Stage_Shapes[3].ShapeType)
	Dim stage_shape_x_3[5]
	Dim stage_shape_y_3[5]
	Nirvana_Stage_Shapes[3].ShapeData_Matrix = DimMatrix(2, 5)

	stage_shape_x_3[0] = 487
	stage_shape_y_3[0] = 264
	SetMatrixValue(Nirvana_Stage_Shapes[3].ShapeData_Matrix, 0, 0, stage_shape_x_3[0])
	SetMatrixValue(Nirvana_Stage_Shapes[3].ShapeData_Matrix, 1, 0, stage_shape_y_3[0])

	stage_shape_x_3[1] = 378
	stage_shape_y_3[1] = 320
	SetMatrixValue(Nirvana_Stage_Shapes[3].ShapeData_Matrix, 0, 1, stage_shape_x_3[1])
	SetMatrixValue(Nirvana_Stage_Shapes[3].ShapeData_Matrix, 1, 1, stage_shape_y_3[1])

	stage_shape_x_3[2] = 562
	stage_shape_y_3[2] = 429
	SetMatrixValue(Nirvana_Stage_Shapes[3].ShapeData_Matrix, 0, 2, stage_shape_x_3[2])
	SetMatrixValue(Nirvana_Stage_Shapes[3].ShapeData_Matrix, 1, 2, stage_shape_y_3[2])

	stage_shape_x_3[3] = 628
	stage_shape_y_3[3] = 401
	SetMatrixValue(Nirvana_Stage_Shapes[3].ShapeData_Matrix, 0, 3, stage_shape_x_3[3])
	SetMatrixValue(Nirvana_Stage_Shapes[3].ShapeData_Matrix, 1, 3, stage_shape_y_3[3])

	stage_shape_x_3[4] = 628
	stage_shape_y_3[4] = 333
	SetMatrixValue(Nirvana_Stage_Shapes[3].ShapeData_Matrix, 0, 4, stage_shape_x_3[4])
	SetMatrixValue(Nirvana_Stage_Shapes[3].ShapeData_Matrix, 1, 4, stage_shape_y_3[4])

	SetSpritePolygon(Nirvana_Stage_Shapes[3].Sprite_ID, stage_shape_x_3, stage_shape_y_3, 5)

	'Transform
	SetSpritePosition(Nirvana_Stage_Shapes[3].Sprite_ID,  0, 0) 'Set to (0,0) so that offset will be world position
	SetSpriteVisible(Nirvana_Stage_Shapes[3].Sprite_ID, FALSE) 'Image is -1 so it wouldn't render anyway

	'------- SHAPE ("BOX_2") -------
	Nirvana_Stage_Shapes[4].Name$ = "BOX_2"
	Nirvana_Stage_Shapes[4].Sprite_ID = CreateSprite(-1, 1, 1)

	'Base Settings
	SetSpriteType(Nirvana_Stage_Shapes[4].Sprite_ID, SPRITE_TYPE_STATIC)
	SetSpriteSolid(Nirvana_Stage_Shapes[4].Sprite_ID, TRUE)
	'Shape
	Nirvana_Stage_Shapes[4].ShapeType = SPRITE_SHAPE_BOX
	SetSpriteShape(Nirvana_Stage_Shapes[4].Sprite_ID, Nirvana_Stage_Shapes[4].ShapeType)
	Nirvana_Stage_Shapes[4].ShapeData_Matrix = DimMatrix(4, 1)
	SetMatrixValue(Nirvana_Stage_Shapes[4].ShapeData_Matrix, 0, 0, 1024)
	SetMatrixValue(Nirvana_Stage_Shapes[4].ShapeData_Matrix, 1, 0, 270)
	SetMatrixValue(Nirvana_Stage_Shapes[4].ShapeData_Matrix, 2, 0, 63)
	SetMatrixValue(Nirvana_Stage_Shapes[4].ShapeData_Matrix, 3, 0, 68)
	SetSpriteShapeOffset(Nirvana_Stage_Shapes[4].Sprite_ID, 1024, 270)
	SetSpriteBox(Nirvana_Stage_Shapes[4].Sprite_ID, 63, 68)

	'Transform
	SetSpritePosition(Nirvana_Stage_Shapes[4].Sprite_ID,  0, 0) 'Set to (0,0) so that offset will be world position
	SetSpriteVisible(Nirvana_Stage_Shapes[4].Sprite_ID, FALSE) 'Image is -1 so it wouldn't render anyway

	'------- SHAPE ("POLYGON_4") -------
	Nirvana_Stage_Shapes[5].Name$ = "POLYGON_4"
	Nirvana_Stage_Shapes[5].Sprite_ID = CreateSprite(-1, 1, 1)

	'Base Settings
	SetSpriteType(Nirvana_Stage_Shapes[5].Sprite_ID, SPRITE_TYPE_STATIC)
	SetSpriteSolid(Nirvana_Stage_Shapes[5].Sprite_ID, TRUE)
	'Shape
	Nirvana_Stage_Shapes[5].ShapeType = SPRITE_SHAPE_POLYGON
	SetSpriteShape(Nirvana_Stage_Shapes[5].Sprite_ID, Nirvana_Stage_Shapes[5].ShapeType)
	Dim stage_shape_x_5[4]
	Dim stage_shape_y_5[4]
	Nirvana_Stage_Shapes[5].ShapeData_Matrix = DimMatrix(2, 4)

	stage_shape_x_5[0] = 1154
	stage_shape_y_5[0] = 205
	SetMatrixValue(Nirvana_Stage_Shapes[5].ShapeData_Matrix, 0, 0, stage_shape_x_5[0])
	SetMatrixValue(Nirvana_Stage_Shapes[5].ShapeData_Matrix, 1, 0, stage_shape_y_5[0])

	stage_shape_x_5[1] = 1249
	stage_shape_y_5[1] = 248
	SetMatrixValue(Nirvana_Stage_Shapes[5].ShapeData_Matrix, 0, 1, stage_shape_x_5[1])
	SetMatrixValue(Nirvana_Stage_Shapes[5].ShapeData_Matrix, 1, 1, stage_shape_y_5[1])

	stage_shape_x_5[2] = 1305
	stage_shape_y_5[2] = 223
	SetMatrixValue(Nirvana_Stage_Shapes[5].ShapeData_Matrix, 0, 2, stage_shape_x_5[2])
	SetMatrixValue(Nirvana_Stage_Shapes[5].ShapeData_Matrix, 1, 2, stage_shape_y_5[2])

	stage_shape_x_5[3] = 1224
	stage_shape_y_5[3] = 187
	SetMatrixValue(Nirvana_Stage_Shapes[5].ShapeData_Matrix, 0, 3, stage_shape_x_5[3])
	SetMatrixValue(Nirvana_Stage_Shapes[5].ShapeData_Matrix, 1, 3, stage_shape_y_5[3])

	SetSpritePolygon(Nirvana_Stage_Shapes[5].Sprite_ID, stage_shape_x_5, stage_shape_y_5, 4)

	'Transform
	SetSpritePosition(Nirvana_Stage_Shapes[5].Sprite_ID,  0, 0) 'Set to (0,0) so that offset will be world position
	SetSpriteVisible(Nirvana_Stage_Shapes[5].Sprite_ID, FALSE) 'Image is -1 so it wouldn't render anyway

	'------- SHAPE ("POLYGON_5") -------
	Nirvana_Stage_Shapes[6].Name$ = "POLYGON_5"
	Nirvana_Stage_Shapes[6].Sprite_ID = CreateSprite(-1, 1, 1)

	'Base Settings
	SetSpriteType(Nirvana_Stage_Shapes[6].Sprite_ID, SPRITE_TYPE_STATIC)
	SetSpriteSolid(Nirvana_Stage_Shapes[6].Sprite_ID, TRUE)
	'Shape
	Nirvana_Stage_Shapes[6].ShapeType = SPRITE_SHAPE_POLYGON
	SetSpriteShape(Nirvana_Stage_Shapes[6].Sprite_ID, Nirvana_Stage_Shapes[6].ShapeType)
	Dim stage_shape_x_6[4]
	Dim stage_shape_y_6[4]
	Nirvana_Stage_Shapes[6].ShapeData_Matrix = DimMatrix(2, 4)

	stage_shape_x_6[0] = 807
	stage_shape_y_6[0] = 253
	SetMatrixValue(Nirvana_Stage_Shapes[6].ShapeData_Matrix, 0, 0, stage_shape_x_6[0])
	SetMatrixValue(Nirvana_Stage_Shapes[6].ShapeData_Matrix, 1, 0, stage_shape_y_6[0])

	stage_shape_x_6[1] = 866
	stage_shape_y_6[1] = 284
	SetMatrixValue(Nirvana_Stage_Shapes[6].ShapeData_Matrix, 0, 1, stage_shape_x_6[1])
	SetMatrixValue(Nirvana_Stage_Shapes[6].ShapeData_Matrix, 1, 1, stage_shape_y_6[1])

	stage_shape_x_6[2] = 956
	stage_shape_y_6[2] = 242
	SetMatrixValue(Nirvana_Stage_Shapes[6].ShapeData_Matrix, 0, 2, stage_shape_x_6[2])
	SetMatrixValue(Nirvana_Stage_Shapes[6].ShapeData_Matrix, 1, 2, stage_shape_y_6[2])

	stage_shape_x_6[3] = 913
	stage_shape_y_6[3] = 219
	SetMatrixValue(Nirvana_Stage_Shapes[6].ShapeData_Matrix, 0, 3, stage_shape_x_6[3])
	SetMatrixValue(Nirvana_Stage_Shapes[6].ShapeData_Matrix, 1, 3, stage_shape_y_6[3])

	SetSpritePolygon(Nirvana_Stage_Shapes[6].Sprite_ID, stage_shape_x_6, stage_shape_y_6, 4)

	'Transform
	SetSpritePosition(Nirvana_Stage_Shapes[6].Sprite_ID,  0, 0) 'Set to (0,0) so that offset will be world position
	SetSpriteVisible(Nirvana_Stage_Shapes[6].Sprite_ID, FALSE) 'Image is -1 so it wouldn't render anyway

	'------- TILE SPRITES  -------
	Nirvana_Tileset_0()
	Cut_Start_Index = 0
	Nirvana_Stage_Layers[4].Layer_TS_Stack = CreateStack_N()
	cut_index = Cut_Start_Index + 0
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 64, 576)
	SetSpriteGravityScale( t_sprite, 0)

	cut_index = Cut_Start_Index + 4
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 640, 576)
	SetSpriteGravityScale( t_sprite, 0)

	cut_index = Cut_Start_Index + 4
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 512, 480)
	SetSpriteGravityScale( t_sprite, 0)

	cut_index = Cut_Start_Index + 4
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 192, 352)
	SetSpriteGravityScale( t_sprite, 0)

	cut_index = Cut_Start_Index + 4
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 576, 320)
	SetSpriteGravityScale( t_sprite, 0)

	cut_index = Cut_Start_Index + 4
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 896, 480)
	SetSpriteGravityScale( t_sprite, 0)

	cut_index = Cut_Start_Index + 5
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 320, 384)
	SetSpriteGravityScale( t_sprite, 0)

	cut_index = Cut_Start_Index + 5
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 64, 32)
	SetSpriteGravityScale( t_sprite, 0)

	cut_index = Cut_Start_Index + 5
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 640, 32)
	SetSpriteGravityScale( t_sprite, 0)

	cut_index = Cut_Start_Index + 6
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 768, 128)
	SetSpriteGravityScale( t_sprite, 0)

	cut_index = Cut_Start_Index + 7
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 1152, 96)
	SetSpriteGravityScale( t_sprite, 0)

	cut_index = Cut_Start_Index + 9
	t_sprite = CreateSprite(Nirvana_Tileset_Cuts[cut_index].Image_ID, Nirvana_Tileset_Cuts[cut_index].NumCols * 64, Nirvana_Tileset_Cuts[cut_index].NumRows * 32)
	Push_N(Nirvana_Stage_Layers[4].Layer_TS_Stack, t_sprite)
	SetSpritePosition( t_sprite, 1024, 224)
	SetSpriteGravityScale( t_sprite, 0)


	Return nv_stage
End Function



Function Nirvana_LoadStage(stage_name$, viewport_x, viewport_y, viewport_w, viewport_h)
	GetWindowSize(NIRVANA_WINDOW_WIDTH, NIRVANA_WINDOW_HEIGHT)

	Select Case stage_name$

	Case "isometric_stage"
		Nirvana_ActiveStage = Nirvana_Stage_0(viewport_x, viewport_y, viewport_w, viewport_h)

	Default
		Return FALSE
	End Select

	Nirvana_ActiveStage.Active = TRUE
	Nirvana_ActiveStage.Stage_Offset.X = 0
	Nirvana_ActiveStage.Stage_Offset.Y = 0
	Nirvana_ActiveStage.Viewport_Size.Width = viewport_w
	Nirvana_ActiveStage.Viewport_Size.Height = viewport_h
	Return TRUE
End Function


