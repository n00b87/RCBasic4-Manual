NIRVANA_SPRITE_DIR$ = NIRVANA_PROJECT_BASE_DIR$ + NIRVANA_PATH_SEPARATOR$ + "sprites" + NIRVANA_PATH_SEPARATOR$


Type Nirvana_Sprite
Dim Name$
Dim BaseName$
Dim Sprite_ID
Dim Detached_Sprite_ID
Dim IsDetached
Dim Animation_Name_Index
Dim Animation_Count
End Type

Dim Nirvana_Sprite_Image_Stack : Nirvana_Sprite_Image_Stack = CreateStack_N()

Dim Nirvana_Sprite_Image_0[1] : ArrayFill(Nirvana_Sprite_Image_0, -1)
Dim Nirvana_Sprite_Image_Source_0$[1]



Nirvana_Sprite_Image_Source_0$[0] = NIRVANA_SPRITE_DIR$ + "WalkForward_Sword_Body.png"


Dim Nirvana_SpriteAnimationNames$[16]

Nirvana_SpriteAnimationNames$[0] = "WALK_0"
Nirvana_SpriteAnimationNames$[1] = "WALK_45"
Nirvana_SpriteAnimationNames$[2] = "WALK_90"
Nirvana_SpriteAnimationNames$[3] = "WALK_135"
Nirvana_SpriteAnimationNames$[4] = "WALK_180"
Nirvana_SpriteAnimationNames$[5] = "WALK_225"
Nirvana_SpriteAnimationNames$[6] = "WALK_270"
Nirvana_SpriteAnimationNames$[7] = "WALK_315"
Nirvana_SpriteAnimationNames$[8] = "IDLE_0"
Nirvana_SpriteAnimationNames$[9] = "IDLE_45"
Nirvana_SpriteAnimationNames$[10] = "IDLE_90"
Nirvana_SpriteAnimationNames$[11] = "IDLE_135"
Nirvana_SpriteAnimationNames$[12] = "IDLE_180"
Nirvana_SpriteAnimationNames$[13] = "IDLE_225"
Nirvana_SpriteAnimationNames$[14] = "IDLE_270"
Nirvana_SpriteAnimationNames$[15] = "IDLE_315"


Function Nirvana_SpriteDef_0(ByRef detached_spr_id)
	For i = 0 To 0
		If Nirvana_Sprite_Image_0[i] < 0 Then
			Nirvana_Sprite_Image_0[i] = LoadImage(Nirvana_Sprite_Image_Source_0$[i])
			If Nirvana_Sprite_Image_0[i] >= 0 Then
				Push_N(Nirvana_Sprite_Image_Stack, Nirvana_Sprite_Image_0[i])
			End If
		End If

	Next
	spr_id = CreateSprite(Nirvana_Sprite_Image_0[0], 180, 180)

	'-------ANIMATIONS-------

	spr_animation1 = CreateSpriteAnimation(spr_id, 24, 20)

	SetSpriteAnimationFrame(spr_id, spr_animation1, 0, 0)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 1, 1)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 2, 2)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 3, 3)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 4, 4)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 5, 5)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 6, 6)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 7, 7)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 8, 8)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 9, 9)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 10, 10)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 11, 11)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 12, 12)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 13, 13)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 14, 14)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 15, 15)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 16, 16)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 17, 17)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 18, 18)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 19, 19)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 20, 20)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 21, 21)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 22, 22)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 23, 23)

	spr_animation2 = CreateSpriteAnimation(spr_id, 24, 20)

	SetSpriteAnimationFrame(spr_id, spr_animation2, 0, 24)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 1, 25)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 2, 26)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 3, 27)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 4, 28)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 5, 29)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 6, 30)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 7, 31)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 8, 32)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 9, 33)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 10, 34)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 11, 35)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 12, 36)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 13, 37)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 14, 38)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 15, 39)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 16, 40)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 17, 41)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 18, 42)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 19, 43)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 20, 44)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 21, 45)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 22, 46)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 23, 47)

	spr_animation3 = CreateSpriteAnimation(spr_id, 24, 20)

	SetSpriteAnimationFrame(spr_id, spr_animation3, 0, 48)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 1, 49)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 2, 50)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 3, 51)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 4, 52)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 5, 53)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 6, 54)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 7, 55)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 8, 56)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 9, 57)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 10, 58)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 11, 59)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 12, 60)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 13, 61)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 14, 62)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 15, 63)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 16, 64)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 17, 65)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 18, 66)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 19, 67)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 20, 68)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 21, 69)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 22, 70)
	SetSpriteAnimationFrame(spr_id, spr_animation3, 23, 71)

	spr_animation4 = CreateSpriteAnimation(spr_id, 24, 20)

	SetSpriteAnimationFrame(spr_id, spr_animation4, 0, 72)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 1, 73)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 2, 74)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 3, 75)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 4, 76)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 5, 77)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 6, 78)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 7, 79)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 8, 80)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 9, 81)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 10, 82)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 11, 83)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 12, 84)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 13, 85)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 14, 86)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 15, 87)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 16, 88)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 17, 89)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 18, 90)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 19, 91)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 20, 92)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 21, 93)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 22, 94)
	SetSpriteAnimationFrame(spr_id, spr_animation4, 23, 95)

	spr_animation5 = CreateSpriteAnimation(spr_id, 24, 20)

	SetSpriteAnimationFrame(spr_id, spr_animation5, 0, 96)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 1, 97)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 2, 98)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 3, 99)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 4, 100)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 5, 101)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 6, 102)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 7, 103)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 8, 104)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 9, 105)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 10, 106)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 11, 107)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 12, 108)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 13, 109)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 14, 110)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 15, 111)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 16, 112)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 17, 113)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 18, 114)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 19, 115)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 20, 116)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 21, 117)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 22, 118)
	SetSpriteAnimationFrame(spr_id, spr_animation5, 23, 119)

	spr_animation6 = CreateSpriteAnimation(spr_id, 24, 20)

	SetSpriteAnimationFrame(spr_id, spr_animation6, 0, 120)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 1, 121)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 2, 122)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 3, 123)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 4, 124)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 5, 125)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 6, 126)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 7, 127)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 8, 128)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 9, 129)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 10, 130)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 11, 131)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 12, 132)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 13, 133)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 14, 134)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 15, 135)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 16, 136)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 17, 137)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 18, 138)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 19, 139)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 20, 140)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 21, 141)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 22, 142)
	SetSpriteAnimationFrame(spr_id, spr_animation6, 23, 143)

	spr_animation7 = CreateSpriteAnimation(spr_id, 24, 20)

	SetSpriteAnimationFrame(spr_id, spr_animation7, 0, 144)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 1, 145)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 2, 146)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 3, 147)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 4, 148)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 5, 149)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 6, 150)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 7, 151)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 8, 152)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 9, 153)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 10, 154)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 11, 155)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 12, 156)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 13, 157)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 14, 158)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 15, 159)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 16, 160)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 17, 161)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 18, 162)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 19, 163)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 20, 164)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 21, 165)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 22, 166)
	SetSpriteAnimationFrame(spr_id, spr_animation7, 23, 167)

	spr_animation8 = CreateSpriteAnimation(spr_id, 24, 20)

	SetSpriteAnimationFrame(spr_id, spr_animation8, 0, 168)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 1, 169)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 2, 170)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 3, 171)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 4, 172)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 5, 173)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 6, 174)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 7, 175)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 8, 176)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 9, 177)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 10, 178)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 11, 179)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 12, 180)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 13, 181)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 14, 182)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 15, 183)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 16, 184)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 17, 185)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 18, 186)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 19, 187)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 20, 188)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 21, 189)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 22, 190)
	SetSpriteAnimationFrame(spr_id, spr_animation8, 23, 191)

	spr_animation9 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation9, 0, 0)

	spr_animation10 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation10, 0, 24)

	spr_animation11 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation11, 0, 48)

	spr_animation12 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation12, 0, 72)

	spr_animation13 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation13, 0, 96)

	spr_animation14 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation14, 0, 120)

	spr_animation15 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation15, 0, 144)

	spr_animation16 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation16, 0, 168)


	'-------SHAPE-------
	detached_spr_id = CreateSprite(-1, 180, 180)

	SetSpriteShape(detached_spr_id, SPRITE_SHAPE_CIRCLE)
	SetSpriteShapeOffset(detached_spr_id, -4, 21)
	SetSpriteRadius(detached_spr_id, 19)

	Return spr_id
End Function


Function Nirvana_CreateSprite(base_name$, sprite_name$) As Nirvana_Sprite
	Dim nv_sprite As Nirvana_Sprite
	nv_sprite.Name$ = sprite_name$
	nv_sprite.BaseName$ = base_name$

	Select Case base_name$

	Case "warrior"
		nv_sprite.Sprite_ID = Nirvana_SpriteDef_0(nv_sprite.Detached_Sprite_ID)
		nv_sprite.IsDetached = TRUE
		nv_sprite.Animation_Name_Index = 0
		nv_sprite.Animation_Count = 17

	End Select

	Return nv_sprite
End Function
