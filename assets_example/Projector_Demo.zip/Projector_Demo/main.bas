title$ = "Projector Test"
w = 640
h = 480
fullscreen = FALSE
vsync = FALSE

'Open a graphics window
OpenWindow( title$, w, h, fullscreen, vsync )

'Lock the window to 60 fps
SetFPS(60)

m3d = OpenCanvas3D(0, 0, w, h, 1)


'Open a canvas to display instructions on
ui_canvas = OpenCanvas(w, h, 0, 0, w, h, 1)

'Set canvas order so it displays on top of the 3D scene
SetCanvasZ(ui_canvas, 0)

'Set the ui canvas active
Canvas(ui_canvas)

'Load font and set it as the active font for text drawing
f_mono = LoadFont("media/FreeMono.ttf", 12)
SetFont(f_mono)

'Set the drawing color to white
SetColor(RGB(255,255,255))

'Display the instructions on the ui canvas
DrawText("Press 1 through 6 to control camera", 10, 10)




Canvas(m3d)


texture1 = LoadImage("media/Batman.tga")
texture2 = LoadImage("media/grate_project.tga")

'Create a projector and set a texture for it
projector1 = CreateProjectorActor()
SetProjectorTexture(projector1, texture1)
SetProjectorFOV(projector1, 5)
SetActorPosition(projector1, -11, 45, -32)
SetProjectorTarget(projector1, -11, 0, -32)

'Create a projector and set a texture for it
projector2 = CreateProjectorActor()
SetProjectorTexture(projector2, texture2)
SetProjectorFOV(projector2, 70)
SetActorPosition(projector2, 11, 45, -32)
SetProjectorTarget(projector2, 11, 0, -32)

'Create a projector and set a texture for it
projector3 = CreateProjectorActor()
SetProjectorTexture(projector3, texture2)
SetProjectorFOV(projector3, 70)
SetActorPosition(projector3, -11, 45, 32)
SetProjectorTarget(projector3, -11, 0, 32)

'Create a projector and set a texture for it
projector4 = CreateProjectorActor()
SetProjectorTexture(projector4, texture2)
SetProjectorFOV(projector4, 70)
SetActorPosition(projector3, 11, 45, 32)
SetProjectorTarget(projector3, 11, 0, 32)

'Create a point light to light the entire scene
light = CreateLightActor()
SetLightType(light, LIGHT_TYPE_POINT)
SetActorPosition(light, 0, 128, 128)

'load the main scene mesh and add it to all 4 projectors
map_mesh = LoadMesh("media/scene.b3d")
map = CreateOctreeActor(map_mesh)
AddProjectorEffectActor(projector1, map)
AddProjectorEffectActor(projector2, map)
AddProjectorEffectActor(projector3, map)
AddProjectorEffectActor(projector4, map)
map_material = GetActorMaterial(map, 2)
SetMaterialLighting(map_material, FALSE)


'Load the glow mesh for the scene above the ground
glow_mesh = LoadMesh("media/glow.b3d")
glow = CreateAnimatedActor(glow_mesh)
SetActorMaterialFlag(glow, MATERIAL_FLAG_LIGHTING, FALSE)
SetActorMaterialType(glow, MATERIAL_TYPE_TRANSPARENT_ADD_COLOR)


'Load audi mesh and Create an animated actor
audi_mesh = LoadMesh("media/audi.b3d")
audi = CreateAnimatedActor(audi_mesh)
AddProjectorEffectActor(projector1, audi)
AddProjectorEffectActor(projector2, audi)
AddProjectorEffectActor(projector4, audi)
SetActorPosition(audi, 20, 0, 45) ' To (20, 0, -128)
audi_start = 45
audi_end = -128
audi_speed = -1


'Load jeep mesh and create an animated actor
jeep_mesh = LoadMesh("media/jeep.b3d")
jeep = CreateAnimatedActor(jeep_mesh)
AddProjectorEffectActor(projector1, jeep)
AddProjectorEffectActor(projector3, jeep)
SetActorPosition(jeep, -20, 0, 25) ' To (-20, 0, -128)
jeep_start = 25
jeep_end = -128
jeep_speed = -1


projector_mesh = LoadMesh("media/cam.b3d")
projector_object = CreateAnimatedActor(projector_mesh)
SetActorPosition(projector_object, -11, 45, -32)


Canvas(m3d)
SetCameraPosition(56, 32, -77)
SetCameraRotation(18, -38, 0)


Dim px, py, pz
Dim target_x, target_y, target_z

Dim vx, vy, vz

While Not Key(K_ESCAPE)
	'Move Audi
	TranslateActorWorld(audi, 0, 0, audi_speed)
	GetActorPosition(audi, vx, vy, vz)
	
	If audi_speed < 0 And vz <= audi_end Then
		audi_speed = 1
	ElseIf audi_speed > 0 And vz >= audi_start Then
		audi_speed = -1
	End If

	'Move Jeep
	TranslateActorWorld(jeep, 0, 0, jeep_speed)
	GetActorPosition(jeep, vx, vy, vz)
	
	If jeep_speed < 0 And vz <= jeep_end Then
		jeep_speed = 1
	ElseIf jeep_speed > 0 And vz >= jeep_start Then
		jeep_speed = -1
	End If
	
	GetActorPosition(projector_object, px, py, pz)
	GetProjectorTarget(projector1, target_x, target_y, target_z)
	fov = GetProjectorFOV(projector1)
	
	' Turn the projector mesh.
	toTarget_x = target_x - px
	toTarget_y = target_y - py
	toTarget_z = target_z - pz
	
	Dim hx, hy, hz
	GetHorizontalAngle(toTarget_x, toTarget_y, toTarget_z, hx, hy, hz)
	
	SetActorRotation(projector_object, hx, hy, hz)

	' Control of the projector (only the 1)
	If Key(K_1) Then
		SetProjectorTarget(projector1, target_x, target_y, target_z + 0.1)
	End If
	
	If Key(K_2) Then
		SetProjectorTarget(projector1, target_x, target_y, target_z - 0.1)
	End If
	
	If Key(K_3) Then
		SetProjectorTarget(projector1, target_x + 0.1, target_y, target_z)
	End If
	
	If Key(K_4) Then
		SetProjectorTarget(projector1, target_x - 0.1, target_y, target_z)
	End If
	
	If Key(K_5) Then
		SetProjectorFOV(projector1, fov + 0.001)
	End If
	
	If Key(K_6) Then
		SetProjectorFOV(projector1, fov - 0.001)
	End If
	
	Update()
Wend


 