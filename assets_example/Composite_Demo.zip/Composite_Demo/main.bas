title$ = "Template"
w = 640
h = 480
fullscreen = FALSE
vsync = FALSE

'Open a graphics window
OpenWindow( title$, w, h, fullscreen, vsync )

'Lock the window to 60 fps
SetFPS(60)


'Lock the window to 60 fps
SetFPS(60)


'Open a 3D canvas to view the 3D scene
m3d = OpenCanvas3D(0, 0, w, h, 1)

'Open a canvas to display instructions on
ui_canvas = OpenCanvas(w, h, 0, 0, w, h, 1)

'Set canvas order so it displays on top of the 3D scene
SetCanvasZ(ui_canvas, 0)

'Set the ui canvas active
Canvas(ui_canvas)

'Load font and set it as the active font for text drawing
f_mono = LoadFont("FreeMono.ttf", 12)
SetFont(f_mono)

'Set the drawing color to white
SetColor(RGB(255,255,255))

'Display the instructions on the ui canvas
DrawText("Press 1 to apply an impulse to the actor", 10, 10)
DrawText("Press 2 to rotate the cylinder", 10, 30)
DrawText("Press Backspace to remove the cylinder from the composite actor", 10, 50)



'Set the 3D canvas as active
Canvas(m3d)

'Set the clear color, by default its black so we want something lighter
SetClearColor(RGB(100,100,255))


'Create a cube
cube = CreateCubeActor( 15 )
cube_material = CreateMaterial()
SetMaterialType(cube_material, FX_MATERIAL_TYPE_NORMAL_BLEND)
SetMaterialLighting(cube_material, FALSE)
SetActorMaterial(cube, 0, cube_material)


'Create a Cylinder
cylinder_mesh = CreateCylinderMesh(5, 20, 6, RGB(120, 255, 120), TRUE)
cylinder_texture = LoadImage("tile_026_Height.png")

cylinder_actor = CreateAnimatedActor(cylinder_mesh)
SetActorShape(cylinder_actor, ACTOR_SHAPE_CYLINDER, 1)
cylinder_material = CreateMaterial()
SetMaterialLighting(cylinder_material, FALSE)
SetMaterialTexture(cylinder_material, 0, cylinder_texture)
SetActorMaterial(cylinder_actor, 0, cylinder_material)
SetActorSolid(cylinder_actor, TRUE)


'Create a composite actor
composite_actor = CreateCompositeActor()
SetActorSolid(composite_actor, TRUE)

'Create a transform matrix for the cube
cube_t = DimMatrix(4, 4)
SetIdentityMatrix(cube_t, 4)
SetMatrixTranslation(cube_t, 0, 40, 0)

'Add the cube as a child to composite_actor
cube_index = AddCompositeChild(composite_actor, cube, cube_t)

'Create a transform for the cylinder
cylinder_t = DimMatrix(4, 4)
SetIdentityMatrix(cylinder_t, 4)
SetMatrixTranslation(cylinder_t, -30, 20, 0)
SetMatrixRotation(cylinder_t, 90, 0, 0)

'Add the cylinder as a child to composite_actor
cylinder_index = AddCompositeChild(composite_actor, cylinder_actor, cylinder_t)



'Set Composite actor position  NOTE: Now that the cube and cylinder are part of composite_actor they will both be moved with it
SetActorPosition(composite_actor, 0, 100, 0)
RotateActor(composite_actor, 0, 0, 110)

'Set the gravity for the actor
SetActorGravity(composite_actor, 0, -5, 0)

'Create a ground plane
plane_mesh = CreatePlaneMesh(1000, 1000, 10, 10, 10, 10)
plane = CreateAnimatedActor(plane_mesh)
plane_material = CreateMaterial()
SetMaterialType(plane_material, FX_MATERIAL_TYPE_PLASTIC)
SetActorMaterial(plane, 0, plane_material)

SetActorSolid(plane, TRUE)
SetActorShape(plane, ACTOR_SHAPE_BOX, 0)



'Set the canvas camera to where the composite actor will be falling
Canvas(m3d)
SetCameraPosition(0, 30, -100)
SetCameraRotation(20, 0, 0)



While Not Key(K_ESCAPE)
	
	If Key(K_BACKSPACE) Then
		w2_index = GetCompositeChildIndex(composite_actor, cylinder_actor)
		RemoveCompositeChild(composite_actor, w2_index)
		While Key(K_BACKSPACE)
			Update()
		Wend
	ElseIf Key(K_1) Then
		ApplyActorCentralImpulseLocal(composite_actor, -2, 0, 0)
	ElseIf Key(K_2) Then
		RotateActor(cylinder_actor, 0, 5, 0)
	End If
	
	Update()
Wend


 