' Title: Custom Rendering Stages
'
'	Author: n00b @rcbasic.freeforums.net
'	NOTE: 
'   This isn't really flashy but just a minimal demo of how to
'   split your rendering up into different stages

title$ = "Nirvana2D Template"
w = 640
h = 480
fullscreen = FALSE
vsync = FALSE

'Open a graphics window
OpenWindow( title$, w, h, fullscreen, vsync )

SetClearColor(RGB(100,100,255))
m3d = OpenCanvas3D(0, 0, w, h, 1)

cube = CreateCubeActor( 20 )
cube_material = CreateMaterial()
SetMaterialType(cube_material, FX_MATERIAL_TYPE_NORMAL_BLEND)
SetMaterialLighting(cube_material, FALSE)
SetActorMaterial(cube, 0, cube_material)
SetActorPosition(cube, 0, 10, 0)

plane_mesh = CreatePlaneMesh(1000, 1000, 10, 10, 10, 10)
plane = CreateAnimatedActor(plane_mesh)
plane_material = CreateMaterial()
SetMaterialType(plane_material, FX_MATERIAL_TYPE_PLASTIC)
SetActorMaterial(plane, 0, plane_material)


Canvas(m3d)
SetCameraPosition(0, 30, -100)
SetCameraRotation(20, 0, 0)

While Not Key(K_ESCAPE)
	
	Pipeline_Begin()
	Canvas(m3d)
	
	'Only the ground plane is rendered in the first stage
	SetActorVisible(cube, FALSE)
	SetActorVisible(plane, TRUE)
	Pipeline_Render()
	
	'Next we will draw a green circle
	SetActorVisible(plane, FALSE)
	SetColor(RGB(0,255,0))
	Dim sx, sy
	GetWorldToViewportPosition(0, 10, 0, sx, sy)
	CircleFill(sx, sy, 50)
	Pipeline_Render()
	
	'Finally we will render the cube
	SetActorVisible(cube, TRUE)
	Pipeline_Render()
	
	Update()
	Pipeline_End()
Wend


 