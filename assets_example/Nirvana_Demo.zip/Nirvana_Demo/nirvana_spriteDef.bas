NIRVANA_SPRITE_DIR$ = NIRVANA_PROJECT_BASE_DIR$ + NIRVANA_PATH_SEPARATOR$ + "sprites" + NIRVANA_PATH_SEPARATOR$


Type Nirvana_Sprite
Dim Name$
Dim BaseName$
Dim Sprite_ID
Dim Detached_Sprite_ID
Dim IsDetached
Dim Animation_Name_Index
Dim Animation_Count
End Type

Dim Nirvana_Sprite_Image_Stack : Nirvana_Sprite_Image_Stack = CreateStack_N()

Dim Nirvana_Sprite_Image_0 : Nirvana_Sprite_Image_0 = -1


Dim Nirvana_SpriteAnimationNames$[6]

Nirvana_SpriteAnimationNames$[0] = "Walk_Right"
Nirvana_SpriteAnimationNames$[1] = "Walk_Left"
Nirvana_SpriteAnimationNames$[2] = "Jump_Right"
Nirvana_SpriteAnimationNames$[3] = "Jump_Left"
Nirvana_SpriteAnimationNames$[4] = "Idle_Right"
Nirvana_SpriteAnimationNames$[5] = "Idle_Left"


Function Nirvana_SpriteDef_0(ByRef detached_spr_id)
	If Nirvana_Sprite_Image_0 < 0 Then
		If OS$ = "WINDOWS" Then
			Nirvana_Sprite_Image_0 = LoadImage(NIRVANA_SPRITE_DIR$ + "graizor.png")
		Else
			Nirvana_Sprite_Image_0 = LoadImage(NIRVANA_SPRITE_DIR$ + "graizor.png")
		End If

		If Nirvana_Sprite_Image_0 >= 0 Then
			Push_N(Nirvana_Sprite_Image_Stack, Nirvana_Sprite_Image_0)
		End If
	End If

	spr_id = CreateSprite(Nirvana_Sprite_Image_0, 64, 64)

	'-------ANIMATIONS-------

	spr_animation1 = CreateSpriteAnimation(spr_id, 4, 6)

	SetSpriteAnimationFrame(spr_id, spr_animation1, 0, 0)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 1, 1)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 2, 0)
	SetSpriteAnimationFrame(spr_id, spr_animation1, 3, 3)

	spr_animation2 = CreateSpriteAnimation(spr_id, 4, 7)

	SetSpriteAnimationFrame(spr_id, spr_animation2, 0, 28)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 1, 29)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 2, 30)
	SetSpriteAnimationFrame(spr_id, spr_animation2, 3, 31)

	spr_animation3 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation3, 0, 17)

	spr_animation4 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation4, 0, 45)

	spr_animation5 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation5, 0, 1)

	spr_animation6 = CreateSpriteAnimation(spr_id, 1, 0)

	SetSpriteAnimationFrame(spr_id, spr_animation6, 0, 29)


	'-------SHAPE-------
detached_spr_id = CreateSprite(-1, 64, 64)

	SetSpriteShape(detached_spr_id, SPRITE_SHAPE_CIRCLE)
	SetSpriteShapeOffset(detached_spr_id, 0, 23)
	SetSpriteRadius(detached_spr_id, 9)

	Return spr_id
End Function


Function Nirvana_CreateSprite(base_name$, sprite_name$) As Nirvana_Sprite
	Dim nv_sprite As Nirvana_Sprite
	nv_sprite.Name$ = sprite_name$
	nv_sprite.BaseName$ = base_name$

	Select Case base_name$

	Case "grz"
		nv_sprite.Sprite_ID = Nirvana_SpriteDef_0(nv_sprite.Detached_Sprite_ID)
		nv_sprite.IsDetached = TRUE
		nv_sprite.Animation_Name_Index = 0
		nv_sprite.Animation_Count = 7

	End Select

	Return nv_sprite
End Function
