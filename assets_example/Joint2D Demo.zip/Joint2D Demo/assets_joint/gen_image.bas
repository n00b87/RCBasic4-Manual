Const GEN_BOX = 0
Const GEN_CIRCLE = 1


'This function will just create images for our sprites
Function GenImage(gen_shape, color, img_w, img_h)
	current_canvas = ActiveCanvas()
	
	tmp_canvas = OpenCanvas(w, h, 0, 0, w, h, 1)
	Canvas(tmp_canvas)
	ClearCanvas()
	
	SetColor(color)
	
	Select Case gen_shape
	Case GEN_BOX
		Rect(0, 0, img_w-1, img_h-1)
	Case GEN_CIRCLE
		CircleFill( img_w/2, img_w/2, img_w/2)
		SetColor(RGB(255,255,255))
		Line(0, img_w/2, img_w, img_w/2)
		Line(img_w/2, 0, img_w/2, img_w)
	End Select
	
	
	img = CanvasClip(0, 0, img_w, img_h)
	
	CloseCanvas(tmp_canvas)
	
	Canvas(current_canvas)
	
	Return img
End Function



