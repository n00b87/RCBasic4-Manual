'Its a pulley
Sub test_pulleyJoint()
	Canvas(spr_canvas)
	
	'SpriteA is going to be static in the top center of the viewport
	SetSpritePosition(spriteA, 400, 200)
	SetSpriteType(spriteA, SPRITE_TYPE_DYNAMIC)
	SetSpriteGravityScale(spriteA, 0)
	SetSpriteVisible(spriteA, TRUE)
	SetSpriteSolid(spriteA, TRUE)
	
	'SpriteB is going to start at the left of spriteA and will start falling at the start of the demo
	SetSpritePosition(spriteB, 500, 200)
	SetSpriteType(spriteB, SPRITE_TYPE_DYNAMIC)
	SetSpriteGravityScale(spriteB, 1.0)
	SetSpriteVisible(spriteB, TRUE)
	SetSpriteSolid(spriteB, TRUE)

	'ax and ay are the local coordinates on spriteA where the joint is connected
	ax = 32
	ay = 0
	
	'bx and by are the local coordinates on spriteB where the joint is connected
	bx = 0
	by = 0
	
	
	ground_x1 = 400
	ground_y1 = 10
	
	ground_x2 = 500
	ground_y2 = 10
	
	
	'collide_connect is a flag that determines if spriteA and spriteB can collide with each other while part of this joint
	collide_connect = FALSE
	
	'Create a distance joint
	test_joint = CreatePulleyJoint(spriteA, spriteB, ground_x1, ground_y1, ground_x2, ground_y2, ax, ay, bx, by, 1, collide_connect)
	
	
	
	joint_type = JOINT_TYPE_PULLEY
End Sub