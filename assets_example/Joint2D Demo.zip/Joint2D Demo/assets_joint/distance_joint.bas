'Distance joints are kind of like having 2 objects tied together by a rope or string
Sub test_distanceJoint()
	Canvas(spr_canvas)
	
	'SpriteA is going to be static in the top center of the viewport
	SetSpritePosition(spriteA, w/2, 10)
	SetSpriteType(spriteA, SPRITE_TYPE_STATIC)
	SetSpriteGravityScale(spriteA, 0)
	SetSpriteVisible(spriteA, TRUE)
	SetSpriteSolid(spriteA, TRUE)
	
	'SpriteB is going to start at the left of spriteA and will start falling at the start of the demo
	SetSpritePosition(spriteB, (w/2) - 70, 50)
	SetSpriteType(spriteB, SPRITE_TYPE_DYNAMIC)
	SetSpriteGravityScale(spriteB, 1.0)
	SetSpriteDensity(spriteB, 5)
	SetSpriteRestitution(spriteB, 0)
	SetSpriteFriction(spriteB, 0)
	SetSpriteVisible(spriteB, TRUE)
	SetSpriteSolid(spriteB, TRUE)

	'ax and ay are the local coordinates on spriteA where the joint is connected
	ax = 30
	ay = 32
	
	'bx and by are the local coordinates on spriteB where the joint is connected
	bx = 32
	by = 32
	
	
	'collide_connect is a flag that determines if spriteA and spriteB can collide with each other while part of this joint
	collide_connect = FALSE
	
	'Create a distance joint
	test_joint = CreateDistanceJoint(spriteA, spriteB, ax, ay, bx, by, collide_connect)
	SetJointLength(test_joint, 200)
	
	'Set the mininum and maximum distance the 2 sprites can be between each other
	SetJointMinLength(test_joint, 20)
	SetJointMaxLength(test_joint, 200)
	
	joint_type = JOINT_TYPE_DISTANCE
End Sub