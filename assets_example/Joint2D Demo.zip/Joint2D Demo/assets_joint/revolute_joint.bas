Sub test_revoluteJoint()
	Canvas(spr_canvas)
	
	'SpriteA is going to be one part of the weld
	SetSpritePosition(spriteA, w/2, 10)
	SetSpriteType(spriteA, SPRITE_TYPE_DYNAMIC)
	SetSpriteGravityScale(spriteA, 1.0)
	SetSpriteVisible(spriteA, TRUE)
	SetSpriteSolid(spriteA, TRUE)
	
	'SpriteB is going to start at the left of spriteA and will start falling at the start of the demo
	SetSpritePosition(spriteB, w/2+64, 70)
	SetSpriteType(spriteB, SPRITE_TYPE_DYNAMIC)
	SetSpriteGravityScale(spriteB, 1.0)
	SetSpriteVisible(spriteB, TRUE)
	SetSpriteSolid(spriteB, TRUE)
	
	'SpriteC is going to be static
	SetSpritePosition(spriteC, w/2 - 100, 200)
	SetSpriteType(spriteC, SPRITE_TYPE_STATIC)
	SetSpriteGravityScale(spriteC, 0)
	SetSpriteVisible(spriteC, TRUE)
	SetSpriteSolid(spriteC, TRUE)
	

	'ax and ay are the local coordinates on spriteA where the joint is connected
	x = SpriteX(spriteB)
	y = SpriteY(spriteB)
	
	'collide_connect is a flag that determines if spriteA and spriteB can collide with each other while part of this joint
	collide_connect = FALSE
	
	'Create a distance joint
	test_joint = CreateRevoluteJoint(spriteA, spriteB, x, y, collide_connect)
	
	joint_type = JOINT_TYPE_REVOLUTE
End Sub