'Friction Joints seem to be more useful for simulating different surfaces from a top-down view
Sub test_frictionJoint()
	Canvas(spr_canvas)
	
	'SpriteA is going to be static in the top center of the viewport
	SetSpritePosition(spriteC, w/2 - 100, 200)
	SetSpriteType(spriteC, SPRITE_TYPE_STATIC)
	SetSpriteGravityScale(spriteC, 0)
	SetSpriteVisible(spriteC, TRUE)
	SetSpriteSolid(spriteC, FALSE)
	
	'SpriteB is going to start at the left of spriteA and will start falling at the start of the demo
	SetSpritePosition(spriteB, w/2, 10)
	SetSpriteType(spriteB, SPRITE_TYPE_DYNAMIC)
	SetSpriteGravityScale(spriteB, 0)
	SetSpriteVisible(spriteB, TRUE)
	SetSpriteSolid(spriteB, TRUE)
	'SetSpriteDensity(spriteB, 7)
	SetSpriteLinearVelocity(spriteB, 0, 40)

	'ax and ay are the local coordinates on spriteA where the joint is connected
	x = SpriteX(spriteB) '32
	y = SpriteY(spriteB) '32
	
	'collide_connect is a flag that determines if spriteA and spriteB can collide with each other while part of this joint
	collide_connect = FALSE
	
	SetGravity2D(0, 0)
	
	'Create a distance joint
	test_joint = CreateFrictionJoint(spriteC, spriteB, x, y, collide_connect)
	
	SetJointMaxForce(test_joint,  10000)
	SetJointMaxTorque(test_joint, 10000)
	
	joint_type = JOINT_TYPE_FRICTION
End Sub