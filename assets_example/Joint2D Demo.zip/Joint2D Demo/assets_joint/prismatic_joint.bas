'Prismatic Joints can be used to make sliding objects or maybe moving platforms
Sub test_prismaticJoint()
	Canvas(spr_canvas)
	
	'SpriteA is going to be static in the top center of the viewport
	SetSpritePosition(spriteA, w/2, 10)
	SetSpriteType(spriteA, SPRITE_TYPE_STATIC)
	SetSpriteGravityScale(spriteA, 0)
	SetSpriteVisible(spriteA, TRUE)
	SetSpriteSolid(spriteA, TRUE)
	
	'SpriteB is going to start at the left of spriteA and will start falling at the start of the demo
	SetSpritePosition(spriteB, w/2, 10)
	SetSpriteType(spriteB, SPRITE_TYPE_DYNAMIC)
	SetSpriteGravityScale(spriteB, 1.0)
	SetSpriteVisible(spriteB, TRUE)
	SetSpriteSolid(spriteB, TRUE)

	'ax and ay are the local coordinates on spriteA where the joint is connected
	ax = SpriteX(spriteA) + 32
	ay = spriteY(spriteA) + 32
	
	axisX = 1
	axisY = 1
	
	'collide_connect is a flag that determines if spriteA and spriteB can collide with each other while part of this joint
	collide_connect = FALSE
	
	'Create a distance joint
	test_joint = CreatePrismaticJoint(spriteA, spriteB, ax, ay, axisX, axisY, collide_connect)
	
	SetJointLimits(test_joint, 0, 200)
	EnableJointLimit(test_joint, TRUE)
	
	joint_type = JOINT_TYPE_PRISMATIC
End Sub