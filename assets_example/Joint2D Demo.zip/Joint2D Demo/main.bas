title$ = "Simple 3D Game"
w = 640
h = 480
fullscreen = FALSE
vsync = FALSE

Include "gen_image.bas"


'Open a graphics window
OpenWindow( title$, w, h, fullscreen, vsync )

'Lock the window to 60 fps
SetFPS(60)


'Open a sprite canvas
spr_canvas = OpenCanvasSpriteLayer(0, 0, w, h)
Canvas(spr_canvas)

'Open a overlay canvas
overlay_canvas = OpenCanvas(w, h, 0, 0, w, h, 1)

'Set Overlay canvas on top
SetCanvasZ(overlay_canvas, 0)


img_a = GenImage(GEN_BOX, RGB(255,0,0), 64, 64)
img_b = GenImage(GEN_BOX, RGB(0,0,255), 64, 64)
img_c = GenImage(GEN_BOX, RGB(0,150,0), 200, 200)

spriteA = -1
spriteB = -1
spriteC = -1

test_joint = -1
joint_type = -1

Const JOINT_TYPE_DISTANCE 		= 0
Const JOINT_TYPE_PRISMATIC		= 1
Const JOINT_TYPE_FRICTION		= 2
Const JOINT_TYPE_PULLEY			= 3
Const JOINT_TYPE_WELD				= 4
Const JOINT_TYPE_REVOLUTE		= 5

fnt = LoadFont("FreeMono.ttf", 18)
SetFont(fnt)


Include "distance_joint.bas"
Include "prismatic_joint.bas"
Include "friction_joint.bas"
Include "pulley_joint.bas"
Include "weld_joint.bas"
Include "revolute_joint.bas"


Sub test_clear()
	If jointExists(test_joint) Then
		DeleteJoint(test_joint)
	End If
	
	If SpriteExists(spriteA) Then
		DeleteSprite(spriteA)
	End If
	
	If SpriteExists(spriteB) Then
		DeleteSprite(spriteB)
	End If
	
	If SpriteExists(spriteC) Then
		DeleteSprite(spriteC)
	End If
	
	Canvas(spr_canvas)
	
	SetCanvasPhysics2D(spr_canvas, TRUE)
	SetGravity2D(0, 60.0)
	SetWorld2DTimeStep(1/60)
	SetWorld2DAutoClearForces(TRUE)
	
	spriteA = CreateSprite( img_a, 64, 64 )
	spriteB = CreateSprite( img_b, 64, 64 )
	spriteC = CreateSprite( img_c, 200, 100 )

	SetSpriteZ(spriteC, 1)

	test_joint = -1
	joint_type = -1
	
	SetSpriteVisible(spriteA, FALSE)
	SetSpriteSolid(spriteA, FALSE)
	
	SetSpriteVisible(spriteB, FALSE)
	SetSpriteSolid(spriteB, FALSE)
	
	SetSpriteVisible(spriteC, FALSE)
	SetSpriteSolid(spriteC, FALSE)
	
End Sub



Sub test_updateJointOverlay()
	
	Dim ax, ay, bx, by, axisX, axisY
	Dim gx1, gy1, gx2, gy2
	
	Canvas(overlay_canvas)
	ClearCanvas()
	
	SetColor(RGB(255, 255, 255))
	DrawText("Press one of the following keys to start a test", 10, 10)
	DrawText("1 - Distance Joint", 10, 30)
	DrawText("2 - Friction Joint", 10, 50)
	DrawText("3 - Prismatic Joint", 10, 70)
	DrawText("4 - Pulley Joint", 10, 90)
	DrawText("5 - Revolute Joint", 10, 110)
	DrawText("6 - Weld Joint", 10, 130)
	
	Current_Joint_Text$ = ""
	
	Select Case joint_type
	
	Case JOINT_TYPE_DISTANCE
		GetJointWorldAnchorA(test_joint, ax, ay)
		GetJointWorldAnchorB(test_joint, bx, by)
		SetColor(RGB(200, 100, 100))
		Line(ax, ay, bx, by)
		
		Current_Joint_Text$ = "Distance"
		
	Case JOINT_TYPE_PRISMATIC
		GetJointWorldAnchorA(test_joint, ax, ay)
		'Print "WorldAnchorA: "; ax; ", "; ay
		GetJointLocalAxisA(test_joint, axisX, axisY)
		SetColor(RGB(200, 100, 100))
		Line(ax, ay, ax + (axisX * 200), ay + (axisY * 200))
		
		Current_Joint_Text$ = "Prismatic"
	
	Case JOINT_TYPE_FRICTION
		GetJointWorldAnchorA(test_joint, ax, ay)
		GetJointWorldAnchorB(test_joint, bx, by)
		'Print "WorldAnchorA: "; ax; ", "; ay
		SetColor(RGB(200, 100, 100))
		Line(ax, ay, bx, by)
		
		Current_Joint_Text$ = "Friction"
		
	Case JOINT_TYPE_PULLEY
		GetJointWorldAnchorA(test_joint, ax, ay)
		GetJointWorldAnchorB(test_joint, bx, by)
		GetJointGroundAnchorA(test_joint, gx1, gy1)
		GetJointGroundAnchorB(test_joint, gx2, gy2)
		'Print "WorldAnchorA: "; ax; ", "; ay
		
		SetColor(RGB(200, 100, 100))
		Line(ax, ay, gx1, gy1)
		Line(gx1, gy1, gx2, gy2)
		Line(bx, by, gx2, gy2)
		
		SetColor(RGB(120,120,120))
		RectFill(gx1-5, gy1-5, 10, 10)
		RectFill(gx2-5, gy2-5, 10, 10)
		
		Current_Joint_Text$ = "Pulley"
		
	Case JOINT_TYPE_WELD, JOINT_TYPE_REVOLUTE
		GetJointWorldAnchorA(test_joint, ax, ay)
		SetColor(RGB(200, 100, 100))
		RectFill(ax-5, ay-5, 10, 10)
		
		If joint_type = JOINT_TYPE_WELD Then
			Current_Joint_Text$ = "Weld"
		Else
			Current_Joint_Text$ = "Revolute"
		End If
		
	End Select
	
	SetColor(RGB(255,255,255))
	DrawText("Current Joint: " + Current_Joint_Text$, 10, 400)
	
End Sub


test_clear()
test_pulleyJoint()

While (WindowExists()) And (Not Key(K_ESCAPE))
	
	Select Case Inkey()
	Case K_1
		test_clear()
		test_distanceJoint()
	Case K_2
		test_clear()
		test_frictionJoint()
	Case K_3
		test_clear()
		test_prismaticJoint()
	Case K_4
		test_clear()
		test_pulleyJoint()
	Case K_5
		test_clear()
		test_revoluteJoint()
	Case K_6
		test_clear()
		test_weldJoint()
	End Select
	
	'Pre Compute Physics
	PreUpdate()
	
	'Draw Anchor Connection
	test_updateJointOverlay()
	
	Update()
Wend













