title$ = "Simple 3D Game"
w = 640
h = 480
fullscreen = FALSE
vsync = FALSE

'Open a graphics window
OpenWindow( title$, w, h, fullscreen, vsync )

'Lock the window to 60 fps
SetFPS(60)


'Open a 3D canvas to view our scene in
scene_canvas = OpenCanvas3D(0, 0, w, h, 1)

'Set our scene canvas as the active canvas
Canvas(scene_canvas)


'Load character mesh and texture
hero_mesh = LoadMesh("assets/char.ms3d")
hero_texture = LoadImage("assets/survivorMaleB.png")


'Create our main character actor (this adds it to our 3D scene)
hero = CreateAnimatedActor(hero_mesh)

'Create a simple animation and set it to the hero actor
PLAYER_RUN_ANIMATION = CreateActorAnimation(hero, 13, 36, 30)
SetActorAnimation(hero, PLAYER_RUN_ANIMATION, -1)

'Set Actor as a solid object
SetActorSolid(hero, TRUE)


'Apply a Texture our main character
hero_material = GetActorMaterial(hero, 0)
SetMaterialTexture(hero_material, 0, hero_texture)
SetMaterialLighting(hero_material, FALSE)



'Create our level actor (adds it to our 3D scene)
plane_mesh = CreatePlaneMesh(1000, 1000, 100, 100, 100, 100)
plane_actor = CreateOctreeActor(plane_mesh)
SetActorSolid(plane_actor, TRUE)
SetActorShape(plane_actor, ACTOR_SHAPE_TRIMESH, 0)

'Apply an FX material to the ground plane
plane_material = CreateMaterial()
SetMaterialType(plane_material, FX_MATERIAL_TYPE_PLASTIC)
SetMaterialLighting(plane_material, FALSE)
SetActorMaterial(plane_actor, 0, plane_material)


particle_actor = CreateParticleActor(PARTICLE_TYPE_CYLINDER)

SetParticleBox(particle_actor, -5,0,-5, 5,1,5)
SetParticleDirection(particle_actor, 0.0,0.06,0.0)
SetMinParticlesPerSecond(particle_actor, 80)
SetMaxParticlesPerSecond(particle_actor, 100)
SetParticleMinStartColor(particle_actor, RGBA(0,255,255,255))
SetParticleMaxStartColor(particle_actor, RGBA(0,255,255,255))
SetParticleMinLife(particle_actor, 800)
SetParticleMaxLife(particle_actor,2000)
SetParticleMaxAngle(particle_actor,0)
SetParticleMinStartSize(particle_actor, 1,1)
SetParticleMaxStartSize(particle_actor, 2,2)


SetParticleLength(particle_actor, 100)
SetParticleCenter(particle_actor, 0, 0, 0)
SetParticleRadius(particle_actor, 20)

StartParticleEmitter(particle_actor)

SetActorSolid(particle_actor, FALSE)
SetActorGravity(particle_actor, 0, 0, 0)
SetActorMaterial(particle_actor, 0, hero_material)


'Set the starting animation to idle_animation and set loops to -1 to loop infinitely
SetActorPosition(hero, 0, 10, 0)

SetCameraPosition(0, 5, -10)
SetCameraRotation(20, 0, 0)


While Not Key(K_ESCAPE)
	
	If Key(K_RIGHT) Then
		SetActorLinearVelocityLocal(hero, 0, 0, 20)
	End If
	
	If key(K_P) Then
		StopParticleEmitter(particle_actor)
	end if
	
	Update()
Wend




