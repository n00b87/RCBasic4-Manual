title$ = "Template"
w = 640
h = 480
fullscreen = FALSE
vsync = FALSE

'Open a graphics window
OpenWindow( title$, w, h, fullscreen, vsync )

'Lock the window to 60 fps
SetFPS(60)

m3d = OpenCanvas3D(0, 0, w, h, 1)

'Open a canvas to display instructions on
ui_canvas = OpenCanvas(w, h, 0, 0, w, h, 1)

'Set canvas order so it displays on top of the 3D scene
SetCanvasZ(ui_canvas, 0)

'Set the ui canvas active
Canvas(ui_canvas)

'Load font and set it as the active font for text drawing
f_mono = LoadFont("FreeMono.ttf", 12)
SetFont(f_mono)

'Set the drawing color to white
SetColor(RGB(255,255,255))

'Display the instructions on the ui canvas
DrawText("Press SPACE to move the vehicle", 10, 10)
DrawText("Press LEFT/RIGHT to steer", 10, 30)


'We don't need the ui canvas anymore so we can switch to the 3D canvas
Canvas(m3d)
SetClearColor(RGB(100,100,255))


'Create a cube actor to use as the chassis
cube = CreateCubeActor( 15 )
SetActorShape(cube, ACTOR_SHAPE_BOX, 800)
SetActorSolid(cube, TRUE)
cube_material = CreateMaterial()
SetMaterialType(cube_material, FX_MATERIAL_TYPE_NORMAL_BLEND)
SetMaterialLighting(cube_material, FALSE)
SetActorMaterial(cube, 0, cube_material)


'This is to keep the vehicle from being too bouncy
SetActorDamping(cube, 0.4, 0.4)


'Create a cylinder mesh for the wheels
'NOTE: Cylinder meshes are oriented facing up so we will need to use SetWheelActorOffsetTransform() to orient the wheel to align with the wheel axis
wheel_mesh = CreateCylinderMesh(5, 3, 6, RGB(120, 255, 120), TRUE)
wheel_texture = LoadImage("tile_026_Height.png")


'Creating a type to hold the actor id and the wheel index for each wheel
Type VehicleWheel
	Dim ActorID
	Dim WheelID
End Type

Dim wheel[4] As VehicleWheel

wheel_material = CreateMaterial()
SetMaterialLighting(wheel_material, FALSE)
SetMaterialTexture(wheel_material, 0, wheel_texture)

'Create the actors for each wheel
For i = 0 To 3
	wheel[i].ActorID = CreateAnimatedActor(wheel_mesh)
	SetActorShape(wheel[i].ActorID, ACTOR_SHAPE_CYLINDER, 1)
	
	SetActorMaterial(wheel[i].ActorID, 0, wheel_material)
Next


'Create the vehicle actor
vehicle = CreateVehicleActor(cube)

'Add 4 wheels to the vehicle
wheel[0].WheelID = AddVehicleWheel(vehicle, wheel[0].ActorID, TRUE)
SetWheelConnectionPoint(vehicle, wheel[0].WheelID, -10, -5, 10)

wheel[1].WheelID = AddVehicleWheel(vehicle, wheel[1].ActorID, TRUE)
SetWheelConnectionPoint(vehicle, wheel[1].WheelID, 10, -5, 10)

wheel[2].WheelID = AddVehicleWheel(vehicle, wheel[2].ActorID, FALSE)
SetWheelConnectionPoint(vehicle, wheel[2].WheelID, -10, -5, -10)

wheel[3].WheelID = AddVehicleWheel(vehicle, wheel[3].ActorID, FALSE)
SetWheelConnectionPoint(vehicle, wheel[3].WheelID, 10, -5, -10)


offset_t = DimMatrix(4, 4)
SetIdentityMatrix(offset_t, 4)
SetMatrixRotation(offset_t, 0, 0, 90)

'Feel free to play around with the numbers for each wheel to get desired result
For i = 0 To 3
	'Rotates the cylinder to line up with the wheel axis
	SetWheelActorOffsetTransform( vehicle, wheel[i].WheelID, offset_t )

	'Sets the Wheel Properties
	SetWheelDirection(vehicle, wheel[i].WheelID, 0, -1, 0)
	SetWheelAxel(vehicle, wheel[i].WheelID, -1, 0, 0)
	SetWheelRadius(vehicle, wheel[i].WheelID, 10)
	SetWheelSuspensionLength( vehicle, wheel[i].WheelID, 0.8 )

	SetWheelSuspensionStiffness( vehicle, wheel[i].WheelID, 20 )
	SetWheelDampingCompression( vehicle, wheel[i].WheelID, 1.1 )
	SetWheelDampingRelaxation( vehicle, wheel[i].WheelID, 1.1 )
	SetWheelFrictionSlip( vehicle, wheel[i].WheelID, 200 )
	SetWheelRollInfluence( vehicle, wheel[i].WheelID, 0.01 )
Next

'Start the vehicle of in the sky and let it fall into the scene
SetActorPosition(vehicle, 0, 100, 0)


'Create our ground plane
plane_mesh = CreatePlaneMesh(1000, 1000, 100, 100, 100, 100)
plane = CreateAnimatedActor(plane_mesh)
plane_material = CreateMaterial()
SetMaterialType(plane_material, FX_MATERIAL_TYPE_PLASTIC)
SetActorMaterial(plane, 0, plane_material)

SetActorSolid(plane, TRUE)
SetActorShape(plane, ACTOR_SHAPE_TRIMESH, 0)


'Set the gravity for the scene
SetGravity3D(0, -10, 0)


Canvas(m3d)
SetCameraPosition(-3, 50, 85)
SetCameraRotation(20, -176, 0)


While Not Key(K_ESCAPE)
	
	
	If Key(K_SPACE) Then
		SetActorLinearVelocityLocal(vehicle, 0, 0, -50)
	End If
	
	If Key(K_LEFT) Then
		SetWheelSteeringValue( vehicle, wheel[0].WheelID, 0.4 )
		SetWheelSteeringValue( vehicle, wheel[1].WheelID, 0.4 )
	ElseIf Key(K_RIGHT) Then
		SetWheelSteeringValue( vehicle, wheel[0].WheelID, -0.4 )
		SetWheelSteeringValue( vehicle, wheel[1].WheelID, -0.4 )
	Else
		SetWheelSteeringValue( vehicle, wheel[0].WheelID, 0 )
		SetWheelSteeringValue( vehicle, wheel[1].WheelID, 0 )
	End If
	
	Update()
Wend


 