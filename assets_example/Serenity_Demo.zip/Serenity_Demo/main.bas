'----------------------------------------------------------------
'   TITLE: House 3D
'   AUTHOR: n00b
'   DATE: April 1, 2025
'
'   DESCRIPTION: Simplest Serenity Example
'
'----------------------------------------------------------------

Include "serenity.bas"


Type Ambient_FPS_Controller
	Dim ControlCanvas
	Dim MoveSpeed
	Dim Sensitivity
	Dim mx
	Dim my
	Dim prev_mx
	Dim prev_my
	Dim mb1
	Dim mb2
	Dim mb3
End Type

Type Ambient_IO
	'Dim KeyPressed[10] 'Only Tracks up to 10 key presses per frame
	'Dim Joystick[AMBIENT_MAX_JOYSTICKS] As Ambient_Joystick
	'Dim Action[30] As Ambient_ActionKey
	Dim FPS_CameraControl As Ambient_FPS_Controller
End Type

Type Ambient_GameState
	Dim State
End Type

Type Ambient_Core
	'Dim WindowSize As Ambient_Size
	Dim VSync
	Dim TargetFPS
	Dim Fullscreen
	
	Dim IO As Ambient_IO
	
	Dim GameState As Ambient_GameState
End Type

Dim Core As Ambient_Core


Core.IO.FPS_CameraControl.MoveSpeed = 48
Core.IO.FPS_CameraControl.Sensitivity = 0.5


Sub Ambient_MouseDelta_FPS(ByRef dx, ByRef dy)
	move_mouse = false
	
	Core.IO.FPS_CameraControl.prev_mx = Core.IO.FPS_CameraControl.mx
	Core.IO.FPS_CameraControl.prev_my = Core.IO.FPS_CameraControl.my
	
	GetMouse(Core.IO.FPS_CameraControl.mx, Core.IO.FPS_CameraControl.my, Core.IO.FPS_CameraControl.mb1, Core.IO.FPS_CameraControl.mb2, Core.IO.FPS_CameraControl.mb3)
	
	Dim w, h
	GetCanvasSize(Core.IO.FPS_CameraControl.ControlCanvas, w, h)
	w = w-1
	h = h-1
	
	If Core.IO.FPS_CameraControl.mx <= 0 And Core.IO.FPS_CameraControl.prev_mx > 0 Then
		Core.IO.FPS_CameraControl.mx = w
		move_mouse = True
	ElseIf Core.IO.FPS_CameraControl.mx >= w And Core.IO.FPS_CameraControl.prev_mx < w Then
		Core.IO.FPS_CameraControl.mx = 0
		move_mouse = True
	End If
    
  If Core.IO.FPS_CameraControl.my <= 0 And Core.IO.FPS_CameraControl.prev_my > 0 Then
		Core.IO.FPS_CameraControl.my = h
		move_mouse = True
	ElseIf Core.IO.FPS_CameraControl.my >= h And Core.IO.FPS_CameraControl.prev_my < h Then
		Core.IO.FPS_CameraControl.my = 0
		move_mouse = True
	End If
	
	If move_mouse Then
		WarpMouse(Core.IO.FPS_CameraControl.mx, Core.IO.FPS_CameraControl.my)
		dx = 0
		dy = 0
	Else
		dx = Core.IO.FPS_CameraControl.mx - Core.IO.FPS_CameraControl.prev_mx
		dy = Core.IO.FPS_CameraControl.my - Core.IO.FPS_CameraControl.prev_my
	End If
End Sub


Sub Ambient_FPSControl()
	If Core.IO.FPS_CameraControl.ControlCanvas < 0 Then
		Return
	End If
	
	
	current_canvas = ActiveCanvas()
	Canvas(Core.IO.FPS_CameraControl.ControlCanvas)

	Dim dx, dy
	Ambient_MouseDelta_FPS(dx, dy)
	
	dx = dx * Core.IO.FPS_CameraControl.Sensitivity
	dy = dy * Core.IO.FPS_CameraControl.Sensitivity
	
	dim xr,yr,zr
	GetCameraRotation(xr, yr, zr)
	SetCameraRotation(xr, yr+dx, zr)
	
	RotateCamera(dy, 0, 0)
	
	If Key(K_W) Then
		TranslateCamera(0,0,Core.IO.FPS_CameraControl.MoveSpeed)
    ElseIf Key(K_S) Then
		TranslateCamera(0,0,-1*Core.IO.FPS_CameraControl.MoveSpeed)
	End If

	If Key(K_A) Then 
		TranslateCamera(-1*Core.IO.FPS_CameraControl.MoveSpeed,0,0)
	ElseIf Key(K_D) Then
		TranslateCamera(Core.IO.FPS_CameraControl.MoveSpeed,0,0)
	End If

	If Key(K_R) Then
		Dim crx, cry, crz
		GetCameraPosition(crx, cry, crz)
		SetCameraPosition(crx, cry+Core.IO.FPS_CameraControl.MoveSpeed, crz)
	ElseIf Key(K_F) Then
		Dim crx, cry, crz
		GetCameraPosition(crx, cry, crz)
		SetCameraPosition(crx, cry-Core.IO.FPS_CameraControl.MoveSpeed, crz)
	End If
	
	Canvas(current_canvas)
End Sub



title$ = "Serenity3D Template"
w = 640
h = 480
fullscreen = FALSE
vsync = TRUE


'Open a graphics window
OpenWindow("Serenity3D Template", w, h, fullscreen, vsync)

SetMouseRelative(true)

'Open a 3D Canvas
m3d = OpenCanvas3D(0, 0, 640, 480, 0)

Core.IO.FPS_CameraControl.ControlCanvas = m3d

'Set the 3D Canvas as the active Canvas (Camera Actions will be done on active canvas)
Canvas(m3d)

SetCameraFarValue(10000)

'Move and Rotate the Camera
SetCameraPosition(-650, 620, 890)
SetCameraRotation(25,-220,0)

'Load a Stage
Serenity_LoadStage("stage1")

'Main Loop
While Not Key(K_ESCAPE)
	'Camera_Control(m3d)
	'C3D_FPSControl(m3d)
	Ambient_FPSControl()
	Update()
Wend

