path_separator$ = "/" : If OS$ = "WINDOWS" : path_separator$ = "\\" : End If


Const SN_MESH_TYPE_NORMAL = 0
Const SN_MESH_TYPE_ZIPPED = 1
Const SN_MESH_TYPE_AN8_SCENE = 2

Const SN_LIGHT_TYPE_POINT = 0
Const SN_LIGHT_TYPE_SPOT = 1
Const SN_LIGHT_TYPE_DIRECTIONAL = 2

Const SN_PARTICLE_TYPE_POINT = 0
Const SN_PARTICLE_TYPE_BOX = 1
Const SN_PARTICLE_TYPE_SPHERE = 2
Const SN_PARTICLE_TYPE_CYLINDER = 3
Const SN_PARTICLE_TYPE_MESH = 4
Const SN_PARTICLE_TYPE_RING = 5

Const SN_PHYSICS_SHAPE_NONE = 0
Const SN_PHYSICS_SHAPE_BOX = 1
Const SN_PHYSICS_SHAPE_SPHERE = 2
Const SN_PHYSICS_SHAPE_CYLINDER = 3
Const SN_PHYSICS_SHAPE_CAPSULE = 4
Const SN_PHYSICS_SHAPE_CONE = 5
Const SN_PHYSICS_SHAPE_CONVEXHULL = 6
Const SN_PHYSICS_SHAPE_TRIMESH = 7

Const SN_ACTOR_TYPE_ANIMATED = 0
Const SN_ACTOR_TYPE_OCTREE = 1
Const SN_ACTOR_TYPE_LIGHT = 2
Const SN_ACTOR_TYPE_BILLBOARD = 3
Const SN_ACTOR_TYPE_TERRAIN = 4
Const SN_ACTOR_TYPE_WATER = 5
Const SN_ACTOR_TYPE_PARTICLE = 6
Const SN_ACTOR_TYPE_CUBE = 7
Const SN_ACTOR_TYPE_SPHERE = 8
Const SN_ACTOR_TYPE_PLANE = 9

Const SN_SKY_TYPE_NONE = 0
Const SN_SKY_TYPE_BOX = 1
Const SN_SKY_TYPE_DOME = 2


Type Serenity_Vector3D
Dim x
Dim y
Dim z
End Type

Type Serenity_Size
Dim Width
Dim Height
Dim Depth
End Type

Function Serenity_CreateVector3D(x, y, z) As Serenity_Vector3D
	Dim v As Serenity_Vector3D
	v.x = x
	v.y = y
	v.z = z
	Return v
End Function

Function Serenity_CreateSize3D(w, h, d) As Serenity_Size
	Dim v As Serenity_Size
	v.width = w
	v.height = h
	v.depth = d
	Return v
End Function

Type Serenity_Texture
Dim ID
Dim Name$
Dim File$ 
Dim UseColorKey
Dim TextureColorKey 
End Type

Type Serenity_Texture_Reference
Dim SN_ID
End Type

Dim Serenity_Global_Texture_List[5] As Serenity_Texture

Type Serenity_Textures_List_Structure
Dim sky As Serenity_Texture_Reference
Dim grass As Serenity_Texture_Reference
Dim tree_texture1 As Serenity_Texture_Reference
Dim brick As Serenity_Texture_Reference
Dim roof As Serenity_Texture_Reference
End Type


Type Serenity_Material
Dim ID
Dim Name$
Dim Texture_Matrix 'Index in Serenity_Global_Texture_List
End Type

Type Serenity_Material_Reference
Dim SN_ID
End Type

Dim Serenity_Global_Material_List[5] As Serenity_Material

Type Serenity_Materials_List_Structure
Dim material_n As Serenity_Material_Reference
Dim tree_material1 As Serenity_Material_Reference
Dim house_material1 As Serenity_Material_Reference
Dim house_material2 As Serenity_Material_Reference
Dim house_window_material As Serenity_Material_Reference
End Type


Type Serenity_Mesh_Animation
Dim Name$ 
Dim Start_Frame
Dim End_Frame
Dim Speed
End Type

Dim Serenity_Global_Mesh_Animation_List[0] As Serenity_Mesh_Animation

Type Serenity_Mesh
Dim ID 
Dim SN_ID
Dim Name$
Dim MeshType 
Dim AN8_Index 
Dim AN8_Scene$ 
Dim Zip$ 
Dim File$ 
Dim Material_Matrix 
Dim MaterialCount 
Dim Animation_Matrix
Dim AnimationCount 
End Type

Type Serenity_Mesh_Reference
Dim SN_ID
End Type

Dim Serenity_Global_AN8ID_List[1]
Dim Serenity_Global_Mesh_List[3] As Serenity_Mesh


Type Serenity_Meshes_List_Structure 
Dim mesh_id0 As Serenity_Mesh_Reference 
Dim tree1 As Serenity_Mesh_Reference 
Dim house_mesh1 As Serenity_Mesh_Reference 
End Type

Type Serenity_Sky_Dome
Dim Image 
Dim hRes 
Dim vRes 
Dim TexturePCT 
Dim SpherePCT 
Dim Radius 
End Type 

Type Serenity_Sky_Box 
Dim Image_Left 
Dim Image_Right 
Dim Image_Top 
Dim Image_Bottom 
Dim Image_Front 
Dim Image_Back 
End Type 

Type Serenity_Sky_Structure
Dim Shape 
Dim Dome As Serenity_Sky_Dome 
Dim Box As Serenity_Sky_Box 
End Type 


Type Serenity_Actor_Physics
Dim Shape
Dim Mass
Dim isSolid
End Type

Type Serenity_Light_Properties
Dim LightType
Dim CastShadow
Dim InnerCone
Dim OuterCone
Dim Radius
Dim FallOff
Dim Ambient
Dim Diffuse
Dim Specular
Dim Constant
Dim Linear
Dim Quadratic
End Type

Type Serenity_Terrain_Properties
Dim HeightMap$
End Type

Type Serenity_ActorAnimation_Properties
Dim AnimationID
Dim NumLoops
End Type

Type Serenity_Water_Properties
Dim WaveHeight
Dim WaveLength
Dim WaveSpeed
End Type

Type Serenity_Particle_Properties
Dim ParticleType
Dim MinSize As Serenity_Size
Dim MaxSize As Serenity_Size
Dim MinStartColor
Dim MaxStartColor
Dim MinSpeed
Dim MaxSpeed
Dim MinLife
Dim MaxLife
Dim Normal As Serenity_Vector3D
Dim Direction As Serenity_Vector3D
Dim MaxAngle
Dim CircleCenter As Serenity_Vector3D
Dim Radius
Dim UseEveryVertex
Dim UseNormalDirection
Dim NormalDirectionModifier
Dim CylinderLength
Dim UseOutlineOnly
Dim MinBoxSize As Serenity_Size
Dim MaxBoxSize As Serenity_Size
Dim RingThickness
End Type

Type Serenity_Actor
Dim ID 
Dim SN_ID 
Dim Name$
Dim ActorType 
Dim Mesh  'Index in Global Mesh list
Dim Position As Serenity_Vector3D
Dim Rotation As Serenity_Vector3D
Dim Scale As Serenity_Vector3D
Dim Material
Dim Shadow
Dim AutoCulling
Dim Physics As Serenity_Actor_Physics
Dim Animation As Serenity_ActorAnimation_Properties
Dim Light As Serenity_Light_Properties
Dim Terrain As Serenity_Terrain_Properties
Dim Water As Serenity_Water_Properties
Dim Particle As Serenity_Particle_Properties
Dim CubeSize
Dim SphereRadius
Dim Visible
End Type 


Dim Textures As Serenity_Textures_List_Structure
'TEXTURES ARE LOADED AND UNLOADED WHEN LOADSTAGE() IS CALLED
Textures.sky.SN_ID = 0
Serenity_Global_Texture_List[Textures.sky.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sky.SN_ID].Name$ = "sky"
Serenity_Global_Texture_List[Textures.sky.SN_ID].File$ = "BlueSkySkybox.png"
Serenity_Global_Texture_List[Textures.sky.SN_ID].TextureColorKey = 0

Textures.grass.SN_ID = 1
Serenity_Global_Texture_List[Textures.grass.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.grass.SN_ID].Name$ = "grass"
Serenity_Global_Texture_List[Textures.grass.SN_ID].File$ = "grass2.png"
Serenity_Global_Texture_List[Textures.grass.SN_ID].TextureColorKey = 0

Textures.tree_texture1.SN_ID = 2
Serenity_Global_Texture_List[Textures.tree_texture1.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.tree_texture1.SN_ID].Name$ = "tree_texture1"
Serenity_Global_Texture_List[Textures.tree_texture1.SN_ID].File$ = "tree_texture1.png"
Serenity_Global_Texture_List[Textures.tree_texture1.SN_ID].TextureColorKey = 0

Textures.brick.SN_ID = 3
Serenity_Global_Texture_List[Textures.brick.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.brick.SN_ID].Name$ = "brick"
Serenity_Global_Texture_List[Textures.brick.SN_ID].File$ = "Brick 11 - 256x256.png"
Serenity_Global_Texture_List[Textures.brick.SN_ID].TextureColorKey = 0

Textures.roof.SN_ID = 4
Serenity_Global_Texture_List[Textures.roof.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.roof.SN_ID].Name$ = "roof"
Serenity_Global_Texture_List[Textures.roof.SN_ID].File$ = "Roof 1 - 256x256.png"
Serenity_Global_Texture_List[Textures.roof.SN_ID].TextureColorKey = 0


Dim Materials As Serenity_Materials_List_Structure
'-----------------DEFINE MATERIALS---------------
'------------MATERIAL[ material_n ]---------------
Materials.material_n.SN_ID = 0
Serenity_Global_Material_List[Materials.material_n.SN_ID].Name$ = "material_n"

Serenity_Global_Material_List[Materials.material_n.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, FALSE) 
SetMaterialType(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.material_n.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.material_n.SN_ID].Texture_Matrix, 0, 0, Textures.grass.SN_ID)


'------------MATERIAL[ tree_material1 ]---------------
Materials.tree_material1.SN_ID = 1
Serenity_Global_Material_List[Materials.tree_material1.SN_ID].Name$ = "tree_material1"

Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, AA_MODE_QUALITY ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, FALSE) 
SetMaterialType(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, MATERIAL_TYPE_TRANSPARENT_ALPHA_CHANNEL ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.tree_material1.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].Texture_Matrix, 0, 0, Textures.tree_texture1.SN_ID)


'------------MATERIAL[ house_material1 ]---------------
Materials.house_material1.SN_ID = 2
Serenity_Global_Material_List[Materials.house_material1.SN_ID].Name$ = "house_material1"

Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, FALSE) 
SetMaterialType(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.house_material1.SN_ID].Texture_Matrix = DimMatrix(1, 2)

SetMatrixValue(Serenity_Global_Material_List[Materials.house_material1.SN_ID].Texture_Matrix, 0, 0, Textures.brick.SN_ID)
SetMatrixValue(Serenity_Global_Material_List[Materials.house_material1.SN_ID].Texture_Matrix, 0, 1, Textures.roof.SN_ID)


'------------MATERIAL[ house_material2 ]---------------
Materials.house_material2.SN_ID = 3
Serenity_Global_Material_List[Materials.house_material2.SN_ID].Name$ = "house_material2"

Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, FALSE) 
SetMaterialType(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.house_material2.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.house_material2.SN_ID].Texture_Matrix, 0, 0, Textures.roof.SN_ID)


'------------MATERIAL[ house_window_material ]---------------
Materials.house_window_material.SN_ID = 4
Serenity_Global_Material_List[Materials.house_window_material.SN_ID].Name$ = "house_window_material"

Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, 4279067509) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, 4279067509) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, 4279067509) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, 4279067509) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, 0.5) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, BLEND_MODE_MIN_ALPHA ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.house_window_material.SN_ID].Texture_Matrix = DimMatrix(1, 0)




Dim Meshes As Serenity_Meshes_List_Structure
'-----------------DEFINE MESHES---------------
'-----MESH[ mesh_id0 ]------------
Meshes.mesh_id0.SN_ID = 0
Serenity_Global_Mesh_List[Meshes.mesh_id0.SN_ID].MeshType = SN_MESH_TYPE_NORMAL
Serenity_Global_Mesh_List[Meshes.mesh_id0.SN_ID].File$ = "!plane"

Serenity_Global_Mesh_List[Meshes.mesh_id0.SN_ID].AnimationCount = 0
Serenity_Global_Mesh_List[Meshes.mesh_id0.SN_ID].Animation_Matrix = DimMatrix(1, Serenity_Global_Mesh_List[Meshes.mesh_id0.SN_ID].AnimationCount)

Serenity_Global_Mesh_List[Meshes.mesh_id0.SN_ID].MaterialCount = 0
Serenity_Global_Mesh_List[Meshes.mesh_id0.SN_ID].Material_Matrix = DimMatrix(1, Serenity_Global_Mesh_List[Meshes.mesh_id0.SN_ID].MaterialCount)

'-----MESH[ tree1 ]------------
Meshes.tree1.SN_ID = 1
Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].MeshType = SN_MESH_TYPE_NORMAL
Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].File$ = "tree_texture1.obj"

Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].AnimationCount = 0
Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].Animation_Matrix = DimMatrix(1, Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].AnimationCount)

Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].MaterialCount = 1
Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].Material_Matrix = DimMatrix(1, Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].MaterialCount)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].Material_Matrix, 0, 0, Materials.tree_material1.SN_ID)

'-----MESH[ house_mesh1 ]------------
Meshes.house_mesh1.SN_ID = 2
Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].MeshType = SN_MESH_TYPE_NORMAL
Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].File$ = "housemodel.obj"

Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].AnimationCount = 0
Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].Animation_Matrix = DimMatrix(1, Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].AnimationCount)

Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].MaterialCount = 7
Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].Material_Matrix = DimMatrix(1, Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].MaterialCount)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].Material_Matrix, 0, 0, Materials.house_material1.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].Material_Matrix, 0, 1, Materials.house_material2.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].Material_Matrix, 0, 2, Materials.house_material2.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].Material_Matrix, 0, 3, Materials.house_material2.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].Material_Matrix, 0, 4, Materials.house_material1.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].Material_Matrix, 0, 5, Materials.house_window_material.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].Material_Matrix, 0, 6, Materials.house_material1.SN_ID)



Dim Serenity_Global_Actor_List[8] As Serenity_Actor

Type Serenity_Stage
Dim ID
Dim Name$
Dim ActorCount
Dim Actor_Matrix
Dim Sky As Serenity_Sky_Structure
Dim GroupName$[1]
Dim GroupCount
End Type
Dim Serenity_Global_Stage_List[1] As Serenity_Stage

Type Serenity_Current_Stage_Structure
Dim StageID
Dim HasSky
End Type

Dim Serenity_Current_Stage As Serenity_Current_Stage_Structure

'-----------------DEFINE STAGES---------------
'----------------INIT STAGE: [ stage1 ]-----------------------
Serenity_Global_Stage_List[0].ID = 0
Serenity_Global_Stage_List[0].Sky.Shape = SN_SKY_TYPE_DOME
Serenity_Global_Stage_List[0].Sky.Dome.Image = Textures.sky.SN_ID
Serenity_Global_Stage_List[0].Sky.Dome.hRes = 16
Serenity_Global_Stage_List[0].Sky.Dome.vRes = 16
Serenity_Global_Stage_List[0].Sky.Dome.TexturePCT = 1
Serenity_Global_Stage_List[0].Sky.Dome.SpherePCT = 40
Serenity_Global_Stage_List[0].Sky.Dome.Radius = 2000

Serenity_Global_Stage_List[0].Actor_Matrix = DimMatrix(2, 8)
'-----------ACTOR [ Serenity_Global_Stage_List[0].Actors.plane ]----------------
Serenity_Global_Actor_List[0].SN_ID = 0

SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 0, 0, 0)
SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 1, 0, -1)
Serenity_Global_Actor_List[0].ID = -1
Serenity_Global_Actor_List[0].ActorType = SN_ACTOR_TYPE_ANIMATED
Serenity_Global_Actor_List[0].Mesh = Meshes.mesh_id0.SN_ID
Serenity_Global_Actor_List[0].Position = Serenity_CreateVector3D(-87.4883, 86.7933, -81.1285)
Serenity_Global_Actor_List[0].Rotation = Serenity_CreateVector3D(0, 0, 0)
Serenity_Global_Actor_List[0].Scale = Serenity_CreateVector3D(1, 1, 1)
Serenity_Global_Actor_List[0].Material = Materials.material_n.SN_ID
Serenity_Global_Actor_List[0].Shadow = TRUE
Serenity_Global_Actor_List[0].AutoCulling = AUTOCULLING_BOX
Serenity_Global_Actor_List[0].Visible = TRUE
Serenity_Global_Actor_List[0].Physics.isSolid = TRUE
Serenity_Global_Actor_List[0].Physics.Mass = 0
Serenity_Global_Actor_List[0].Physics.Shape = 1

'-----------ACTOR [ Serenity_Global_Stage_List[0].Actors.tree1 ]----------------
Serenity_Global_Actor_List[1].SN_ID = 1

SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 0, 1, 1)
SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 1, 1, 0)
Serenity_Global_Actor_List[1].ID = -1
Serenity_Global_Actor_List[1].ActorType = SN_ACTOR_TYPE_ANIMATED
Serenity_Global_Actor_List[1].Mesh = Meshes.tree1.SN_ID
Serenity_Global_Actor_List[1].Position = Serenity_CreateVector3D(1162.03, 87.0033, -268.988)
Serenity_Global_Actor_List[1].Rotation = Serenity_CreateVector3D(0, 0, 0)
Serenity_Global_Actor_List[1].Scale = Serenity_CreateVector3D(88.5, 88.5, 88.5)
Serenity_Global_Actor_List[1].Shadow = TRUE
Serenity_Global_Actor_List[1].AutoCulling = AUTOCULLING_BOX
Serenity_Global_Actor_List[1].Visible = TRUE
Serenity_Global_Actor_List[1].Physics.isSolid = FALSE
Serenity_Global_Actor_List[1].Physics.Mass = 0
Serenity_Global_Actor_List[1].Physics.Shape = 1

'-----------ACTOR [ Serenity_Global_Stage_List[0].Actors.tree2 ]----------------
Serenity_Global_Actor_List[2].SN_ID = 2

SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 0, 2, 2)
SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 1, 2, 0)
Serenity_Global_Actor_List[2].ID = -1
Serenity_Global_Actor_List[2].ActorType = SN_ACTOR_TYPE_ANIMATED
Serenity_Global_Actor_List[2].Mesh = Meshes.tree1.SN_ID
Serenity_Global_Actor_List[2].Position = Serenity_CreateVector3D(1342.89, 81.5182, -1766.24)
Serenity_Global_Actor_List[2].Rotation = Serenity_CreateVector3D(0, 0, 0)
Serenity_Global_Actor_List[2].Scale = Serenity_CreateVector3D(90, 90, 90)
Serenity_Global_Actor_List[2].Shadow = TRUE
Serenity_Global_Actor_List[2].AutoCulling = AUTOCULLING_BOX
Serenity_Global_Actor_List[2].Visible = TRUE
Serenity_Global_Actor_List[2].Physics.isSolid = FALSE
Serenity_Global_Actor_List[2].Physics.Mass = 0
Serenity_Global_Actor_List[2].Physics.Shape = 1

'-----------ACTOR [ Serenity_Global_Stage_List[0].Actors.tree3 ]----------------
Serenity_Global_Actor_List[3].SN_ID = 3

SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 0, 3, 3)
SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 1, 3, 0)
Serenity_Global_Actor_List[3].ID = -1
Serenity_Global_Actor_List[3].ActorType = SN_ACTOR_TYPE_ANIMATED
Serenity_Global_Actor_List[3].Mesh = Meshes.tree1.SN_ID
Serenity_Global_Actor_List[3].Position = Serenity_CreateVector3D(1726.33, 96.2395, -1490.18)
Serenity_Global_Actor_List[3].Rotation = Serenity_CreateVector3D(0, 0, 0)
Serenity_Global_Actor_List[3].Scale = Serenity_CreateVector3D(90, 90, 90)
Serenity_Global_Actor_List[3].Shadow = TRUE
Serenity_Global_Actor_List[3].AutoCulling = AUTOCULLING_BOX
Serenity_Global_Actor_List[3].Visible = TRUE
Serenity_Global_Actor_List[3].Physics.isSolid = FALSE
Serenity_Global_Actor_List[3].Physics.Mass = 0
Serenity_Global_Actor_List[3].Physics.Shape = 1

'-----------ACTOR [ Serenity_Global_Stage_List[0].Actors.tree4 ]----------------
Serenity_Global_Actor_List[4].SN_ID = 4

SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 0, 4, 4)
SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 1, 4, 0)
Serenity_Global_Actor_List[4].ID = -1
Serenity_Global_Actor_List[4].ActorType = SN_ACTOR_TYPE_ANIMATED
Serenity_Global_Actor_List[4].Mesh = Meshes.tree1.SN_ID
Serenity_Global_Actor_List[4].Position = Serenity_CreateVector3D(1011.02, 84.3289, -1139.18)
Serenity_Global_Actor_List[4].Rotation = Serenity_CreateVector3D(0, 0, 0)
Serenity_Global_Actor_List[4].Scale = Serenity_CreateVector3D(90, 90, 90)
Serenity_Global_Actor_List[4].Shadow = TRUE
Serenity_Global_Actor_List[4].AutoCulling = AUTOCULLING_BOX
Serenity_Global_Actor_List[4].Visible = TRUE
Serenity_Global_Actor_List[4].Physics.isSolid = FALSE
Serenity_Global_Actor_List[4].Physics.Mass = 0
Serenity_Global_Actor_List[4].Physics.Shape = 1

'-----------ACTOR [ Serenity_Global_Stage_List[0].Actors.tree5 ]----------------
Serenity_Global_Actor_List[5].SN_ID = 5

SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 0, 5, 5)
SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 1, 5, 0)
Serenity_Global_Actor_List[5].ID = -1
Serenity_Global_Actor_List[5].ActorType = SN_ACTOR_TYPE_ANIMATED
Serenity_Global_Actor_List[5].Mesh = Meshes.tree1.SN_ID
Serenity_Global_Actor_List[5].Position = Serenity_CreateVector3D(1439.19, 72.4182, -929.675)
Serenity_Global_Actor_List[5].Rotation = Serenity_CreateVector3D(0, 0, 0)
Serenity_Global_Actor_List[5].Scale = Serenity_CreateVector3D(90, 90, 90)
Serenity_Global_Actor_List[5].Shadow = TRUE
Serenity_Global_Actor_List[5].AutoCulling = AUTOCULLING_BOX
Serenity_Global_Actor_List[5].Visible = TRUE
Serenity_Global_Actor_List[5].Physics.isSolid = FALSE
Serenity_Global_Actor_List[5].Physics.Mass = 0
Serenity_Global_Actor_List[5].Physics.Shape = 1

'-----------ACTOR [ Serenity_Global_Stage_List[0].Actors.tree5 ]----------------
Serenity_Global_Actor_List[6].SN_ID = 6

SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 0, 6, 6)
SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 1, 6, 0)
Serenity_Global_Actor_List[6].ID = -1
Serenity_Global_Actor_List[6].ActorType = SN_ACTOR_TYPE_ANIMATED
Serenity_Global_Actor_List[6].Mesh = Meshes.tree1.SN_ID
Serenity_Global_Actor_List[6].Position = Serenity_CreateVector3D(1217.21, 67.9114, 74.7491)
Serenity_Global_Actor_List[6].Rotation = Serenity_CreateVector3D(0, 0, 0)
Serenity_Global_Actor_List[6].Scale = Serenity_CreateVector3D(90, 90, 90)
Serenity_Global_Actor_List[6].Shadow = TRUE
Serenity_Global_Actor_List[6].AutoCulling = AUTOCULLING_BOX
Serenity_Global_Actor_List[6].Visible = TRUE
Serenity_Global_Actor_List[6].Physics.isSolid = FALSE
Serenity_Global_Actor_List[6].Physics.Mass = 0
Serenity_Global_Actor_List[6].Physics.Shape = 1

'-----------ACTOR [ Serenity_Global_Stage_List[0].Actors.house ]----------------
Serenity_Global_Actor_List[7].SN_ID = 7

SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 0, 7, 7)
SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 1, 7, -1)
Serenity_Global_Actor_List[7].ID = -1
Serenity_Global_Actor_List[7].ActorType = SN_ACTOR_TYPE_ANIMATED
Serenity_Global_Actor_List[7].Mesh = Meshes.house_mesh1.SN_ID
Serenity_Global_Actor_List[7].Position = Serenity_CreateVector3D(-990.383, 84.2548, -1193.71)
Serenity_Global_Actor_List[7].Rotation = Serenity_CreateVector3D(0, 59.1241, 0)
Serenity_Global_Actor_List[7].Scale = Serenity_CreateVector3D(35, 35, 35)
Serenity_Global_Actor_List[7].Shadow = TRUE
Serenity_Global_Actor_List[7].AutoCulling = AUTOCULLING_BOX
Serenity_Global_Actor_List[7].Visible = TRUE
Serenity_Global_Actor_List[7].Physics.isSolid = FALSE
Serenity_Global_Actor_List[7].Physics.Mass = 0
Serenity_Global_Actor_List[7].Physics.Shape = 1


'------------[STAGE LOAD FUNCTIONS]-----------
Sub Load_stage1( )
	Serenity_Current_Stage.StageID = 0

	'---------STAGE TEXTURES-------------
	Serenity_Global_Texture_List[ Serenity_Global_Stage_List[0].Sky.Dome.Image ].ID = LoadImage( "textures" + path_separator$ + Serenity_Global_Texture_List[Serenity_Global_Stage_List[0].Sky.Dome.Image].File$ )
	Serenity_Global_Texture_List[ Textures.grass.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.grass.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.tree_texture1.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.tree_texture1.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.brick.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.brick.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.roof.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.roof.SN_ID].File$)


	'---------STAGE MATERIALS-------------
	SetMaterialTexture(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.grass.SN_ID].ID ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.tree_texture1.SN_ID].ID ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.brick.SN_ID].ID ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, 1, Serenity_Global_Texture_List[Textures.roof.SN_ID].ID ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.roof.SN_ID].ID ) 


	'---------STAGE AN8-------------


	'---------STAGE MESHES-------------
	Serenity_Global_Mesh_List[Meshes.mesh_id0.SN_ID].ID = CreatePlaneMesh(100, 100, 50, 50, 10, 10)

	Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].ID = LoadMesh("models" + path_separator$ + "tree_texture1.obj")

	Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].ID = LoadMesh("models" + path_separator$ + "housemodel.obj")




	AddSceneSkyDomeEx( Serenity_Global_Texture_List[ Serenity_Global_Stage_List[0].Sky.Dome.Image ].ID, Serenity_Global_Stage_List[0].Sky.Dome.hRes, Serenity_Global_Stage_List[0].Sky.Dome.vRes, Serenity_Global_Stage_List[0].Sky.Dome.TexturePCT, Serenity_Global_Stage_List[0].Sky.Dome.SpherePCT, Serenity_Global_Stage_List[0].Sky.Dome.Radius ) 

	Serenity_Global_Actor_List[0].ID =  CreateAnimatedActor( Serenity_Global_Mesh_List[Serenity_Global_Actor_List[0].Mesh].ID ) 

	SetActorPosition( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Position.X, Serenity_Global_Actor_List[0].Position.Y, Serenity_Global_Actor_List[0].Position.Z ) 
	SetActorRotation( Serenity_Global_Actor_List[0].ID, 0, Serenity_Global_Actor_List[0].Rotation.Y, 0 ) 
	RotateActor( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Rotation.X, 0, 0 ) 
	RotateActor( Serenity_Global_Actor_List[0].ID, 0, 0, Serenity_Global_Actor_List[0].Rotation.Z ) 
	SetActorScale( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Scale.X, Serenity_Global_Actor_List[0].Scale.Y, Serenity_Global_Actor_List[0].Scale.Z ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 0, Serenity_Global_Material_List[ Materials.material_n.SN_ID ].ID )

	SetActorAnimation( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Animation.AnimationID, Serenity_Global_Actor_List[0].Animation.NumLoops ) 

	SetActorVisible( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Visible ) 
	SetActorAutoCulling( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].AutoCulling ) 
	AddActorShadow( Serenity_Global_Actor_List[0].ID ) 
	SetActorShape( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Physics.Shape, Serenity_Global_Actor_List[0].Physics.Mass ) 
	SetActorSolid( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Physics.isSolid ) 



	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 0, Serenity_Global_Material_List[Materials.material_n.SN_ID].ID )

	Serenity_Global_Actor_List[1].ID =  CreateAnimatedActor( Serenity_Global_Mesh_List[Serenity_Global_Actor_List[1].Mesh].ID ) 

	SetActorPosition( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Position.X, Serenity_Global_Actor_List[1].Position.Y, Serenity_Global_Actor_List[1].Position.Z ) 
	SetActorRotation( Serenity_Global_Actor_List[1].ID, 0, Serenity_Global_Actor_List[1].Rotation.Y, 0 ) 
	RotateActor( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Rotation.X, 0, 0 ) 
	RotateActor( Serenity_Global_Actor_List[1].ID, 0, 0, Serenity_Global_Actor_List[1].Rotation.Z ) 
	SetActorScale( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Scale.X, Serenity_Global_Actor_List[1].Scale.Y, Serenity_Global_Actor_List[1].Scale.Z ) 

	SetActorAnimation( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Animation.AnimationID, Serenity_Global_Actor_List[1].Animation.NumLoops ) 

	SetActorVisible( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Visible ) 
	SetActorAutoCulling( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].AutoCulling ) 
	AddActorShadow( Serenity_Global_Actor_List[1].ID ) 
	SetActorShape( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Physics.Shape, Serenity_Global_Actor_List[1].Physics.Mass ) 
	SetActorSolid( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Physics.isSolid ) 



	SetActorMaterial( Serenity_Global_Actor_List[1].ID, 0, Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID ) 

	Serenity_Global_Actor_List[2].ID =  CreateAnimatedActor( Serenity_Global_Mesh_List[Serenity_Global_Actor_List[2].Mesh].ID ) 

	SetActorPosition( Serenity_Global_Actor_List[2].ID, Serenity_Global_Actor_List[2].Position.X, Serenity_Global_Actor_List[2].Position.Y, Serenity_Global_Actor_List[2].Position.Z ) 
	SetActorRotation( Serenity_Global_Actor_List[2].ID, 0, Serenity_Global_Actor_List[2].Rotation.Y, 0 ) 
	RotateActor( Serenity_Global_Actor_List[2].ID, Serenity_Global_Actor_List[2].Rotation.X, 0, 0 ) 
	RotateActor( Serenity_Global_Actor_List[2].ID, 0, 0, Serenity_Global_Actor_List[2].Rotation.Z ) 
	SetActorScale( Serenity_Global_Actor_List[2].ID, Serenity_Global_Actor_List[2].Scale.X, Serenity_Global_Actor_List[2].Scale.Y, Serenity_Global_Actor_List[2].Scale.Z ) 

	SetActorAnimation( Serenity_Global_Actor_List[2].ID, Serenity_Global_Actor_List[2].Animation.AnimationID, Serenity_Global_Actor_List[2].Animation.NumLoops ) 

	SetActorVisible( Serenity_Global_Actor_List[2].ID, Serenity_Global_Actor_List[2].Visible ) 
	SetActorAutoCulling( Serenity_Global_Actor_List[2].ID, Serenity_Global_Actor_List[2].AutoCulling ) 
	AddActorShadow( Serenity_Global_Actor_List[2].ID ) 
	SetActorShape( Serenity_Global_Actor_List[2].ID, Serenity_Global_Actor_List[2].Physics.Shape, Serenity_Global_Actor_List[2].Physics.Mass ) 
	SetActorSolid( Serenity_Global_Actor_List[2].ID, Serenity_Global_Actor_List[2].Physics.isSolid ) 



	SetActorMaterial( Serenity_Global_Actor_List[2].ID, 0, Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID ) 

	Serenity_Global_Actor_List[3].ID =  CreateAnimatedActor( Serenity_Global_Mesh_List[Serenity_Global_Actor_List[3].Mesh].ID ) 

	SetActorPosition( Serenity_Global_Actor_List[3].ID, Serenity_Global_Actor_List[3].Position.X, Serenity_Global_Actor_List[3].Position.Y, Serenity_Global_Actor_List[3].Position.Z ) 
	SetActorRotation( Serenity_Global_Actor_List[3].ID, 0, Serenity_Global_Actor_List[3].Rotation.Y, 0 ) 
	RotateActor( Serenity_Global_Actor_List[3].ID, Serenity_Global_Actor_List[3].Rotation.X, 0, 0 ) 
	RotateActor( Serenity_Global_Actor_List[3].ID, 0, 0, Serenity_Global_Actor_List[3].Rotation.Z ) 
	SetActorScale( Serenity_Global_Actor_List[3].ID, Serenity_Global_Actor_List[3].Scale.X, Serenity_Global_Actor_List[3].Scale.Y, Serenity_Global_Actor_List[3].Scale.Z ) 

	SetActorAnimation( Serenity_Global_Actor_List[3].ID, Serenity_Global_Actor_List[3].Animation.AnimationID, Serenity_Global_Actor_List[3].Animation.NumLoops ) 

	SetActorVisible( Serenity_Global_Actor_List[3].ID, Serenity_Global_Actor_List[3].Visible ) 
	SetActorAutoCulling( Serenity_Global_Actor_List[3].ID, Serenity_Global_Actor_List[3].AutoCulling ) 
	AddActorShadow( Serenity_Global_Actor_List[3].ID ) 
	SetActorShape( Serenity_Global_Actor_List[3].ID, Serenity_Global_Actor_List[3].Physics.Shape, Serenity_Global_Actor_List[3].Physics.Mass ) 
	SetActorSolid( Serenity_Global_Actor_List[3].ID, Serenity_Global_Actor_List[3].Physics.isSolid ) 



	SetActorMaterial( Serenity_Global_Actor_List[3].ID, 0, Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID ) 

	Serenity_Global_Actor_List[4].ID =  CreateAnimatedActor( Serenity_Global_Mesh_List[Serenity_Global_Actor_List[4].Mesh].ID ) 

	SetActorPosition( Serenity_Global_Actor_List[4].ID, Serenity_Global_Actor_List[4].Position.X, Serenity_Global_Actor_List[4].Position.Y, Serenity_Global_Actor_List[4].Position.Z ) 
	SetActorRotation( Serenity_Global_Actor_List[4].ID, 0, Serenity_Global_Actor_List[4].Rotation.Y, 0 ) 
	RotateActor( Serenity_Global_Actor_List[4].ID, Serenity_Global_Actor_List[4].Rotation.X, 0, 0 ) 
	RotateActor( Serenity_Global_Actor_List[4].ID, 0, 0, Serenity_Global_Actor_List[4].Rotation.Z ) 
	SetActorScale( Serenity_Global_Actor_List[4].ID, Serenity_Global_Actor_List[4].Scale.X, Serenity_Global_Actor_List[4].Scale.Y, Serenity_Global_Actor_List[4].Scale.Z ) 

	SetActorAnimation( Serenity_Global_Actor_List[4].ID, Serenity_Global_Actor_List[4].Animation.AnimationID, Serenity_Global_Actor_List[4].Animation.NumLoops ) 

	SetActorVisible( Serenity_Global_Actor_List[4].ID, Serenity_Global_Actor_List[4].Visible ) 
	SetActorAutoCulling( Serenity_Global_Actor_List[4].ID, Serenity_Global_Actor_List[4].AutoCulling ) 
	AddActorShadow( Serenity_Global_Actor_List[4].ID ) 
	SetActorShape( Serenity_Global_Actor_List[4].ID, Serenity_Global_Actor_List[4].Physics.Shape, Serenity_Global_Actor_List[4].Physics.Mass ) 
	SetActorSolid( Serenity_Global_Actor_List[4].ID, Serenity_Global_Actor_List[4].Physics.isSolid ) 



	SetActorMaterial( Serenity_Global_Actor_List[4].ID, 0, Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID ) 

	Serenity_Global_Actor_List[5].ID =  CreateAnimatedActor( Serenity_Global_Mesh_List[Serenity_Global_Actor_List[5].Mesh].ID ) 

	SetActorPosition( Serenity_Global_Actor_List[5].ID, Serenity_Global_Actor_List[5].Position.X, Serenity_Global_Actor_List[5].Position.Y, Serenity_Global_Actor_List[5].Position.Z ) 
	SetActorRotation( Serenity_Global_Actor_List[5].ID, 0, Serenity_Global_Actor_List[5].Rotation.Y, 0 ) 
	RotateActor( Serenity_Global_Actor_List[5].ID, Serenity_Global_Actor_List[5].Rotation.X, 0, 0 ) 
	RotateActor( Serenity_Global_Actor_List[5].ID, 0, 0, Serenity_Global_Actor_List[5].Rotation.Z ) 
	SetActorScale( Serenity_Global_Actor_List[5].ID, Serenity_Global_Actor_List[5].Scale.X, Serenity_Global_Actor_List[5].Scale.Y, Serenity_Global_Actor_List[5].Scale.Z ) 

	SetActorAnimation( Serenity_Global_Actor_List[5].ID, Serenity_Global_Actor_List[5].Animation.AnimationID, Serenity_Global_Actor_List[5].Animation.NumLoops ) 

	SetActorVisible( Serenity_Global_Actor_List[5].ID, Serenity_Global_Actor_List[5].Visible ) 
	SetActorAutoCulling( Serenity_Global_Actor_List[5].ID, Serenity_Global_Actor_List[5].AutoCulling ) 
	AddActorShadow( Serenity_Global_Actor_List[5].ID ) 
	SetActorShape( Serenity_Global_Actor_List[5].ID, Serenity_Global_Actor_List[5].Physics.Shape, Serenity_Global_Actor_List[5].Physics.Mass ) 
	SetActorSolid( Serenity_Global_Actor_List[5].ID, Serenity_Global_Actor_List[5].Physics.isSolid ) 



	SetActorMaterial( Serenity_Global_Actor_List[5].ID, 0, Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID ) 

	Serenity_Global_Actor_List[6].ID =  CreateAnimatedActor( Serenity_Global_Mesh_List[Serenity_Global_Actor_List[6].Mesh].ID ) 

	SetActorPosition( Serenity_Global_Actor_List[6].ID, Serenity_Global_Actor_List[6].Position.X, Serenity_Global_Actor_List[6].Position.Y, Serenity_Global_Actor_List[6].Position.Z ) 
	SetActorRotation( Serenity_Global_Actor_List[6].ID, 0, Serenity_Global_Actor_List[6].Rotation.Y, 0 ) 
	RotateActor( Serenity_Global_Actor_List[6].ID, Serenity_Global_Actor_List[6].Rotation.X, 0, 0 ) 
	RotateActor( Serenity_Global_Actor_List[6].ID, 0, 0, Serenity_Global_Actor_List[6].Rotation.Z ) 
	SetActorScale( Serenity_Global_Actor_List[6].ID, Serenity_Global_Actor_List[6].Scale.X, Serenity_Global_Actor_List[6].Scale.Y, Serenity_Global_Actor_List[6].Scale.Z ) 

	SetActorAnimation( Serenity_Global_Actor_List[6].ID, Serenity_Global_Actor_List[6].Animation.AnimationID, Serenity_Global_Actor_List[6].Animation.NumLoops ) 

	SetActorVisible( Serenity_Global_Actor_List[6].ID, Serenity_Global_Actor_List[6].Visible ) 
	SetActorAutoCulling( Serenity_Global_Actor_List[6].ID, Serenity_Global_Actor_List[6].AutoCulling ) 
	AddActorShadow( Serenity_Global_Actor_List[6].ID ) 
	SetActorShape( Serenity_Global_Actor_List[6].ID, Serenity_Global_Actor_List[6].Physics.Shape, Serenity_Global_Actor_List[6].Physics.Mass ) 
	SetActorSolid( Serenity_Global_Actor_List[6].ID, Serenity_Global_Actor_List[6].Physics.isSolid ) 



	SetActorMaterial( Serenity_Global_Actor_List[6].ID, 0, Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID ) 

	Serenity_Global_Actor_List[7].ID =  CreateAnimatedActor( Serenity_Global_Mesh_List[Serenity_Global_Actor_List[7].Mesh].ID ) 

	SetActorPosition( Serenity_Global_Actor_List[7].ID, Serenity_Global_Actor_List[7].Position.X, Serenity_Global_Actor_List[7].Position.Y, Serenity_Global_Actor_List[7].Position.Z ) 
	SetActorRotation( Serenity_Global_Actor_List[7].ID, 0, Serenity_Global_Actor_List[7].Rotation.Y, 0 ) 
	RotateActor( Serenity_Global_Actor_List[7].ID, Serenity_Global_Actor_List[7].Rotation.X, 0, 0 ) 
	RotateActor( Serenity_Global_Actor_List[7].ID, 0, 0, Serenity_Global_Actor_List[7].Rotation.Z ) 
	SetActorScale( Serenity_Global_Actor_List[7].ID, Serenity_Global_Actor_List[7].Scale.X, Serenity_Global_Actor_List[7].Scale.Y, Serenity_Global_Actor_List[7].Scale.Z ) 

	SetActorAnimation( Serenity_Global_Actor_List[7].ID, Serenity_Global_Actor_List[7].Animation.AnimationID, Serenity_Global_Actor_List[7].Animation.NumLoops ) 

	SetActorVisible( Serenity_Global_Actor_List[7].ID, Serenity_Global_Actor_List[7].Visible ) 
	SetActorAutoCulling( Serenity_Global_Actor_List[7].ID, Serenity_Global_Actor_List[7].AutoCulling ) 
	AddActorShadow( Serenity_Global_Actor_List[7].ID ) 
	SetActorShape( Serenity_Global_Actor_List[7].ID, Serenity_Global_Actor_List[7].Physics.Shape, Serenity_Global_Actor_List[7].Physics.Mass ) 
	SetActorSolid( Serenity_Global_Actor_List[7].ID, Serenity_Global_Actor_List[7].Physics.isSolid ) 



	SetActorMaterial( Serenity_Global_Actor_List[7].ID, 0, Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[7].ID, 1, Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[7].ID, 2, Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[7].ID, 3, Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[7].ID, 4, Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[7].ID, 5, Serenity_Global_Material_List[Materials.house_window_material.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[7].ID, 6, Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID ) 

End Sub





'------------[STAGE CLEAR FUNCTIONS]-----------
Sub Clear_stage1( )
	Serenity_Current_Stage.StageID = -1
	RemoveSceneSky()
	DeleteImage( Serenity_Global_Texture_List[ Serenity_Global_Stage_List[0].Sky.Dome.Image ].ID )

	'---------STAGE ACTORS-------------
	DeleteActor( Serenity_Global_Actor_List[0].ID )
	Serenity_Global_Actor_List[0].ID = -1
	DeleteActor( Serenity_Global_Actor_List[1].ID )
	Serenity_Global_Actor_List[1].ID = -1
	DeleteActor( Serenity_Global_Actor_List[2].ID )
	Serenity_Global_Actor_List[2].ID = -1
	DeleteActor( Serenity_Global_Actor_List[3].ID )
	Serenity_Global_Actor_List[3].ID = -1
	DeleteActor( Serenity_Global_Actor_List[4].ID )
	Serenity_Global_Actor_List[4].ID = -1
	DeleteActor( Serenity_Global_Actor_List[5].ID )
	Serenity_Global_Actor_List[5].ID = -1
	DeleteActor( Serenity_Global_Actor_List[6].ID )
	Serenity_Global_Actor_List[6].ID = -1
	DeleteActor( Serenity_Global_Actor_List[7].ID )
	Serenity_Global_Actor_List[7].ID = -1
	'---------STAGE MESHES-------------
	DeleteMesh( Serenity_Global_Mesh_List[Meshes.mesh_id0.SN_ID].ID )
	Serenity_Global_Mesh_List[Meshes.mesh_id0.SN_ID].ID = -1

	DeleteMesh( Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].ID )
	Serenity_Global_Mesh_List[Meshes.tree1.SN_ID].ID = -1

	DeleteMesh( Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].ID )
	Serenity_Global_Mesh_List[Meshes.house_mesh1.SN_ID].ID = -1



	'---------STAGE AN8-------------


	'---------STAGE MATERIALS-------------
	SetMaterialTexture(Serenity_Global_Material_List[Materials.material_n.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.tree_material1.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.house_material1.SN_ID].ID, 1, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.house_material2.SN_ID].ID, 0, -1 ) 


	'---------STAGE TEXTURES-------------
	DeleteImage( Serenity_Global_Texture_List[ Textures.grass.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.grass.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.tree_texture1.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.tree_texture1.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.brick.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.brick.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.roof.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.roof.SN_ID ].ID = -1


End Sub







'------------[API FUNCTIONS]-------------------
'-------TEXTURES-------
Function Serenity_GetTextureIndex(texture_name$)
	For i = 0 To 4
		If Serenity_Global_Texture_List[i].Name$ = texture_name$ Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetTextureCount()
	Return 5
End Function

Function Serenity_GetTextureID(texture_index)
	If texture_index < 0 Or texture_index >= 5 Then
		Return -1
	End If
	Return Serenity_Global_Texture_List[texture_index].ID
End Function

Function Serenity_GetTextureFile$(texture_index)
	If texture_index < 0 Or texture_index >= 5 Then
		Return ""
	End If
	Return Serenity_Global_Texture_List[texture_index].File$
End Function

Function Serenity_GetTextureColorKey(texture_index)
	If texture_index < 0 Or texture_index >= 5 Then
		Return 0
	End If
	Return Serenity_Global_Texture_List[texture_index].TextureColorKey
End Function

Function Serenity_GetTextureIsColorKey(texture_index)
	If texture_index < 0 Or texture_index >= 5 Then
		Return FALSE
	End If
	Return Serenity_Global_Texture_List[texture_index].UseColorKey
End Function

'-------MATERIALS-------
Function Serenity_GetMaterialIndex(material_name$)
	For i = 0 To 4
		If Serenity_Global_Material_List[i].Name$ = material_name$ Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetMaterialCount()
	Return 5
End Function

Function Serenity_GetMaterialID(material_index)
	If material_index < 0 Or material_index >= 5 Then
		Return -1
	End If
	Return Serenity_Global_Material_List[material_index].ID
End Function

Function Serenity_GetMaterialTextureIndex(material_index, texture_level)
	If material_index < 0 Or material_index >= 5 Then
		Return -1
	End If
	Dim r, c
	GetMatrixSize(Serenity_Global_Material_List[material_index].Texture_Matrix, r, c)
	If texture_level < 0 Or texture_level >= c Then
		Return -1
	End If
	Return MatrixValue(Serenity_Global_Material_List[material_index].Texture_Matrix, 0, texture_level)
End Function

'-------AN8-------
Function Serenity_GetAN8Count()
	Return 0
End Function

Function Serenity_GetAN8ID(an8_index)
	If an8_index < 0 Or an8_index >= 0 Then
		Return -1
	End If
	Return Serenity_Global_AN8ID_List[an8_index]
End Function

'-------MESHES-------
Function Serenity_GetMeshIndex(mesh_name$)
	For i = 0 To 2
		If Serenity_Global_Mesh_List[i].Name$ = mesh_name$ Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetMeshCount()
	Return 3
End Function

Function Serenity_GetMeshID(mesh_index)
	If mesh_index < 0 Or mesh_index >= 3 Then
		Return -1
	End If
	Return Serenity_Global_Mesh_List[mesh_index].ID
End Function

Function Serenity_GetMeshName$(mesh_index)
	If mesh_index < 0 Or mesh_index >= 3 Then
		Return ""
	End If
	Return Serenity_Global_Mesh_List[mesh_index].Name$
End Function

Function Serenity_GetMeshType(mesh_index)
	If mesh_index < 0 Or mesh_index >= 3 Then
		Return -1
	End If
	Return Serenity_Global_Mesh_List[mesh_index].MeshType
End Function

Function Serenity_GetMeshAN8Index(mesh_index)
	If mesh_index < 0 Or mesh_index >= 3 Then
		Return -1
	End If
	Return Serenity_Global_Mesh_List[mesh_index].AN8_Index
End Function

Function Serenity_GetMeshAN8Scene$(mesh_index)
	If mesh_index < 0 Or mesh_index >= 3 Then
		Return ""
	End If
	Return Serenity_Global_Mesh_List[mesh_index].AN8_Scene$
End Function

Function Serenity_GetMeshArchiveName$(mesh_index)
	If mesh_index < 0 Or mesh_index >= 3 Then
		Return ""
	End If
	Return Serenity_Global_Mesh_List[mesh_index].Zip$
End Function

Function Serenity_GetMeshFile$(mesh_index)
	If mesh_index < 0 Or mesh_index >= 3 Then
		Return ""
	End If
	Return Serenity_Global_Mesh_List[mesh_index].File$
End Function

Function Serenity_GetMeshMaterialCount(mesh_index)
	If mesh_index < 0 Or mesh_index >= 3 Then
		Return 0
	End If
	Return Serenity_Global_Mesh_List[mesh_index].MaterialCount
End Function

Function Serenity_GetMeshMaterialIndex(mesh_index, material_num)
	If mesh_index < 0 Or mesh_index >= 3 Then
		Return -1
	End If
	If material_num < 0 Or material_num >= Serenity_Global_Mesh_List[mesh_index].MaterialCount Then
		Return -1
	End If
	Return MatrixValue(Serenity_Global_Mesh_List[mesh_index].Material_Matrix, 0, material_num)
End Function

Function Serenity_GetMeshAnimationCount(mesh_index)
	If mesh_index < 0 Or mesh_index >= 3 Then
		Return 0
	End If
	Return Serenity_Global_Mesh_List[mesh_index].AnimationCount
End Function

Function Serenity_GetMeshAnimationID(mesh_index, animation_num)
	If mesh_index < 0 Or mesh_index >= 3 Then
		Return -1
	End If
	If animation_num < 0 Or animation_num >= Serenity_Global_Mesh_List[mesh_index].AnimationCount Then
		Return -1
	End If
	Return MatrixValue(Serenity_Global_Mesh_List[mesh_index].Animation_Matrix, 0, animation_num)
End Function

'-------SKY-------
Function Serenity_GetSkyShape()
	If Serenity_Current_Stage.StageID < 0 Then
		Return -1
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].Sky.Shape
End Function

Function Serenity_GetSkyBox() As Serenity_Sky_Box
	If Serenity_Current_Stage.StageID < 0 Then
		Dim tmp_sky As Serenity_Sky_Box
		Return tmp_sky
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].Sky.Box
End Function

Function Serenity_GetSkyDome() As Serenity_Sky_Dome
	If Serenity_Current_Stage.StageID < 0 Then
		Dim tmp_sky As Serenity_Sky_Dome
		Return tmp_sky
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].Sky.Dome
End Function

Function Serenity_StageHasSky()
	If Serenity_Current_Stage.StageID < 0 Then
		Return FALSE
	End If
	Return Serenity_Current_Stage.HasSky
End Function

'-------ACTORS-------
Function Serenity_GetActorIndex(actor_name$)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	For i = 0 To Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount-1
		If Serenity_Global_Actor_List[i].Name$ = actor_name$ Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetActorCount()
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return 0
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount
End Function

Function Serenity_GetActorID(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].ID
End Function

Function Serenity_GetActorName$(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return ""
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return ""
	End If
	Return Serenity_Global_Actor_List[actor_index].Name$
End Function

Function Serenity_GetActorType(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].ActorType
End Function

Function Serenity_GetActorMeshIndex(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].Mesh
End Function

Function Serenity_GetActorOverrideMaterialIndex(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].Material
End Function

Function Serenity_GetActorTerrainHeightMap$(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return ""
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return ""
	End If
	Return Serenity_Global_Actor_List[actor_index].Terrain.HeightMap$
End Function

Function Serenity_GetActorCubeSize(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].CubeSize
End Function

Function Serenity_GetActorSphereRadius(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].SphereRadius
End Function

Function Serenity_GetActorGroupIndex(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return MatrixValue(Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].Actor_Matrix, 1, actor_index)
End Function

'-------STAGES-------
Function Serenity_GetStageIndex(stage_name$)
	For i = 0 To 0
		If Serenity_Global_Stage_List[i].Name$ = stage_name$ Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetStageName$(stage_index)
	If stage_index < 0 Or stage_index >= 1 Then
		Return ""
	End If
	Return Serenity_Global_Stage_List[stage_index].Name$
End Function

Function Serenity_GetStageCount()
	Return 1
End Function

Sub Serenity_ClearStage()
	Select Case Serenity_Current_Stage.StageID
	Case 0 : Clear_stage1()
	End Select
End Sub

Sub Serenity_LoadStage(stage_name$)
	Serenity_ClearStage()
	Select Case stage_name$
	Case "stage1" : Load_stage1()
	End Select
End Sub

Function Serenity_GetCurrentStageIndex()
	Return Serenity_Current_Stage.StageID
End Function

'-------GROUPS-------
Function Serenity_GetGroupCount()
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return 0
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].GroupCount
End Function

Function Serenity_GetGroupIndex(group_name$)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return 0
	End If
	For i = 0 To Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].GroupCount-1
		If UCase$(Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].GroupName$[i]) = UCase$(group_name) Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetGroupName$(group_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return ""
	End If
	If group_index < 0 Or group_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].GroupCount Then
		Return ""
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].GroupName$[group_index]
End Function



Include Once
