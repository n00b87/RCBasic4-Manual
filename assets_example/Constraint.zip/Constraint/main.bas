'----------------------------------------------------------------
'   TITLE: 3D Constraint Demo
'   AUTHOR: n00b
'   DATE: Dec 13, 2024
'
'   DESCRIPTION: Shows how to use a constraint to limit actors
'                motion
'----------------------------------------------------------------

sub cam_control(cam_canvas)
	current_canvas = ActiveCanvas()
	If Key(K_W) Then
		Canvas(cam_canvas)
		TranslateCamera(0,0,1)
    ElseIf Key(K_S) Then
		Canvas(cam_canvas)
		TranslateCamera(0,0,-1)
	End If

	If Key(K_A) Then 
		Canvas(cam_canvas)
		TranslateCamera(-1,0,0)
	ElseIf Key(K_D) Then
		Canvas(cam_canvas)
		TranslateCamera(1,0,0)
	End If

	If Key(K_R) Then
		Canvas(cam_canvas)
		Dim crx, cry, crz
		GetCameraPosition(crx, cry, crz)
		SetCameraPosition(crx, cry+1, crz)
	ElseIf Key(K_F) Then
		Canvas(cam_canvas)
		'TranslateCameraW(0, -10, 0) - Haven't added this function yet
		Dim crx, cry, crz
		GetCameraPosition(crx, cry, crz)
		SetCameraPosition(crx, cry-1, crz)
	End If


	If Key(K_UP) Then
		Canvas(cam_canvas)
		RotateCamera(1, 0, 0)
	ElseIf Key(K_DOWN) Then
		Canvas(cam_canvas)
		RotateCamera(-1, 0, 0)
	End If

	If Key(K_LEFT) Then
		Canvas(cam_canvas)
		Dim crx, cry, crz
		GetCameraRotation(crx, cry, crz)

		RotateCamera(-1*crx, 0, 0)
		RotateCamera(0, -1, 0)
		RotateCamera(crx, 0, 0)
	ElseIf Key(K_RIGHT) Then
		Canvas(cam_canvas)
		Dim crx, cry, crz
		GetCameraRotation(crx, cry, crz)
		SetCameraRotation(crx, cry+1, crz)
	End If
	
	Canvas(current_canvas)
end sub

window_width = 640
window_height= 480
fullscreen = false
vsync = false

OpenWindow( "Constraint Demo", window_width, window_height, fullscreen, vsync )

SetFPS(60)

scene_canvas = OpenCanvas3D(0, 0, window_width, window_height, 0)
ui_canvas = OpenCanvas(window_width, window_height, 0, 0, window_width, window_height, 0)
SetCanvasZ(ui_canvas, 0)

Canvas(ui_canvas)
ClearCanvas()
m_font = LoadFont("FreeMono.ttf", 12)
SetFont(m_font)
SetColor(RGB(255,255,255))
DrawText("W/A/S/D TO MOVE", 10, 10)
DrawText("R/F TO MOVE UP AND DOWN", 10, 30)
DrawText("ARROW KEYS TO TURN", 10, 50)

Canvas(scene_canvas)


ground2 = CreateCubeActor(100)
ground2_material = GetActorMaterial(ground2, 0)
SetMaterialLighting(ground2_material, true)
SetMaterialEmissiveColor(ground2_material, RGB(0,120,0))
ScaleActor(ground2, 100, 1, 100)
SetActorSolid(ground2, true)
SetActorShape(ground2, ACTOR_SHAPE_BOX, 0)



'test_mesh = LoadMesh("char.ms3d")
'test_texture = LoadImage("tx.png")

test_mesh = CreateCylinderMesh(10, 20, 8, RGB(255,0,0), TRUE)

test_obj = CreateAnimatedActor(test_mesh)
test_material = GetActorMaterial(test_obj, 0)
SetMaterialLighting(test_material, true)
SetMaterialEmissiveColor(test_material, RGB(200,0,0))
'SetMaterialTexture(test_material, 0, test_texture)
TranslateActorWorld(test_obj, 0, 100, 0)
SetActorSolid(test_obj, true)
RotateActor(test_obj, 0, 0, 90)
SetActorShapeEx(test_obj, ACTOR_SHAPE_CYLINDER, 10, 10)
Dim test_gx, test_gy, test_gz
GetActorGravity(test_obj, test_gx, test_gy, test_gz)
SetActorGravity(test_obj, test_gx, test_gy+5, test_gz)

'RotateActor(test_obj, 0, 0, 90)


Canvas(scene_canvas)
SetCameraPosition(-7.7, 52.8, 0.75)
SetCameraRotation(0, 105, 0)
RotateCamera(17, 0, 0)

t = Timer()
While Timer()-t < 1000: PreUpdate(): Wend


While Not Key(K_ESCAPE)
	
	If Key(K_1) Then
		Dim cam_x, cam_y, cam_z, cam_rx, cam_ry, cam_rz
		GetCameraPosition(cam_x, cam_y, cam_z)
		GetCameraRotation(cam_rx, cam_ry, cam_rz)
		Print "Camera: pos=("; cam_x; ", "; cam_y; ", "; cam_z; ") ";
		Print " rot=("; cam_rx; ", "; cam_ry; ", "; cam_rz; ") "
		'SetActorLinearFactor(test_obj, 20, 0, 0)
	ElseIf Key(K_2) Then
		ApplyActorCentralImpulseLocal(test_obj, 10, 20, 0)
	End If
	
	cam_control(scene_canvas)
	
	Canvas(scene_canvas)
	'PreUpdate()
	Dim sx, sy, sz
	Dim gx, gy, gz
	'GetActorPosition(sphere, sx, sy, sz)
	'GetActorPosition(ground, gx, gy, gz)
	Dim vx, vy
	GetWorldToViewportPosition(sx, sy, sz, vx, vy)
	
	
	SetColor(RGB(255,255,255))
	Line3D(gx, gy, gz, sx, sy, sz)
	
	Update()
Wend
