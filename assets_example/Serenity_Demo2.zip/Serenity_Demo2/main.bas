'----------------------------------------------------------------
'   TITLE: Sponza
'   AUTHOR: n00b
'   DATE: Nov 19, 2025
'
'   DESCRIPTION: Render level with multiple materials and effects
'
'----------------------------------------------------------------


Include "serenity.bas"

Type Ambient_FPS_Controller
	Dim ControlCanvas
	Dim MoveSpeed
	Dim Sensitivity
	Dim mx
	Dim my
	Dim prev_mx
	Dim prev_my
	Dim mb1
	Dim mb2
	Dim mb3
End Type

Type Ambient_IO
	'Dim KeyPressed[10] 'Only Tracks up to 10 key presses per frame
	'Dim Joystick[AMBIENT_MAX_JOYSTICKS] As Ambient_Joystick
	'Dim Action[30] As Ambient_ActionKey
	Dim FPS_CameraControl As Ambient_FPS_Controller
End Type

Type Ambient_GameState
	Dim State
End Type

Type Ambient_Core
	'Dim WindowSize As Ambient_Size
	Dim VSync
	Dim TargetFPS
	Dim Fullscreen
	
	Dim IO As Ambient_IO
	
	Dim GameState As Ambient_GameState
End Type

Dim Core As Ambient_Core


Core.IO.FPS_CameraControl.MoveSpeed = 30
Core.IO.FPS_CameraControl.Sensitivity = 0.5


Sub Ambient_MouseDelta_FPS(ByRef dx, ByRef dy)
	move_mouse = false
	
	Core.IO.FPS_CameraControl.prev_mx = Core.IO.FPS_CameraControl.mx
	Core.IO.FPS_CameraControl.prev_my = Core.IO.FPS_CameraControl.my
	
	GetMouse(Core.IO.FPS_CameraControl.mx, Core.IO.FPS_CameraControl.my, Core.IO.FPS_CameraControl.mb1, Core.IO.FPS_CameraControl.mb2, Core.IO.FPS_CameraControl.mb3)
	
	Dim w, h
	GetCanvasSize(Core.IO.FPS_CameraControl.ControlCanvas, w, h)
	w = w-1
	h = h-1
	
	If Core.IO.FPS_CameraControl.mx <= 0 And Core.IO.FPS_CameraControl.prev_mx > 0 Then
		Core.IO.FPS_CameraControl.mx = w
		move_mouse = True
	ElseIf Core.IO.FPS_CameraControl.mx >= w And Core.IO.FPS_CameraControl.prev_mx < w Then
		Core.IO.FPS_CameraControl.mx = 0
		move_mouse = True
	End If
    
  If Core.IO.FPS_CameraControl.my <= 0 And Core.IO.FPS_CameraControl.prev_my > 0 Then
		Core.IO.FPS_CameraControl.my = h
		move_mouse = True
	ElseIf Core.IO.FPS_CameraControl.my >= h And Core.IO.FPS_CameraControl.prev_my < h Then
		Core.IO.FPS_CameraControl.my = 0
		move_mouse = True
	End If
	
	If move_mouse Then
		WarpMouse(Core.IO.FPS_CameraControl.mx, Core.IO.FPS_CameraControl.my)
		dx = 0
		dy = 0
	Else
		dx = Core.IO.FPS_CameraControl.mx - Core.IO.FPS_CameraControl.prev_mx
		dy = Core.IO.FPS_CameraControl.my - Core.IO.FPS_CameraControl.prev_my
	End If
End Sub


Sub Ambient_FPSControl()
	If Core.IO.FPS_CameraControl.ControlCanvas < 0 Then
		Return
	End If
	
	
	current_canvas = ActiveCanvas()
	Canvas(Core.IO.FPS_CameraControl.ControlCanvas)

	Dim dx, dy
	Ambient_MouseDelta_FPS(dx, dy)
	
	dx = dx * Core.IO.FPS_CameraControl.Sensitivity
	dy = dy * Core.IO.FPS_CameraControl.Sensitivity
	
	dim xr,yr,zr
	GetCameraRotation(xr, yr, zr)
	SetCameraRotation(xr, yr+dx, zr)
	
	GetCameraRotation(xr, yr, zr)
	
	mxr = (xr + dy) MOD 180
	If mxr > -70 And mxr < 70 Then
		RotateCamera(dy, 0, 0)
	End If
	
	If Key(K_W) Then
		TranslateCamera(0,0,Core.IO.FPS_CameraControl.MoveSpeed)
    ElseIf Key(K_S) Then
		TranslateCamera(0,0,-1*Core.IO.FPS_CameraControl.MoveSpeed)
	End If

	If Key(K_A) Then 
		TranslateCamera(-1*Core.IO.FPS_CameraControl.MoveSpeed,0,0)
	ElseIf Key(K_D) Then
		TranslateCamera(Core.IO.FPS_CameraControl.MoveSpeed,0,0)
	End If

	If Key(K_R) Then
		Dim crx, cry, crz
		GetCameraPosition(crx, cry, crz)
		SetCameraPosition(crx, cry+Core.IO.FPS_CameraControl.MoveSpeed, crz)
	ElseIf Key(K_F) Then
		Dim crx, cry, crz
		GetCameraPosition(crx, cry, crz)
		SetCameraPosition(crx, cry-Core.IO.FPS_CameraControl.MoveSpeed, crz)
	End If
	
	Canvas(current_canvas)
End Sub



title$ = "Serenity3D Template"
w = 640
h = 480
fullscreen = FALSE
vsync = FALSE


'Open a graphics window
OpenWindow("Serenity3D Template", w, h, fullscreen, vsync)

'Lock the window to 60 fps
SetFPS(60)

'Open a 3D Canvas
m3d = OpenCanvas3D(0, 0, w, h, 0)
ui_canvas = OpenCanvas(w, h, 0, 0, w, h, 1)
SetCanvasZ(ui_canvas, 0)
SetCanvasZ(m3d, 1)

LoadFont("font/FreeMono.ttf", 14)

Canvas(ui_canvas)
SetColor(RGB(10,10,10))
RectFill(5,5,180,180)
SetColor(RGB(255,255,255))
DrawText("Key 1 - Bloom", 10, 10)
DrawText("Key 2 - Blur", 10, 30)
DrawText("Key 3 - Motion Blur", 10, 50)
DrawText("Key 4 - Radial Blur", 10, 70)
DrawText("Key 5 - Colorize", 10, 90)
DrawText("Key 6 - Invert", 10, 110)
DrawText("Key 7 - Mineral", 10, 130)
DrawText("Key 0 - NONE", 10, 150)


Core.IO.FPS_CameraControl.ControlCanvas = m3d
SetMouseRelative(true)

'Set the 3D Canvas as the active Canvas (Camera Actions will be done on active canvas)
Canvas(m3d)

'Move and Rotate the Camera
SetCameraPosition(-100, 190, -300)
SetCameraRotation(0,90,0)

'Load a Stage
Serenity_Current_Stage.StageID = -1
Serenity_LoadStage("stage1")


'Main Loop
While Not Key(K_ESCAPE)
	Ambient_FPSControl()
	
	If Key(K_1) Then
		Canvas(m3d)
		SetPostEffect( m3d, POST_EFFECT_TYPE_BLOOM)
		SetPostEffectProperty( m3d, POST_EFFECT_PROPERTY_STRENGTH, 1.2 )
		
		While Key(K_1)
			Update()
		Wend
	ElseIf Key(K_2) Then
		Canvas(m3d)
		SetPostEffect( m3d, POST_EFFECT_TYPE_BLUR)
		SetPostEffectProperty( m3d, POST_EFFECT_PROPERTY_DISTANCE, 0.008 )
		
		While Key(K_2)
			Update()
		Wend
	ElseIf Key(K_3) Then
		Canvas(m3d)
		SetPostEffect( m3d, POST_EFFECT_TYPE_MOTION_BLUR)
		SetPostEffectProperty( m3d, POST_EFFECT_PROPERTY_STRENGTH, 0.8 )
		
		While Key(K_3)
			Update()
		Wend
	ElseIf Key(K_4) Then
		Canvas(m3d)
		SetPostEffect( m3d, POST_EFFECT_TYPE_RADIAL_BLUR)
		SetPostEffectProperty( m3d, POST_EFFECT_PROPERTY_STRENGTH, 2 )
		SetPostEffectProperty( m3d, POST_EFFECT_PROPERTY_DISTANCE, 0.8 )
		
		While Key(K_4)
			Update()
		Wend
	ElseIf Key(K_5) Then
		Canvas(m3d)
		SetPostEffect( m3d, POST_EFFECT_TYPE_COLORIZE)
		SetPostEffectProperty( m3d, POST_EFFECT_PROPERTY_STRENGTH, 5 )
		SetPostEffectProperty( m3d, POST_EFFECT_PROPERTY_SATURATION, 4 )
		SetPostEffectProperty( m3d, POST_EFFECT_PROPERTY_COLOR, RGB(255,0,0) )
		
		While Key(K_5)
			Update()
		Wend
	ElseIf Key(K_6) Then
		Canvas(m3d)
		SetPostEffect( m3d, POST_EFFECT_TYPE_INVERT)
		
		While Key(K_6)
			Update()
		Wend
	ElseIf Key(K_7) Then
		Canvas(m3d)
		SetPostEffect( m3d, POST_EFFECT_TYPE_MINERAL)
		SetPostEffectProperty( m3d, POST_EFFECT_PROPERTY_STRENGTH, 0.2 )
		
		While Key(K_7)
			Update()
		Wend
	ElseIf Key(K_0) Then
		Canvas(m3d)
		ClearPostEffect( m3d )
		
		While Key(K_7)
			Update()
		Wend
	End If
	
	Update()
Wend

