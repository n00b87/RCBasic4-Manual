path_separator$ = "/" : If OS$ = "WINDOWS" : path_separator$ = "\\" : End If


Const SN_MESH_TYPE_NORMAL = 0
Const SN_MESH_TYPE_ZIPPED = 1
Const SN_MESH_TYPE_AN8_SCENE = 2

Const SN_LIGHT_TYPE_POINT = 0
Const SN_LIGHT_TYPE_SPOT = 1
Const SN_LIGHT_TYPE_DIRECTIONAL = 2

Const SN_PARTICLE_TYPE_POINT = 0
Const SN_PARTICLE_TYPE_BOX = 1
Const SN_PARTICLE_TYPE_SPHERE = 2
Const SN_PARTICLE_TYPE_CYLINDER = 3
Const SN_PARTICLE_TYPE_MESH = 4
Const SN_PARTICLE_TYPE_RING = 5

Const SN_PHYSICS_SHAPE_NONE = 0
Const SN_PHYSICS_SHAPE_BOX = 1
Const SN_PHYSICS_SHAPE_SPHERE = 2
Const SN_PHYSICS_SHAPE_CYLINDER = 3
Const SN_PHYSICS_SHAPE_CAPSULE = 4
Const SN_PHYSICS_SHAPE_CONE = 5
Const SN_PHYSICS_SHAPE_CONVEXHULL = 6
Const SN_PHYSICS_SHAPE_TRIMESH = 7

Const SN_ACTOR_TYPE_ANIMATED = 0
Const SN_ACTOR_TYPE_OCTREE = 1
Const SN_ACTOR_TYPE_LIGHT = 2
Const SN_ACTOR_TYPE_BILLBOARD = 3
Const SN_ACTOR_TYPE_TERRAIN = 4
Const SN_ACTOR_TYPE_WATER = 5
Const SN_ACTOR_TYPE_PARTICLE = 6
Const SN_ACTOR_TYPE_CUBE = 7
Const SN_ACTOR_TYPE_SPHERE = 8
Const SN_ACTOR_TYPE_PLANE = 9

Const SN_SKY_TYPE_NONE = 0
Const SN_SKY_TYPE_BOX = 1
Const SN_SKY_TYPE_DOME = 2


Type Serenity_Vector3D
Dim x
Dim y
Dim z
End Type

Type Serenity_Size
Dim Width
Dim Height
Dim Depth
End Type

Function Serenity_CreateVector3D(x, y, z) As Serenity_Vector3D
	Dim v As Serenity_Vector3D
	v.x = x
	v.y = y
	v.z = z
	Return v
End Function

Function Serenity_CreateSize3D(w, h, d) As Serenity_Size
	Dim v As Serenity_Size
	v.width = w
	v.height = h
	v.depth = d
	Return v
End Function

Type Serenity_Texture
Dim ID
Dim Name$
Dim File$ 
Dim UseColorKey
Dim TextureColorKey 
End Type

Type Serenity_Texture_Reference
Dim SN_ID
End Type

Dim Serenity_Global_Texture_List[38] As Serenity_Texture

Type Serenity_Textures_List_Structure
Dim background As Serenity_Texture_Reference
Dim background_ddn As Serenity_Texture_Reference
Dim lion As Serenity_Texture_Reference
Dim lion2_ddn As Serenity_Texture_Reference
Dim lion_ddn As Serenity_Texture_Reference
Dim spnza_bricks_a_ddn As Serenity_Texture_Reference
Dim spnza_bricks_a_diff As Serenity_Texture_Reference
Dim spnza_bricks_a_spec As Serenity_Texture_Reference
Dim sponza_arch_ddn As Serenity_Texture_Reference
Dim sponza_arch_diff As Serenity_Texture_Reference
Dim sponza_arch_spec As Serenity_Texture_Reference
Dim sponza_ceiling_a_diff As Serenity_Texture_Reference
Dim sponza_ceiling_a_spec As Serenity_Texture_Reference
Dim sponza_column_a_ddn As Serenity_Texture_Reference
Dim sponza_column_a_diff As Serenity_Texture_Reference
Dim sponza_column_a_spec As Serenity_Texture_Reference
Dim sponza_column_b_ddn As Serenity_Texture_Reference
Dim sponza_column_b_diff As Serenity_Texture_Reference
Dim sponza_column_b_spec As Serenity_Texture_Reference
Dim sponza_column_c_ddn As Serenity_Texture_Reference
Dim sponza_column_c_diff As Serenity_Texture_Reference
Dim sponza_column_c_spec As Serenity_Texture_Reference
Dim sponza_curtain_blue_diff As Serenity_Texture_Reference
Dim sponza_curtain_diff As Serenity_Texture_Reference
Dim sponza_curtain_green_diff As Serenity_Texture_Reference
Dim sponza_details_diff As Serenity_Texture_Reference
Dim sponza_details_spec As Serenity_Texture_Reference
Dim sponza_fabric_blue_diff As Serenity_Texture_Reference
Dim sponza_fabric_diff As Serenity_Texture_Reference
Dim sponza_fabric_green_diff As Serenity_Texture_Reference
Dim sponza_fabric_spec As Serenity_Texture_Reference
Dim sponza_flagpole_diff As Serenity_Texture_Reference
Dim sponza_flagpole_spec As Serenity_Texture_Reference
Dim sponza_floor_a_diff As Serenity_Texture_Reference
Dim sponza_floor_a_spec As Serenity_Texture_Reference
Dim sponza_roof_diff As Serenity_Texture_Reference
Dim vase_ddn As Serenity_Texture_Reference
Dim vase_dif As Serenity_Texture_Reference
End Type


Type Serenity_Material
Dim ID
Dim Name$
Dim Texture_Matrix 'Index in Serenity_Global_Texture_List
End Type

Type Serenity_Material_Reference
Dim SN_ID
End Type

Dim Serenity_Global_Material_List[20] As Serenity_Material

Type Serenity_Materials_List_Structure
Dim Material__25 As Serenity_Material_Reference
Dim Material__298 As Serenity_Material_Reference
Dim Material__47 As Serenity_Material_Reference
Dim arch As Serenity_Material_Reference
Dim bricks As Serenity_Material_Reference
Dim ceiling As Serenity_Material_Reference
Dim column_a As Serenity_Material_Reference
Dim column_b As Serenity_Material_Reference
Dim column_c As Serenity_Material_Reference
Dim details As Serenity_Material_Reference
Dim fabric_a As Serenity_Material_Reference
Dim fabric_c As Serenity_Material_Reference
Dim fabric_d As Serenity_Material_Reference
Dim fabric_e As Serenity_Material_Reference
Dim fabric_f As Serenity_Material_Reference
Dim fabric_g As Serenity_Material_Reference
Dim flagpole As Serenity_Material_Reference
Dim floor As Serenity_Material_Reference
Dim roof As Serenity_Material_Reference
Dim vase As Serenity_Material_Reference
End Type


Type Serenity_Mesh_Animation
Dim Name$ 
Dim Start_Frame
Dim End_Frame
Dim Speed
End Type

Dim Serenity_Global_Mesh_Animation_List[0] As Serenity_Mesh_Animation

Type Serenity_Mesh
Dim ID 
Dim SN_ID
Dim Name$
Dim MeshType 
Dim AN8_Index 
Dim AN8_Scene$ 
Dim Zip$ 
Dim File$ 
Dim Material_Matrix 
Dim MaterialCount 
Dim Animation_Matrix
Dim AnimationCount 
Dim ColliderMesh_SN_ID 
End Type

Type Serenity_Mesh_Reference
Dim SN_ID
End Type

Dim Serenity_Global_AN8ID_List[1]
Dim Serenity_Global_Mesh_List[1] As Serenity_Mesh


Type Serenity_Meshes_List_Structure 
Dim sponza_mesh As Serenity_Mesh_Reference 
End Type

Type Serenity_Sky_Dome
Dim Image 
Dim hRes 
Dim vRes 
Dim TexturePCT 
Dim SpherePCT 
Dim Radius 
End Type 

Type Serenity_Sky_Box 
Dim Image_Left 
Dim Image_Right 
Dim Image_Top 
Dim Image_Bottom 
Dim Image_Front 
Dim Image_Back 
End Type 

Type Serenity_Sky_Structure
Dim Shape 
Dim Dome As Serenity_Sky_Dome 
Dim Box As Serenity_Sky_Box 
End Type 


Type Serenity_Actor_Physics
Dim Shape
Dim Mass
Dim isSolid
End Type

Type Serenity_Light_Properties
Dim LightType
Dim CastShadow
Dim InnerCone
Dim OuterCone
Dim Radius
Dim FallOff
Dim Ambient
Dim Diffuse
Dim Specular
Dim Constant
Dim Linear
Dim Quadratic
End Type

Type Serenity_Terrain_Properties
Dim HeightMap$
End Type

Type Serenity_ActorAnimation_Properties
Dim AnimationID
Dim NumLoops
End Type

Type Serenity_Water_Properties
Dim WaveHeight
Dim WaveLength
Dim WaveSpeed
End Type

Type Serenity_Particle_Properties
Dim ParticleType
Dim MinSize As Serenity_Size
Dim MaxSize As Serenity_Size
Dim MinStartColor
Dim MaxStartColor
Dim MinSpeed
Dim MaxSpeed
Dim MinLife
Dim MaxLife
Dim Normal As Serenity_Vector3D
Dim Direction As Serenity_Vector3D
Dim MaxAngle
Dim CircleCenter As Serenity_Vector3D
Dim Radius
Dim UseEveryVertex
Dim UseNormalDirection
Dim NormalDirectionModifier
Dim CylinderLength
Dim UseOutlineOnly
Dim MinBoxSize As Serenity_Size
Dim MaxBoxSize As Serenity_Size
Dim RingThickness
End Type

Type Serenity_Actor
Dim ID 
Dim SN_ID 
Dim Name$
Dim ActorType 
Dim Mesh  'Index in Global Mesh list
Dim Collider_ID 'Collision Actor (NOTE: Will be -1 by default
Dim Position As Serenity_Vector3D
Dim Rotation As Serenity_Vector3D
Dim Scale As Serenity_Vector3D
Dim Material
Dim Shadow
Dim AutoCulling
Dim Physics As Serenity_Actor_Physics
Dim Animation As Serenity_ActorAnimation_Properties
Dim Light As Serenity_Light_Properties
Dim Terrain As Serenity_Terrain_Properties
Dim Water As Serenity_Water_Properties
Dim Particle As Serenity_Particle_Properties
Dim CubeSize
Dim SphereRadius
Dim Visible
End Type 


Dim Textures As Serenity_Textures_List_Structure
'TEXTURES ARE LOADED AND UNLOADED WHEN LOADSTAGE() IS CALLED
Textures.background.SN_ID = 0
Serenity_Global_Texture_List[Textures.background.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.background.SN_ID].Name$ = "background"
Serenity_Global_Texture_List[Textures.background.SN_ID].File$ = "background.jpg"
Serenity_Global_Texture_List[Textures.background.SN_ID].TextureColorKey = 0

Textures.background_ddn.SN_ID = 1
Serenity_Global_Texture_List[Textures.background_ddn.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.background_ddn.SN_ID].Name$ = "background_ddn"
Serenity_Global_Texture_List[Textures.background_ddn.SN_ID].File$ = "background_ddn.jpg"
Serenity_Global_Texture_List[Textures.background_ddn.SN_ID].TextureColorKey = 0

Textures.lion.SN_ID = 2
Serenity_Global_Texture_List[Textures.lion.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.lion.SN_ID].Name$ = "lion"
Serenity_Global_Texture_List[Textures.lion.SN_ID].File$ = "lion.jpg"
Serenity_Global_Texture_List[Textures.lion.SN_ID].TextureColorKey = 0

Textures.lion2_ddn.SN_ID = 3
Serenity_Global_Texture_List[Textures.lion2_ddn.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.lion2_ddn.SN_ID].Name$ = "lion2_ddn"
Serenity_Global_Texture_List[Textures.lion2_ddn.SN_ID].File$ = "lion2_ddn.jpg"
Serenity_Global_Texture_List[Textures.lion2_ddn.SN_ID].TextureColorKey = 0

Textures.lion_ddn.SN_ID = 4
Serenity_Global_Texture_List[Textures.lion_ddn.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.lion_ddn.SN_ID].Name$ = "lion_ddn"
Serenity_Global_Texture_List[Textures.lion_ddn.SN_ID].File$ = "lion_ddn.jpg"
Serenity_Global_Texture_List[Textures.lion_ddn.SN_ID].TextureColorKey = 0

Textures.spnza_bricks_a_ddn.SN_ID = 5
Serenity_Global_Texture_List[Textures.spnza_bricks_a_ddn.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.spnza_bricks_a_ddn.SN_ID].Name$ = "spnza_bricks_a_ddn"
Serenity_Global_Texture_List[Textures.spnza_bricks_a_ddn.SN_ID].File$ = "spnza_bricks_a_ddn.jpg"
Serenity_Global_Texture_List[Textures.spnza_bricks_a_ddn.SN_ID].TextureColorKey = 0

Textures.spnza_bricks_a_diff.SN_ID = 6
Serenity_Global_Texture_List[Textures.spnza_bricks_a_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.spnza_bricks_a_diff.SN_ID].Name$ = "spnza_bricks_a_diff"
Serenity_Global_Texture_List[Textures.spnza_bricks_a_diff.SN_ID].File$ = "spnza_bricks_a_diff.jpg"
Serenity_Global_Texture_List[Textures.spnza_bricks_a_diff.SN_ID].TextureColorKey = 0

Textures.spnza_bricks_a_spec.SN_ID = 7
Serenity_Global_Texture_List[Textures.spnza_bricks_a_spec.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.spnza_bricks_a_spec.SN_ID].Name$ = "spnza_bricks_a_spec"
Serenity_Global_Texture_List[Textures.spnza_bricks_a_spec.SN_ID].File$ = "spnza_bricks_a_spec.jpg"
Serenity_Global_Texture_List[Textures.spnza_bricks_a_spec.SN_ID].TextureColorKey = 0

Textures.sponza_arch_ddn.SN_ID = 8
Serenity_Global_Texture_List[Textures.sponza_arch_ddn.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_arch_ddn.SN_ID].Name$ = "sponza_arch_ddn"
Serenity_Global_Texture_List[Textures.sponza_arch_ddn.SN_ID].File$ = "sponza_arch_ddn.jpg"
Serenity_Global_Texture_List[Textures.sponza_arch_ddn.SN_ID].TextureColorKey = 0

Textures.sponza_arch_diff.SN_ID = 9
Serenity_Global_Texture_List[Textures.sponza_arch_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_arch_diff.SN_ID].Name$ = "sponza_arch_diff"
Serenity_Global_Texture_List[Textures.sponza_arch_diff.SN_ID].File$ = "sponza_arch_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_arch_diff.SN_ID].TextureColorKey = 0

Textures.sponza_arch_spec.SN_ID = 10
Serenity_Global_Texture_List[Textures.sponza_arch_spec.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_arch_spec.SN_ID].Name$ = "sponza_arch_spec"
Serenity_Global_Texture_List[Textures.sponza_arch_spec.SN_ID].File$ = "sponza_arch_spec.jpg"
Serenity_Global_Texture_List[Textures.sponza_arch_spec.SN_ID].TextureColorKey = 0

Textures.sponza_ceiling_a_diff.SN_ID = 11
Serenity_Global_Texture_List[Textures.sponza_ceiling_a_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_ceiling_a_diff.SN_ID].Name$ = "sponza_ceiling_a_diff"
Serenity_Global_Texture_List[Textures.sponza_ceiling_a_diff.SN_ID].File$ = "sponza_ceiling_a_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_ceiling_a_diff.SN_ID].TextureColorKey = 0

Textures.sponza_ceiling_a_spec.SN_ID = 12
Serenity_Global_Texture_List[Textures.sponza_ceiling_a_spec.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_ceiling_a_spec.SN_ID].Name$ = "sponza_ceiling_a_spec"
Serenity_Global_Texture_List[Textures.sponza_ceiling_a_spec.SN_ID].File$ = "sponza_ceiling_a_spec.jpg"
Serenity_Global_Texture_List[Textures.sponza_ceiling_a_spec.SN_ID].TextureColorKey = 0

Textures.sponza_column_a_ddn.SN_ID = 13
Serenity_Global_Texture_List[Textures.sponza_column_a_ddn.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_column_a_ddn.SN_ID].Name$ = "sponza_column_a_ddn"
Serenity_Global_Texture_List[Textures.sponza_column_a_ddn.SN_ID].File$ = "sponza_column_a_ddn.jpg"
Serenity_Global_Texture_List[Textures.sponza_column_a_ddn.SN_ID].TextureColorKey = 0

Textures.sponza_column_a_diff.SN_ID = 14
Serenity_Global_Texture_List[Textures.sponza_column_a_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_column_a_diff.SN_ID].Name$ = "sponza_column_a_diff"
Serenity_Global_Texture_List[Textures.sponza_column_a_diff.SN_ID].File$ = "sponza_column_a_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_column_a_diff.SN_ID].TextureColorKey = 0

Textures.sponza_column_a_spec.SN_ID = 15
Serenity_Global_Texture_List[Textures.sponza_column_a_spec.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_column_a_spec.SN_ID].Name$ = "sponza_column_a_spec"
Serenity_Global_Texture_List[Textures.sponza_column_a_spec.SN_ID].File$ = "sponza_column_a_spec.jpg"
Serenity_Global_Texture_List[Textures.sponza_column_a_spec.SN_ID].TextureColorKey = 0

Textures.sponza_column_b_ddn.SN_ID = 16
Serenity_Global_Texture_List[Textures.sponza_column_b_ddn.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_column_b_ddn.SN_ID].Name$ = "sponza_column_b_ddn"
Serenity_Global_Texture_List[Textures.sponza_column_b_ddn.SN_ID].File$ = "sponza_column_b_ddn.jpg"
Serenity_Global_Texture_List[Textures.sponza_column_b_ddn.SN_ID].TextureColorKey = 0

Textures.sponza_column_b_diff.SN_ID = 17
Serenity_Global_Texture_List[Textures.sponza_column_b_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_column_b_diff.SN_ID].Name$ = "sponza_column_b_diff"
Serenity_Global_Texture_List[Textures.sponza_column_b_diff.SN_ID].File$ = "sponza_column_b_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_column_b_diff.SN_ID].TextureColorKey = 0

Textures.sponza_column_b_spec.SN_ID = 18
Serenity_Global_Texture_List[Textures.sponza_column_b_spec.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_column_b_spec.SN_ID].Name$ = "sponza_column_b_spec"
Serenity_Global_Texture_List[Textures.sponza_column_b_spec.SN_ID].File$ = "sponza_column_b_spec.jpg"
Serenity_Global_Texture_List[Textures.sponza_column_b_spec.SN_ID].TextureColorKey = 0

Textures.sponza_column_c_ddn.SN_ID = 19
Serenity_Global_Texture_List[Textures.sponza_column_c_ddn.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_column_c_ddn.SN_ID].Name$ = "sponza_column_c_ddn"
Serenity_Global_Texture_List[Textures.sponza_column_c_ddn.SN_ID].File$ = "sponza_column_c_ddn.jpg"
Serenity_Global_Texture_List[Textures.sponza_column_c_ddn.SN_ID].TextureColorKey = 0

Textures.sponza_column_c_diff.SN_ID = 20
Serenity_Global_Texture_List[Textures.sponza_column_c_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_column_c_diff.SN_ID].Name$ = "sponza_column_c_diff"
Serenity_Global_Texture_List[Textures.sponza_column_c_diff.SN_ID].File$ = "sponza_column_c_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_column_c_diff.SN_ID].TextureColorKey = 0

Textures.sponza_column_c_spec.SN_ID = 21
Serenity_Global_Texture_List[Textures.sponza_column_c_spec.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_column_c_spec.SN_ID].Name$ = "sponza_column_c_spec"
Serenity_Global_Texture_List[Textures.sponza_column_c_spec.SN_ID].File$ = "sponza_column_c_spec.jpg"
Serenity_Global_Texture_List[Textures.sponza_column_c_spec.SN_ID].TextureColorKey = 0

Textures.sponza_curtain_blue_diff.SN_ID = 22
Serenity_Global_Texture_List[Textures.sponza_curtain_blue_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_curtain_blue_diff.SN_ID].Name$ = "sponza_curtain_blue_diff"
Serenity_Global_Texture_List[Textures.sponza_curtain_blue_diff.SN_ID].File$ = "sponza_curtain_blue_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_curtain_blue_diff.SN_ID].TextureColorKey = 0

Textures.sponza_curtain_diff.SN_ID = 23
Serenity_Global_Texture_List[Textures.sponza_curtain_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_curtain_diff.SN_ID].Name$ = "sponza_curtain_diff"
Serenity_Global_Texture_List[Textures.sponza_curtain_diff.SN_ID].File$ = "sponza_curtain_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_curtain_diff.SN_ID].TextureColorKey = 0

Textures.sponza_curtain_green_diff.SN_ID = 24
Serenity_Global_Texture_List[Textures.sponza_curtain_green_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_curtain_green_diff.SN_ID].Name$ = "sponza_curtain_green_diff"
Serenity_Global_Texture_List[Textures.sponza_curtain_green_diff.SN_ID].File$ = "sponza_curtain_green_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_curtain_green_diff.SN_ID].TextureColorKey = 0

Textures.sponza_details_diff.SN_ID = 25
Serenity_Global_Texture_List[Textures.sponza_details_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_details_diff.SN_ID].Name$ = "sponza_details_diff"
Serenity_Global_Texture_List[Textures.sponza_details_diff.SN_ID].File$ = "sponza_details_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_details_diff.SN_ID].TextureColorKey = 0

Textures.sponza_details_spec.SN_ID = 26
Serenity_Global_Texture_List[Textures.sponza_details_spec.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_details_spec.SN_ID].Name$ = "sponza_details_spec"
Serenity_Global_Texture_List[Textures.sponza_details_spec.SN_ID].File$ = "sponza_details_spec.jpg"
Serenity_Global_Texture_List[Textures.sponza_details_spec.SN_ID].TextureColorKey = 0

Textures.sponza_fabric_blue_diff.SN_ID = 27
Serenity_Global_Texture_List[Textures.sponza_fabric_blue_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_fabric_blue_diff.SN_ID].Name$ = "sponza_fabric_blue_diff"
Serenity_Global_Texture_List[Textures.sponza_fabric_blue_diff.SN_ID].File$ = "sponza_fabric_blue_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_fabric_blue_diff.SN_ID].TextureColorKey = 0

Textures.sponza_fabric_diff.SN_ID = 28
Serenity_Global_Texture_List[Textures.sponza_fabric_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_fabric_diff.SN_ID].Name$ = "sponza_fabric_diff"
Serenity_Global_Texture_List[Textures.sponza_fabric_diff.SN_ID].File$ = "sponza_fabric_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_fabric_diff.SN_ID].TextureColorKey = 0

Textures.sponza_fabric_green_diff.SN_ID = 29
Serenity_Global_Texture_List[Textures.sponza_fabric_green_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_fabric_green_diff.SN_ID].Name$ = "sponza_fabric_green_diff"
Serenity_Global_Texture_List[Textures.sponza_fabric_green_diff.SN_ID].File$ = "sponza_fabric_green_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_fabric_green_diff.SN_ID].TextureColorKey = 0

Textures.sponza_fabric_spec.SN_ID = 30
Serenity_Global_Texture_List[Textures.sponza_fabric_spec.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_fabric_spec.SN_ID].Name$ = "sponza_fabric_spec"
Serenity_Global_Texture_List[Textures.sponza_fabric_spec.SN_ID].File$ = "sponza_fabric_spec.jpg"
Serenity_Global_Texture_List[Textures.sponza_fabric_spec.SN_ID].TextureColorKey = 0

Textures.sponza_flagpole_diff.SN_ID = 31
Serenity_Global_Texture_List[Textures.sponza_flagpole_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_flagpole_diff.SN_ID].Name$ = "sponza_flagpole_diff"
Serenity_Global_Texture_List[Textures.sponza_flagpole_diff.SN_ID].File$ = "sponza_flagpole_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_flagpole_diff.SN_ID].TextureColorKey = 0

Textures.sponza_flagpole_spec.SN_ID = 32
Serenity_Global_Texture_List[Textures.sponza_flagpole_spec.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_flagpole_spec.SN_ID].Name$ = "sponza_flagpole_spec"
Serenity_Global_Texture_List[Textures.sponza_flagpole_spec.SN_ID].File$ = "sponza_flagpole_spec.jpg"
Serenity_Global_Texture_List[Textures.sponza_flagpole_spec.SN_ID].TextureColorKey = 0

Textures.sponza_floor_a_diff.SN_ID = 33
Serenity_Global_Texture_List[Textures.sponza_floor_a_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_floor_a_diff.SN_ID].Name$ = "sponza_floor_a_diff"
Serenity_Global_Texture_List[Textures.sponza_floor_a_diff.SN_ID].File$ = "sponza_floor_a_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_floor_a_diff.SN_ID].TextureColorKey = 0

Textures.sponza_floor_a_spec.SN_ID = 34
Serenity_Global_Texture_List[Textures.sponza_floor_a_spec.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_floor_a_spec.SN_ID].Name$ = "sponza_floor_a_spec"
Serenity_Global_Texture_List[Textures.sponza_floor_a_spec.SN_ID].File$ = "sponza_floor_a_spec.jpg"
Serenity_Global_Texture_List[Textures.sponza_floor_a_spec.SN_ID].TextureColorKey = 0

Textures.sponza_roof_diff.SN_ID = 35
Serenity_Global_Texture_List[Textures.sponza_roof_diff.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.sponza_roof_diff.SN_ID].Name$ = "sponza_roof_diff"
Serenity_Global_Texture_List[Textures.sponza_roof_diff.SN_ID].File$ = "sponza_roof_diff.jpg"
Serenity_Global_Texture_List[Textures.sponza_roof_diff.SN_ID].TextureColorKey = 0

Textures.vase_ddn.SN_ID = 36
Serenity_Global_Texture_List[Textures.vase_ddn.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.vase_ddn.SN_ID].Name$ = "vase_ddn"
Serenity_Global_Texture_List[Textures.vase_ddn.SN_ID].File$ = "vase_ddn.jpg"
Serenity_Global_Texture_List[Textures.vase_ddn.SN_ID].TextureColorKey = 0

Textures.vase_dif.SN_ID = 37
Serenity_Global_Texture_List[Textures.vase_dif.SN_ID].ID = -1
Serenity_Global_Texture_List[Textures.vase_dif.SN_ID].Name$ = "vase_dif"
Serenity_Global_Texture_List[Textures.vase_dif.SN_ID].File$ = "vase_dif.jpg"
Serenity_Global_Texture_List[Textures.vase_dif.SN_ID].TextureColorKey = 0


Dim Materials As Serenity_Materials_List_Structure
'-----------------DEFINE MATERIALS---------------
'------------MATERIAL[ Material__25 ]---------------
Materials.Material__25.SN_ID = 0
Serenity_Global_Material_List[Materials.Material__25.SN_ID].Name$ = "Material__25"

Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.Material__25.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.Material__25.SN_ID].Texture_Matrix, 0, 0, Textures.lion.SN_ID)


'------------MATERIAL[ Material__298 ]---------------
Materials.Material__298.SN_ID = 1
Serenity_Global_Material_List[Materials.Material__298.SN_ID].Name$ = "Material__298"

Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.Material__298.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.Material__298.SN_ID].Texture_Matrix, 0, 0, Textures.background.SN_ID)


'------------MATERIAL[ Material__47 ]---------------
Materials.Material__47.SN_ID = 2
Serenity_Global_Material_List[Materials.Material__47.SN_ID].Name$ = "Material__47"

Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.Material__47.SN_ID].Texture_Matrix = DimMatrix(1, 0)



'------------MATERIAL[ arch ]---------------
Materials.arch.SN_ID = 3
Serenity_Global_Material_List[Materials.arch.SN_ID].Name$ = "arch"

Serenity_Global_Material_List[Materials.arch.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.arch.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.arch.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_arch_diff.SN_ID)


'------------MATERIAL[ bricks ]---------------
Materials.bricks.SN_ID = 4
Serenity_Global_Material_List[Materials.bricks.SN_ID].Name$ = "bricks"

Serenity_Global_Material_List[Materials.bricks.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.bricks.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.bricks.SN_ID].Texture_Matrix, 0, 0, Textures.spnza_bricks_a_diff.SN_ID)


'------------MATERIAL[ ceiling ]---------------
Materials.ceiling.SN_ID = 5
Serenity_Global_Material_List[Materials.ceiling.SN_ID].Name$ = "ceiling"

Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.ceiling.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.ceiling.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_ceiling_a_diff.SN_ID)


'------------MATERIAL[ column_a ]---------------
Materials.column_a.SN_ID = 6
Serenity_Global_Material_List[Materials.column_a.SN_ID].Name$ = "column_a"

Serenity_Global_Material_List[Materials.column_a.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.column_a.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.column_a.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_column_a_diff.SN_ID)


'------------MATERIAL[ column_b ]---------------
Materials.column_b.SN_ID = 7
Serenity_Global_Material_List[Materials.column_b.SN_ID].Name$ = "column_b"

Serenity_Global_Material_List[Materials.column_b.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.column_b.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.column_b.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_column_b_diff.SN_ID)


'------------MATERIAL[ column_c ]---------------
Materials.column_c.SN_ID = 8
Serenity_Global_Material_List[Materials.column_c.SN_ID].Name$ = "column_c"

Serenity_Global_Material_List[Materials.column_c.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.column_c.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.column_c.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_column_c_diff.SN_ID)


'------------MATERIAL[ details ]---------------
Materials.details.SN_ID = 9
Serenity_Global_Material_List[Materials.details.SN_ID].Name$ = "details"

Serenity_Global_Material_List[Materials.details.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.details.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.details.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.details.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.details.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.details.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.details.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.details.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.details.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.details.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.details.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.details.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.details.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.details.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.details.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.details.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.details.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.details.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.details.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.details.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.details.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.details.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.details.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_details_diff.SN_ID)


'------------MATERIAL[ fabric_a ]---------------
Materials.fabric_a.SN_ID = 10
Serenity_Global_Material_List[Materials.fabric_a.SN_ID].Name$ = "fabric_a"

Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.fabric_a.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_fabric_diff.SN_ID)


'------------MATERIAL[ fabric_c ]---------------
Materials.fabric_c.SN_ID = 11
Serenity_Global_Material_List[Materials.fabric_c.SN_ID].Name$ = "fabric_c"

Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.fabric_c.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_curtain_diff.SN_ID)


'------------MATERIAL[ fabric_d ]---------------
Materials.fabric_d.SN_ID = 12
Serenity_Global_Material_List[Materials.fabric_d.SN_ID].Name$ = "fabric_d"

Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.fabric_d.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_fabric_blue_diff.SN_ID)


'------------MATERIAL[ fabric_e ]---------------
Materials.fabric_e.SN_ID = 13
Serenity_Global_Material_List[Materials.fabric_e.SN_ID].Name$ = "fabric_e"

Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.fabric_e.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_fabric_green_diff.SN_ID)


'------------MATERIAL[ fabric_f ]---------------
Materials.fabric_f.SN_ID = 14
Serenity_Global_Material_List[Materials.fabric_f.SN_ID].Name$ = "fabric_f"

Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.fabric_f.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_curtain_green_diff.SN_ID)


'------------MATERIAL[ fabric_g ]---------------
Materials.fabric_g.SN_ID = 15
Serenity_Global_Material_List[Materials.fabric_g.SN_ID].Name$ = "fabric_g"

Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.fabric_g.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_curtain_blue_diff.SN_ID)


'------------MATERIAL[ flagpole ]---------------
Materials.flagpole.SN_ID = 16
Serenity_Global_Material_List[Materials.flagpole.SN_ID].Name$ = "flagpole"

Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.flagpole.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.flagpole.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_flagpole_diff.SN_ID)


'------------MATERIAL[ floor ]---------------
Materials.floor.SN_ID = 17
Serenity_Global_Material_List[Materials.floor.SN_ID].Name$ = "floor"

Serenity_Global_Material_List[Materials.floor.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.floor.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.floor.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_floor_a_diff.SN_ID)


'------------MATERIAL[ roof ]---------------
Materials.roof.SN_ID = 18
Serenity_Global_Material_List[Materials.roof.SN_ID].Name$ = "roof"

Serenity_Global_Material_List[Materials.roof.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.roof.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.roof.SN_ID].Texture_Matrix, 0, 0, Textures.sponza_roof_diff.SN_ID)


'------------MATERIAL[ vase ]---------------
Materials.vase.SN_ID = 19
Serenity_Global_Material_List[Materials.vase.SN_ID].Name$ = "vase"

Serenity_Global_Material_List[Materials.vase.SN_ID].ID = CreateMaterial() 
SetMaterialAmbientColor(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, 4294967295) 
SetMaterialDiffuseColor(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, 4294967295) 
SetMaterialEmissiveColor(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, 0) 
SetMaterialSpecularColor(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, 4294967295) 
SetMaterialAntiAliasing(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, AA_MODE_SIMPLE ) 
SetMaterialBackfaceCulling(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, TRUE) 
SetMaterialFrontfaceCulling(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, FALSE) 
SetMaterialBlendFactor(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, 0) 
SetMaterialBlendMode(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, BLEND_MODE_NONE ) 
SetMaterialColorMask(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, COLOR_MASK_ALL ) 
SetMaterialColorMode(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, COLOR_MODE_DIFFUSE ) 
SetMaterialFog(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, FALSE) 
SetMaterialGouraudShading(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, TRUE) 
SetMaterialLighting(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, TRUE) 
SetMaterialType(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, MATERIAL_TYPE_SOLID ) 
SetMaterialNormalize(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, FALSE) 
SetMaterialPointCloud(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, FALSE) 
SetMaterialShininess(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, 0) 
SetMaterialThickness(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, 1) 
SetMaterialWireframe(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, FALSE) 

Serenity_Global_Material_List[Materials.vase.SN_ID].Texture_Matrix = DimMatrix(1, 1)

SetMatrixValue(Serenity_Global_Material_List[Materials.vase.SN_ID].Texture_Matrix, 0, 0, Textures.vase_dif.SN_ID)



Dim Meshes As Serenity_Meshes_List_Structure
'-----------------DEFINE MESHES---------------
'-----MESH[ sponza_mesh ]------------
Meshes.sponza_mesh.SN_ID = 0
Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Name$ = "sponza_mesh"
Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].ColliderMesh_SN_ID = -1
Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].MeshType = SN_MESH_TYPE_NORMAL
Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].File$ = "sponza.obj"

Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].AnimationCount = 0
Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Animation_Matrix = DimMatrix(1, Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].AnimationCount)

Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].MaterialCount = 20
Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix = DimMatrix(1, Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].MaterialCount)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 0, Materials.Material__25.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 1, Materials.Material__298.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 2, Materials.Material__47.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 3, Materials.arch.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 4, Materials.bricks.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 5, Materials.ceiling.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 6, Materials.column_a.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 7, Materials.column_b.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 8, Materials.column_c.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 9, Materials.details.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 10, Materials.fabric_a.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 11, Materials.fabric_c.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 12, Materials.fabric_d.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 13, Materials.fabric_e.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 14, Materials.fabric_f.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 15, Materials.fabric_g.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 16, Materials.flagpole.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 17, Materials.floor.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 18, Materials.roof.SN_ID)
SetMatrixValue(Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].Material_Matrix, 0, 19, Materials.vase.SN_ID)



Dim Serenity_Global_Actor_List[2] As Serenity_Actor

Type Serenity_Stage
Dim ID
Dim Name$
Dim ActorCount
Dim Actor_Matrix
Dim Sky As Serenity_Sky_Structure
Dim GroupName$[1]
Dim GroupCount
End Type
Dim Serenity_Global_Stage_List[1] As Serenity_Stage

Type Serenity_Current_Stage_Structure
Dim StageID
Dim HasSky
End Type

Dim Serenity_Current_Stage As Serenity_Current_Stage_Structure

'-----------------DEFINE STAGES---------------
'----------------INIT STAGE: [ stage1 ]-----------------------
Serenity_Global_Stage_List[0].ID = 0
Serenity_Global_Stage_List[0].ActorCount = 2

Serenity_Global_Stage_List[0].Actor_Matrix = DimMatrix(2, 2)
'-----------ACTOR [ Serenity_Global_Stage_List[0].Actors.sponza ]----------------
Serenity_Global_Actor_List[0].Name$ = "sponza"
Serenity_Global_Actor_List[0].SN_ID = 0

SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 0, 0, 0)
SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 1, 0, -1)
Serenity_Global_Actor_List[0].ID = -1
Serenity_Global_Actor_List[0].ActorType = SN_ACTOR_TYPE_OCTREE
Serenity_Global_Actor_List[0].Mesh = Meshes.sponza_mesh.SN_ID
Serenity_Global_Actor_List[0].Position = Serenity_CreateVector3D(0, 0, -270)
Serenity_Global_Actor_List[0].Rotation = Serenity_CreateVector3D(0, 0, 0)
Serenity_Global_Actor_List[0].Scale = Serenity_CreateVector3D(1, 1, 1)
Serenity_Global_Actor_List[0].Shadow = FALSE
Serenity_Global_Actor_List[0].AutoCulling = AUTOCULLING_BOX
Serenity_Global_Actor_List[0].Visible = TRUE
Serenity_Global_Actor_List[0].Physics.isSolid = FALSE
Serenity_Global_Actor_List[0].Physics.Mass = 0
Serenity_Global_Actor_List[0].Physics.Shape = 1

'-----------ACTOR [ Serenity_Global_Stage_List[0].Actors.point_light ]----------------
Serenity_Global_Actor_List[1].Name$ = "point_light"
Serenity_Global_Actor_List[1].SN_ID = 1

SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 0, 1, 1)
SetMatrixValue(Serenity_Global_Stage_List[0].Actor_Matrix, 1, 1, -1)
Serenity_Global_Actor_List[1].ID = -1
Serenity_Global_Actor_List[1].ActorType = SN_ACTOR_TYPE_LIGHT
Serenity_Global_Actor_List[1].Position = Serenity_CreateVector3D(-388.698, 515.612, -258.389)
Serenity_Global_Actor_List[1].Rotation = Serenity_CreateVector3D(-269.659, 0, 0)
Serenity_Global_Actor_List[1].Scale = Serenity_CreateVector3D(1, 1, 1)
Serenity_Global_Actor_List[1].Shadow = FALSE
Serenity_Global_Actor_List[1].AutoCulling = AUTOCULLING_BOX
Serenity_Global_Actor_List[1].Visible = TRUE
Serenity_Global_Actor_List[1].Physics.isSolid = FALSE
Serenity_Global_Actor_List[1].Physics.Mass = 0
Serenity_Global_Actor_List[1].Physics.Shape = 2
Serenity_Global_Actor_List[1].Light.LightType = SN_LIGHT_TYPE_POINT
Serenity_Global_Actor_List[1].Light.CastShadow = TRUE
Serenity_Global_Actor_List[1].Light.InnerCone = 300
Serenity_Global_Actor_List[1].Light.OuterCone = 400
Serenity_Global_Actor_List[1].Light.FallOff = 20
Serenity_Global_Actor_List[1].Light.Ambient = 4293980400
Serenity_Global_Actor_List[1].Light.Diffuse = 4293980400
Serenity_Global_Actor_List[1].Light.Specular = 4293980400
Serenity_Global_Actor_List[1].Light.Radius = 600


'------------[STAGE LOAD FUNCTIONS]-----------
Sub Load_stage1( )
	Serenity_Current_Stage.StageID = 0

	'---------STAGE TEXTURES-------------
	Serenity_Global_Texture_List[ Textures.lion.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.lion.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.background.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.background.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_arch_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_arch_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.spnza_bricks_a_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.spnza_bricks_a_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_ceiling_a_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_ceiling_a_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_column_a_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_column_a_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_column_b_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_column_b_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_column_c_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_column_c_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_details_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_details_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_fabric_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_fabric_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_curtain_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_curtain_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_fabric_blue_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_fabric_blue_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_fabric_green_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_fabric_green_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_curtain_green_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_curtain_green_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_curtain_blue_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_curtain_blue_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_flagpole_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_flagpole_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_floor_a_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_floor_a_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.sponza_roof_diff.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.sponza_roof_diff.SN_ID].File$)
	Serenity_Global_Texture_List[ Textures.vase_dif.SN_ID ].ID = LoadImage("textures" + path_separator$ + Serenity_Global_Texture_List[Textures.vase_dif.SN_ID].File$)


	'---------STAGE MATERIALS-------------
	SetMaterialTexture(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.lion.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.background.SN_ID].ID ) 
	
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_arch_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.spnza_bricks_a_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_ceiling_a_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_column_a_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_column_b_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_column_c_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.details.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_details_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_fabric_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_curtain_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_fabric_blue_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_fabric_green_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_curtain_green_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_curtain_blue_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_flagpole_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_floor_a_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.sponza_roof_diff.SN_ID].ID ) 
	
	SetMaterialTexture(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, 0, Serenity_Global_Texture_List[Textures.vase_dif.SN_ID].ID ) 
	


	'---------STAGE AN8-------------


	'---------STAGE MESHES-------------
	Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].ID = LoadMesh("models" + path_separator$ + "sponza.obj")




	Serenity_Global_Actor_List[0].ID =  CreateOctreeActor( Serenity_Global_Mesh_List[Serenity_Global_Actor_List[0].Mesh].ID ) 

	SetActorPosition( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Position.X, Serenity_Global_Actor_List[0].Position.Y, Serenity_Global_Actor_List[0].Position.Z ) 
	SetActorRotation( Serenity_Global_Actor_List[0].ID, 0, Serenity_Global_Actor_List[0].Rotation.Y, 0 ) 
	RotateActor( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Rotation.X, 0, 0 ) 
	RotateActor( Serenity_Global_Actor_List[0].ID, 0, 0, Serenity_Global_Actor_List[0].Rotation.Z ) 
	SetActorScale( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Scale.X, Serenity_Global_Actor_List[0].Scale.Y, Serenity_Global_Actor_List[0].Scale.Z ) 

	SetActorVisible( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Visible ) 
	SetActorAutoCulling( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].AutoCulling ) 
	RemoveActorShadow( Serenity_Global_Actor_List[0].ID ) 


	SetActorShape( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Physics.Shape, Serenity_Global_Actor_List[0].Physics.Mass ) 
	SetActorSolid( Serenity_Global_Actor_List[0].ID, Serenity_Global_Actor_List[0].Physics.isSolid ) 



	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 0, Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 1, Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 2, Serenity_Global_Material_List[Materials.Material__47.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 3, Serenity_Global_Material_List[Materials.arch.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 4, Serenity_Global_Material_List[Materials.bricks.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 5, Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 6, Serenity_Global_Material_List[Materials.column_a.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 7, Serenity_Global_Material_List[Materials.column_b.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 8, Serenity_Global_Material_List[Materials.column_c.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 9, Serenity_Global_Material_List[Materials.details.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 10, Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 11, Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 12, Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 13, Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 14, Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 15, Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 16, Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 17, Serenity_Global_Material_List[Materials.floor.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 18, Serenity_Global_Material_List[Materials.roof.SN_ID].ID ) 
	SetActorMaterial( Serenity_Global_Actor_List[0].ID, 19, Serenity_Global_Material_List[Materials.vase.SN_ID].ID ) 

	Serenity_Global_Actor_List[1].ID =  CreateLightActor( ) 

	SetActorPosition( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Position.X, Serenity_Global_Actor_List[1].Position.Y, Serenity_Global_Actor_List[1].Position.Z ) 
	SetActorRotation( Serenity_Global_Actor_List[1].ID, 0, Serenity_Global_Actor_List[1].Rotation.Y, 0 ) 
	RotateActor( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Rotation.X, 0, 0 ) 
	RotateActor( Serenity_Global_Actor_List[1].ID, 0, 0, Serenity_Global_Actor_List[1].Rotation.Z ) 
	SetActorScale( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Scale.X, Serenity_Global_Actor_List[1].Scale.Y, Serenity_Global_Actor_List[1].Scale.Z ) 

	SetActorVisible( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Visible ) 
	SetActorAutoCulling( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].AutoCulling ) 

	SetLightType( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Light.LightType )
	SetLightShadowCast( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Light.CastShadow )
	SetLightInnerCone( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Light.InnerCone )
	SetLightOuterCone( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Light.OuterCone )
	SetLightFallOff( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Light.FallOff )
	SetLightAmbientColor( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Light.Ambient )
	SetLightDiffuseColor( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Light.Diffuse )
	SetLightSpecularColor( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Light.Specular )
	SetLightRadius( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Light.Radius )

	SetActorShape( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Physics.Shape, Serenity_Global_Actor_List[1].Physics.Mass ) 
	SetActorSolid( Serenity_Global_Actor_List[1].ID, Serenity_Global_Actor_List[1].Physics.isSolid ) 


End Sub





'------------[STAGE CLEAR FUNCTIONS]-----------
Sub Clear_stage1( )
	Serenity_Current_Stage.StageID = -1
	'---------STAGE ACTORS-------------
	DeleteActor( Serenity_Global_Actor_List[0].ID )
	Serenity_Global_Actor_List[0].ID = -1
	DeleteActor( Serenity_Global_Actor_List[1].ID )
	Serenity_Global_Actor_List[1].ID = -1
	'---------STAGE MESHES-------------
	DeleteMesh( Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].ID )
	Serenity_Global_Mesh_List[Meshes.sponza_mesh.SN_ID].ID = -1



	'---------STAGE AN8-------------


	'---------STAGE MATERIALS-------------
	SetMaterialTexture(Serenity_Global_Material_List[Materials.Material__25.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.Material__298.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.arch.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.bricks.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.ceiling.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.column_a.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.column_b.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.column_c.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.details.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_a.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_c.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_d.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_e.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_f.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.fabric_g.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.flagpole.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.floor.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.roof.SN_ID].ID, 0, -1 ) 
	SetMaterialTexture(Serenity_Global_Material_List[Materials.vase.SN_ID].ID, 0, -1 ) 


	'---------STAGE TEXTURES-------------
	DeleteImage( Serenity_Global_Texture_List[ Textures.lion.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.lion.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.background.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.background.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_arch_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_arch_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.spnza_bricks_a_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.spnza_bricks_a_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_ceiling_a_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_ceiling_a_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_column_a_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_column_a_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_column_b_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_column_b_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_column_c_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_column_c_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_details_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_details_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_fabric_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_fabric_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_curtain_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_curtain_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_fabric_blue_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_fabric_blue_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_fabric_green_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_fabric_green_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_curtain_green_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_curtain_green_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_curtain_blue_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_curtain_blue_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_flagpole_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_flagpole_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_floor_a_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_floor_a_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.sponza_roof_diff.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.sponza_roof_diff.SN_ID ].ID = -1
	DeleteImage( Serenity_Global_Texture_List[ Textures.vase_dif.SN_ID ].ID )
	Serenity_Global_Texture_List[ Textures.vase_dif.SN_ID ].ID = -1


End Sub







'------------[API FUNCTIONS]-------------------
'-------TEXTURES-------
Function Serenity_GetTextureIndex(texture_name$)
	For i = 0 To 37
		If Serenity_Global_Texture_List[i].Name$ = texture_name$ Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetTextureCount()
	Return 38
End Function

Function Serenity_GetTextureID(texture_index)
	If texture_index < 0 Or texture_index >= 38 Then
		Return -1
	End If
	Return Serenity_Global_Texture_List[texture_index].ID
End Function

Function Serenity_GetTextureFile$(texture_index)
	If texture_index < 0 Or texture_index >= 38 Then
		Return ""
	End If
	Return Serenity_Global_Texture_List[texture_index].File$
End Function

Function Serenity_GetTextureColorKey(texture_index)
	If texture_index < 0 Or texture_index >= 38 Then
		Return 0
	End If
	Return Serenity_Global_Texture_List[texture_index].TextureColorKey
End Function

Function Serenity_GetTextureIsColorKey(texture_index)
	If texture_index < 0 Or texture_index >= 38 Then
		Return FALSE
	End If
	Return Serenity_Global_Texture_List[texture_index].UseColorKey
End Function

'-------MATERIALS-------
Function Serenity_GetMaterialIndex(material_name$)
	For i = 0 To 19
		If Serenity_Global_Material_List[i].Name$ = material_name$ Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetMaterialCount()
	Return 20
End Function

Function Serenity_GetMaterialID(material_index)
	If material_index < 0 Or material_index >= 20 Then
		Return -1
	End If
	Return Serenity_Global_Material_List[material_index].ID
End Function

Function Serenity_GetMaterialTextureIndex(material_index, texture_level)
	If material_index < 0 Or material_index >= 20 Then
		Return -1
	End If
	Dim r, c
	GetMatrixSize(Serenity_Global_Material_List[material_index].Texture_Matrix, r, c)
	If texture_level < 0 Or texture_level >= c Then
		Return -1
	End If
	Return MatrixValue(Serenity_Global_Material_List[material_index].Texture_Matrix, 0, texture_level)
End Function

'-------AN8-------
Function Serenity_GetAN8Count()
	Return 0
End Function

Function Serenity_GetAN8ID(an8_index)
	If an8_index < 0 Or an8_index >= 0 Then
		Return -1
	End If
	Return Serenity_Global_AN8ID_List[an8_index]
End Function

'-------MESHES-------
Function Serenity_GetMeshIndex(mesh_name$)
	For i = 0 To 0
		If Serenity_Global_Mesh_List[i].Name$ = mesh_name$ Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetMeshCount()
	Return 1
End Function

Function Serenity_GetMeshID(mesh_index)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return -1
	End If
	Return Serenity_Global_Mesh_List[mesh_index].ID
End Function

Function Serenity_GetMeshName$(mesh_index)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return ""
	End If
	Return Serenity_Global_Mesh_List[mesh_index].Name$
End Function

Function Serenity_GetMeshType(mesh_index)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return -1
	End If
	Return Serenity_Global_Mesh_List[mesh_index].MeshType
End Function

Function Serenity_GetMeshAN8Index(mesh_index)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return -1
	End If
	Return Serenity_Global_Mesh_List[mesh_index].AN8_Index
End Function

Function Serenity_GetMeshAN8Scene$(mesh_index)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return ""
	End If
	Return Serenity_Global_Mesh_List[mesh_index].AN8_Scene$
End Function

Function Serenity_GetMeshArchiveName$(mesh_index)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return ""
	End If
	Return Serenity_Global_Mesh_List[mesh_index].Zip$
End Function

Function Serenity_GetMeshFile$(mesh_index)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return ""
	End If
	Return Serenity_Global_Mesh_List[mesh_index].File$
End Function

Function Serenity_GetMeshMaterialCount(mesh_index)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return 0
	End If
	Return Serenity_Global_Mesh_List[mesh_index].MaterialCount
End Function

Function Serenity_GetMeshMaterialIndex(mesh_index, material_num)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return -1
	End If
	If material_num < 0 Or material_num >= Serenity_Global_Mesh_List[mesh_index].MaterialCount Then
		Return -1
	End If
	Return MatrixValue(Serenity_Global_Mesh_List[mesh_index].Material_Matrix, 0, material_num)
End Function

Function Serenity_GetMeshAnimationCount(mesh_index)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return 0
	End If
	Return Serenity_Global_Mesh_List[mesh_index].AnimationCount
End Function

Function Serenity_GetMeshAnimationID(mesh_index, animation_num)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return -1
	End If
	If animation_num < 0 Or animation_num >= Serenity_Global_Mesh_List[mesh_index].AnimationCount Then
		Return -1
	End If
	Return MatrixValue(Serenity_Global_Mesh_List[mesh_index].Animation_Matrix, 0, animation_num)+1
End Function

Function Serenity_GetMeshAnimationIDByName(mesh_index, animation_name$)
	If mesh_index < 0 Or mesh_index >= ArraySize(Serenity_Global_Mesh_List, 1) Then
		Return -1
	End If
	ani_name$ = Trim$(UCase$(animation_name$))
	For i = 0 To ArraySize(Serenity_Global_Mesh_Animation_List, 1) - 1
		If Trim$(UCase$(Serenity_Global_Mesh_Animation_List[i].Name$)) = ani_name$ Then
			Return MatrixValue(Serenity_Global_Mesh_List[mesh_index].Animation_Matrix, 0, i)+1
		End If
	Next
	Return -1
End Function

Function Serenity_GetMeshColliderIndex(mesh_index)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return -1
	End If
	Return Serenity_Global_Mesh_List[mesh_index].ColliderMesh_SN_ID
End Function

Sub Serenity_SetMeshColliderIndex(mesh_index, collider_index)
	If mesh_index < 0 Or mesh_index >= 1 Then
		Return
	End If
	Serenity_Global_Mesh_List[mesh_index].ColliderMesh_SN_ID = collider_index
End Sub

'-------SKY-------
Function Serenity_GetSkyShape()
	If Serenity_Current_Stage.StageID < 0 Then
		Return -1
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].Sky.Shape
End Function

Function Serenity_GetSkyBox() As Serenity_Sky_Box
	If Serenity_Current_Stage.StageID < 0 Then
		Dim tmp_sky As Serenity_Sky_Box
		Return tmp_sky
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].Sky.Box
End Function

Function Serenity_GetSkyDome() As Serenity_Sky_Dome
	If Serenity_Current_Stage.StageID < 0 Then
		Dim tmp_sky As Serenity_Sky_Dome
		Return tmp_sky
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].Sky.Dome
End Function

Function Serenity_StageHasSky()
	If Serenity_Current_Stage.StageID < 0 Then
		Return FALSE
	End If
	Return Serenity_Current_Stage.HasSky
End Function

'-------ACTORS-------
Function Serenity_GetActorIndex(actor_name$)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	For i = 0 To Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount-1
		If Serenity_Global_Actor_List[i].Name$ = actor_name$ Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetActorCount()
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return 0
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount
End Function

Function Serenity_GetActorID(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].ID
End Function

Function Serenity_GetActorName$(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return ""
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return ""
	End If
	Return Serenity_Global_Actor_List[actor_index].Name$
End Function

Function Serenity_GetActorType(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].ActorType
End Function

Function Serenity_GetActorMeshIndex(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].Mesh
End Function

Function Serenity_GetActorOverrideMaterialIndex(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].Material
End Function

Function Serenity_GetActorTerrainHeightMap$(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return ""
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return ""
	End If
	Return Serenity_Global_Actor_List[actor_index].Terrain.HeightMap$
End Function

Function Serenity_GetActorCubeSize(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].CubeSize
End Function

Function Serenity_GetActorSphereRadius(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return Serenity_Global_Actor_List[actor_index].SphereRadius
End Function

Function Serenity_GetActorGroupIndex(actor_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return -1
	End If
	If actor_index < 0 Or actor_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].ActorCount Then
		Return -1
	End If
	Return MatrixValue(Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].Actor_Matrix, 1, actor_index)
End Function

'-------STAGES-------
Function Serenity_GetStageIndex(stage_name$)
	For i = 0 To 0
		If Serenity_Global_Stage_List[i].Name$ = stage_name$ Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetStageName$(stage_index)
	If stage_index < 0 Or stage_index >= 1 Then
		Return ""
	End If
	Return Serenity_Global_Stage_List[stage_index].Name$
End Function

Function Serenity_GetStageCount()
	Return 1
End Function

Sub Serenity_ClearStage()
	Select Case Serenity_Current_Stage.StageID
	Case 0 : Clear_stage1()
	End Select
End Sub

Sub Serenity_LoadStage(stage_name$)
	Serenity_ClearStage()
	Select Case stage_name$
	Case "stage1" : Load_stage1()
	End Select
End Sub

Function Serenity_GetCurrentStageIndex()
	Return Serenity_Current_Stage.StageID
End Function

'-------GROUPS-------
Function Serenity_GetGroupCount()
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return 0
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].GroupCount
End Function

Function Serenity_GetGroupIndex(group_name$)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return 0
	End If
	For i = 0 To Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].GroupCount-1
		If UCase$(Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].GroupName$[i]) = UCase$(group_name) Then
			Return i
		End If
	Next
	Return -1
End Function

Function Serenity_GetGroupName$(group_index)
	If Serenity_Current_Stage.StageID < 0 Or Serenity_Current_Stage.StageID >= 1 Then
		Return ""
	End If
	If group_index < 0 Or group_index >= Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].GroupCount Then
		Return ""
	End If
	Return Serenity_Global_Stage_List[Serenity_Current_Stage.StageID].GroupName$[group_index]
End Function



Include Once
